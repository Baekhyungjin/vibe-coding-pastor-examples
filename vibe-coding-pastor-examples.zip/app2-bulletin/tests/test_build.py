# -*- coding: utf-8 -*-
"""빌드 결과 정적 검사 (T3, T4, T5, T6, T7 중 Python 이 할 수 있는 부분).
화면 폭과 글자 크기 버튼 동작은 브라우저가 필요하다(scripts/browser_check.js.txt, 사람과 AI 가 함께 확인)."""
import hashlib
import json
import os
import re
import shutil
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import bulletin  # noqa: E402
from verify_core import record_metric  # noqa: E402

TMP = os.path.join(ROOT, "output", "_t_build")
CFG = bulletin.load_config(ROOT)
CODES = bulletin.load_codes(CFG, ROOT)


def fresh(name):
    p = os.path.join(TMP, name)
    shutil.rmtree(p, ignore_errors=True)
    os.makedirs(p)
    return p


def make_root(name, dates):
    """운영 content 를 복사한 임시 작업 폴더 (config, data, lib, photos 는 공유)."""
    r = fresh(name)
    for d in ("config", "data", "lib", "photos"):
        shutil.copytree(os.path.join(ROOT, d), os.path.join(r, d))
    os.makedirs(os.path.join(r, "content"))
    base = json.load(open(os.path.join(ROOT, "content", "2026-11-01.json"), encoding="utf-8"))
    for d in dates:
        c = dict(base, date=d)
        with open(os.path.join(r, "content", d + ".json"), "w", encoding="utf-8") as f:
            json.dump(c, f, ensure_ascii=False)
    return r


def weekly(start, n):
    import datetime
    d0 = datetime.date.fromisoformat(start)
    return [(d0 + datetime.timedelta(weeks=i)).isoformat() for i in range(n)]


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


class BuildTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.root = make_root("base", ["2026-10-18", "2026-10-25", "2026-11-01"])
        cls.out = os.path.join(cls.root, "docs")
        cls.res = bulletin.build(cls.root, out_dir=cls.out)
        cls.pages = {"index": read(os.path.join(cls.out, "index.html"))}
        for d in cls.res["built"]:
            cls.pages[d] = read(os.path.join(cls.out, d, "index.html"))

    def test_S1_최신_주보가_docs_index_에_있다(self):
        self.assertEqual("2026-11-01", self.res["latest"])
        self.assertIn("2026년 11월 1일 일요일", self.pages["index"])
        self.assertEqual(4, len(self.pages))

    def test_T6_모든_쪽에_noindex_가_있다(self):
        for k, h in self.pages.items():
            self.assertIn('<meta name="robots" content="noindex, nofollow">', h, k)

    def test_T6b_모든_이미지에_alt_가_있다(self):
        n = 0
        for k, h in self.pages.items():
            for tag in re.findall(r"<img\b[^>]*>", h):
                n += 1
                m = re.search(r'alt="([^"]*)"', tag)
                self.assertTrue(m and m.group(1).strip(), "%s: %s" % (k, tag))
        self.assertGreaterEqual(n, 4)

    def test_T7_성경_링크는_모두_확인된_주소_형식이다(self):
        pat = re.compile(r"^https://bible\.bskorea\.or\.kr/bible/KRV/([1-3]?[A-Z]{2,3})\.(\d{1,3})$")
        valid = {v["code"] for v in CODES.values()}
        links = 0
        for k, h in self.pages.items():
            for href in re.findall(r'<a class="ref" href="([^"]+)"', h):
                links += 1
                m = pat.match(href)
                self.assertIsNotNone(m, "%s: %s" % (k, href))
                self.assertIn(m.group(1), valid, href)
        self.assertGreaterEqual(links, 8)
        self.assertIn("https://bible.bskorea.or.kr/bible/KRV/JHN.3", self.pages["index"])
        self.assertIn("https://bible.bskorea.or.kr/bible/KRV/PSA.23", self.pages["index"])

    def test_T7b_66권_책_코드_표가_온전하다(self):
        self.assertEqual(66, len(CODES))
        codes = [v["code"] for v in CODES.values()]
        self.assertEqual(66, len(set(codes)))
        self.assertEqual("JHN", CODES["43"]["code"])
        self.assertEqual("PSA", CODES["19"]["code"])

    def test_T5_쪽_용량은_1MB_이하이다(self):
        limit = CFG["rules"]["page_max_bytes"]
        worst = 0
        for d in self.res["built"]:
            total = sum(os.path.getsize(os.path.join(dp, f)) for dp, _, fs in os.walk(os.path.join(self.out, d)) for f in fs)
            worst = max(worst, total)
            self.assertLessEqual(total, limit, d)
        record_metric(ROOT, "가장 큰 주보 쪽 용량(바이트)", worst)

    def test_T4_외부_자원을_불러오지_않는다(self):
        for k, h in self.pages.items():
            self.assertNotRegex(h, r'<script[^>]+src=', k)
            self.assertNotRegex(h, r'<link[^>]+href=', k)
            self.assertNotRegex(h, r'<img[^>]+src="https?:', k)
            self.assertNotRegex(h, r'@import|url\(http', k)
            for href in re.findall(r'href="(https?://[^"]+)"', h):
                self.assertTrue(href.startswith("https://bible.bskorea.or.kr/"), href)

    def test_T2_글자_크기_버튼과_저장_실패_대비가_있다(self):
        for k, h in self.pages.items():
            for i in ("fs-down", "fs-reset", "fs-up", "fslabel"):
                self.assertIn('id="%s"' % i, h, k)
            self.assertIn("try{window.localStorage", h)
            self.assertIn("min-height:44px", h)
        self.assertIn("meta name=\"viewport\"", self.pages["index"])

    def test_T3_글자_크기는_가장_작아도_16px_이상이다(self):
        base = CFG["ui"]["base_px"]
        steps = CFG["ui"]["font_steps"]
        self.assertGreaterEqual(base + min(steps), 16)
        self.assertGreaterEqual(base + steps[1], 16)  # 기본 단계
        self.assertGreater(max(steps), 0)             # 키우는 단계가 있다

    def test_T3b_밝은_모드와_어두운_모드_모두_글자_대비가_충분하다(self):
        css = bulletin.CSS
        light = dict(re.findall(r"--(\w+):(#[0-9a-fA-F]{6})", css.split("@media")[0]))
        dark = dict(re.findall(r"--(\w+):(#[0-9a-fA-F]{6})", css.split("@media (prefers-color-scheme:dark)")[1].split("}")[0]))

        def lum(h):
            r, g, b = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
            f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
            return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)

        def ratio(a, b):
            la, lb = sorted((lum(a), lum(b)), reverse=True)
            return (la + 0.05) / (lb + 0.05)
        worst = 99
        for name, pal in (("밝은", light), ("어두운", dark)):
            for fg, bg in (("ink", "bg"), ("ink", "card"), ("sub", "card"), ("link", "card"), ("accent", "card")):
                r = ratio(pal[fg], pal[bg])
                worst = min(worst, r)
                self.assertGreaterEqual(r, 4.5, "%s 모드 %s/%s 대비 %.2f" % (name, fg, bg, r))
        record_metric(ROOT, "가장 낮은 글자 대비(WCAG, 기준 4.5)", round(worst, 2))

    def test_FR2_공유_미리보기_태그가_있다(self):
        for k, h in self.pages.items():
            for p in ("og:title", "og:description", "og:type", "og:locale"):
                self.assertIn('property="%s"' % p, h, k)

    def test_N5_공개_쪽에_동의_기록_같은_내부_칸이_새지_않는다(self):
        for k, h in self.pages.items():
            for w in ("consent", "guardian", "동의가 기록", "010-"):
                self.assertNotIn(w, h, "%s: %s" % (k, w))

    def test_N6_빌드는_원본_content_를_바꾸지_않는다(self):
        def snap(r):
            return {f: hashlib.sha256(open(os.path.join(r, "content", f), "rb").read()).hexdigest()
                    for f in sorted(os.listdir(os.path.join(r, "content")))}
        r = make_root("hash", ["2026-11-01"])
        before = snap(r)
        bulletin.build(r, out_dir=os.path.join(r, "docs"))
        self.assertEqual(before, snap(r))

    def test_H1_함정이_하나라도_있으면_docs_를_한_글자도_쓰지_않는다(self):
        r = make_root("gatefail", ["2026-11-01"])
        bad = json.load(open(os.path.join(ROOT, "samples", "trap", "trap_01_동의없음.json"), encoding="utf-8"))
        bad["date"] = "2026-11-08"
        with open(os.path.join(r, "content", "2026-11-08.json"), "w", encoding="utf-8") as f:
            json.dump(bad, f, ensure_ascii=False)
        out = os.path.join(r, "docs")
        with self.assertRaises(bulletin.GateError) as cm:
            bulletin.build(r, out_dir=out)
        self.assertIn("CONSENT_MISSING", [i.code for i in cm.exception.issues])
        self.assertFalse(os.path.exists(out), "중단됐는데 docs 가 만들어졌다")

    def test_FR5_지난_주보는_12주까지만_공개한다(self):
        dates = weekly("2026-01-04", 15)  # 15주치
        r = make_root("weeks", dates)
        res = bulletin.build(r, out_dir=os.path.join(r, "docs"))
        self.assertEqual(dates[-1], res["latest"])
        self.assertEqual(dates[-13:], res["built"])        # 가장 최근 주 + 거슬러 12주
        self.assertEqual(dates[:2], res["expired"])
        for d in res["expired"]:
            self.assertFalse(os.path.exists(os.path.join(r, "docs", d)), d)
        top = read(os.path.join(r, "docs", "index.html"))
        for d in res["expired"]:
            self.assertNotIn(d + "/index.html", top)
        self.assertEqual(12, len(re.findall(r'<li><a href="\d{4}-\d{2}-\d{2}/index\.html">', top)))

    def test_FR5b_만료_폴더는_사람이_prune_을_불러야_지워진다(self):
        dates = weekly("2026-01-04", 15)
        r = make_root("prune", dates)
        out = os.path.join(r, "docs")
        bulletin.build(r, out_dir=out)
        old = os.path.join(out, dates[0])
        os.makedirs(old)                      # 예전에 공개했던 폴더가 남아 있다고 치자
        res = bulletin.build(r, out_dir=out)  # 빌드는 지우지 않는다
        self.assertTrue(os.path.isdir(old))
        removed = bulletin.prune(out, set(res["built"]))
        self.assertEqual([dates[0]], removed)
        self.assertFalse(os.path.isdir(old))

    def test_S2_운영_docs_에_만료된_주보가_없다(self):
        """저장소의 docs/ 에 12주를 넘은 폴더가 남아 있으면 안 된다."""
        docs = os.path.join(ROOT, "docs")
        if not os.path.isdir(docs):
            self.skipTest("docs 가 아직 없다")
        dates = [n for n in os.listdir(docs) if re.fullmatch(r"\d{4}-\d{2}-\d{2}", n)]
        self.assertEqual([], bulletin.expired_weeks(dates, CFG["keep_weeks"]))


if __name__ == "__main__":
    unittest.main()
