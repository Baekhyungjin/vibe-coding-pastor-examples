# -*- coding: utf-8 -*-
"""게시 전 검사기 시험: 골든은 통과, 함정은 '정확히 그 이유로' 중단 (S3, N1~N4 대응)."""
import copy
import json
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import publish_gate  # noqa: E402
import excel_in  # noqa: E402
from verify_core import record_metric  # noqa: E402

CFG = json.load(open(os.path.join(ROOT, "config", "church.json"), encoding="utf-8"))
GOLD = os.path.join(ROOT, "samples", "golden")
TRAP = os.path.join(ROOT, "samples", "trap")
TMP = os.path.join(ROOT, "output", "_t_gate")


def load(path):
    with open(path, encoding="utf-8") as f:
        return json.load(f)


class GateTests(unittest.TestCase):
    def test_S3_골든_주보는_통과한다(self):
        names = sorted(n for n in os.listdir(GOLD) if n.endswith(".json"))
        self.assertGreaterEqual(len(names), 2)
        for n in names:
            issues = publish_gate.check(load(os.path.join(GOLD, n)), CFG)
            self.assertEqual([], [str(i) for i in issues], n)

    def test_H1_함정은_하나도_빠짐없이_중단된다(self):
        expected = load(os.path.join(TRAP, "expected.json"))
        files = sorted(n for n in os.listdir(TRAP) if n.startswith("trap_"))
        self.assertGreaterEqual(len(files), 10)
        self.assertEqual(sorted(files), sorted(expected), "expected.json 에 없는 함정이 있다")
        passed = [n for n in files if not publish_gate.check(load(os.path.join(TRAP, n)), CFG)]
        self.assertEqual([], passed, "검사기가 통과시킨 함정: %s" % passed)
        record_metric(ROOT, "함정 샘플 수", len(files))

    def test_H2_함정은_엉뚱한_이유가_아니라_정해진_이유로_걸린다(self):
        expected = load(os.path.join(TRAP, "expected.json"))
        wrong = {}
        for n, codes in expected.items():
            got = publish_gate.codes(publish_gate.check(load(os.path.join(TRAP, n)), CFG))
            if got != sorted(codes):
                wrong[n] = {"기대": sorted(codes), "실제": got}
        self.assertEqual({}, wrong, "이유가 다른 함정: %s" % json.dumps(wrong, ensure_ascii=False))

    def test_N1_병환_기도제목_헌금자명단은_동의가_있어도_거부한다(self):
        base = load(os.path.join(GOLD, "golden_01_기본.json"))
        for kind in ("병환", "기도제목", "헌금자명단", "헌금", "심방", "상담"):
            c = copy.deepcopy(base)
            c["news"] = [{"kind": kind, "text": "가상 소식입니다.", "consent": True}]
            self.assertIn(publish_gate.KIND_FORBIDDEN, publish_gate.codes(publish_gate.check(c, CFG)), kind)

    def test_N2_동의는_true_일_때만_인정한다(self):
        base = load(os.path.join(GOLD, "golden_01_기본.json"))
        for bad in (False, None, "true", "예", 1, 0, ""):
            c = copy.deepcopy(base)
            c["news"][0]["consent"] = bad
            self.assertIn(publish_gate.CONSENT_MISSING, publish_gate.codes(publish_gate.check(c, CFG)), repr(bad))

    def test_N3_성경_인용은_세_절까지만(self):
        base = load(os.path.join(GOLD, "golden_02_세절인용_소식없음.json"))
        self.assertEqual([], publish_gate.check(base, CFG))
        c = copy.deepcopy(base)
        c["scripture_quotes"][0]["ref"] = "시 23:1-4"
        self.assertIn(publish_gate.SCRIPTURE_TOO_LONG, publish_gate.codes(publish_gate.check(c, CFG)))
        c["scripture_quotes"][0]["ref"] = "시 23편"  # 장 전체 = 6절
        self.assertIn(publish_gate.SCRIPTURE_TOO_LONG, publish_gate.codes(publish_gate.check(c, CFG)))

    def test_N3b_개역개정이나_허가_안된_번역본은_거부한다(self):
        base = load(os.path.join(GOLD, "golden_01_기본.json"))
        for tr in ("개역개정", "새번역", "NIV"):
            c = copy.deepcopy(base)
            c["scripture_quotes"][0]["translation"] = tr
            self.assertIn(publish_gate.TRANSLATION_NOT_ALLOWED, publish_gate.codes(publish_gate.check(c, CFG)), tr)

    def test_N4_인용_칸_밖에_성경_본문이_있으면_거부한다(self):
        base = load(os.path.join(GOLD, "golden_01_기본.json"))
        for body in ("여호와는 나의 목자시니 내가 부족함이 없으리로다",
                     "그가 나를 푸른 초장에 누이시며 쉴만한 물 가으로 인도하시는도다"):
            c = copy.deepcopy(base)
            c["announcements"].append({"title": "말씀", "body": body})
            self.assertIn(publish_gate.SCRIPTURE_IN_FREETEXT, publish_gate.codes(publish_gate.check(c, CFG)), body)

    def test_N5_설정을_몰래_느슨하게_하면_걸린다(self):
        """게시 규칙 설정(config)은 승인 대상이다. 규칙을 약하게 바꾼 설정을 바로 알아챈다."""
        r = CFG["rules"]
        self.assertLessEqual(r["scripture_max_verses"], 3)
        for kind in ("병환", "기도제목", "헌금자명단"):
            self.assertIn(kind, r["news_kinds_forbidden"])
        self.assertEqual(["개역한글"], CFG["translations_allowed"])
        self.assertTrue(CFG["noindex"])
        self.assertLessEqual(CFG["keep_weeks"], 12)

    def test_FR1_엑셀_양식도_같은_검사를_받는다(self):
        c = excel_in.load_xlsx(os.path.join(GOLD, "golden_03_엑셀양식.xlsx"))
        self.assertEqual("2026-11-08", c["date"])
        self.assertEqual([], [str(i) for i in publish_gate.check(c, CFG)])
        self.assertEqual(5, len(c["order"]))

    def test_FR1b_엑셀에서_동의_칸이_비면_걸린다(self):
        import openpyxl
        os.makedirs(TMP, exist_ok=True)
        wb = openpyxl.load_workbook(os.path.join(GOLD, "golden_03_엑셀양식.xlsx"))
        wb["소식"]["C2"] = None
        p = os.path.join(TMP, "no_consent.xlsx")
        wb.save(p)
        c = excel_in.load_xlsx(p)
        self.assertIn(publish_gate.CONSENT_MISSING, publish_gate.codes(publish_gate.check(c, CFG)))


if __name__ == "__main__":
    unittest.main()
