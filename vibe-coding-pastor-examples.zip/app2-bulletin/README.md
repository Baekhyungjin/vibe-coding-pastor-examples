# app2-bulletin: 모바일 주보 생성기 (가상교회)

파이썬 3.13 표준 라이브러리와 openpyxl 만 쓴다. 모든 교회 이름, 인물, 번호는 설명용으로 지어낸 것이다.

```
python scripts/make_samples.py   # 가짜 샘플 만들기 (승인 뒤에는 다시 실행하지 않는다)
python scripts/build.py          # content/ 를 검사하고 docs/ 를 만든다 (검사에 걸리면 docs/ 는 그대로)
python scripts/build.py --check-only
python scripts/build.py --prune  # 12주를 넘은 공개 폴더를 지운다 (사람이 직접)
python scripts/verify.py         # 하네스. 마지막 줄 RESULT: PASSED (n/n)
```

| 위치 | 하는 일 |
| --- | --- |
| `content/YYYY-MM-DD.json` | 이번 주 입력 (예배 순서, 설교 본문 장절, 광고, 교인 소식, 사진) |
| `config/church.json` | 교회 설정과 게시 규칙(rules). 규칙은 승인 대상 |
| `src/publish_gate.py` | 게시 전 검사기. 걸리면 빌드 중단 |
| `src/bulletin.py` | HTML 생성 (직접 쓴 CSS, 빌드 도구 없음) |
| `src/excel_in.py` | 엑셀 양식을 같은 구조로 읽기 |
| `data/bible_codes.json` | 66권 책 코드 (bible.bskorea.or.kr 개역한글판 주소로 모두 확인) |
| `lib/` | 장절 파서와 범위표 (예제/common 에서 복사) |
| `docs/` | 공개용 결과 (GitHub Pages 에 올리는 폴더) |
| `scripts/browser_check.js.txt` | 브라우저 폭별 검사 방법 (Aside REPL) |
| `output/browser_report.json`, `output/screens/` | 브라우저 검사 결과와 모바일 화면 |

## 한계
- 동의서를 실제로 받았는지는 알 수 없다. consent 칸이 true 인지만 본다.
- 개역한글 본문 인용 칸은 번역본 이름과 절 수만 본다. 글자 대조는 예제/common 의 bible_store 로 따로 한다(Ch 6).
- 찬송 가사 검사는 "짧은 줄 4줄 이상"과 칸 이름으로 잡는 휴리스틱이라 놓칠 수 있다.
- 다크 모드와 글자 크기 저장(localStorage)은 이 PC 의 브라우저 검사에서 확인하지 못했다.
- GitHub Pages 실제 배포는 해 보지 못했다.