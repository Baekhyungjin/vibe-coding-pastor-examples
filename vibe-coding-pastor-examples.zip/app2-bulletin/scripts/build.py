# -*- coding: utf-8 -*-
"""주보 빌드 명령

    python scripts/build.py                  # content/ 전체를 검사하고 docs/ 를 만든다
    python scripts/build.py --check-only     # 검사만
    python scripts/build.py --prune          # 12주를 넘은 공개 주보 폴더를 지운다 (사람이 직접 실행)
"""
import os
import sys

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "src"))

import bulletin  # noqa: E402
import publish_gate  # noqa: E402


def main(argv):
    root = ROOT
    try:
        if "--check-only" in argv:
            cfg = bulletin.load_config(root)
            import json
            bad = []
            for d in bulletin.list_content(root):
                c = json.load(open(os.path.join(root, "content", d + ".json"), encoding="utf-8"))
                bad += publish_gate.check(c, cfg)
            if bad:
                raise bulletin.GateError(bad)
            print("게시 전 검사 통과")
            return 0
        res = bulletin.build(root)
    except bulletin.GateError as e:
        print("빌드 중단: 게시 전 검사에 걸렸습니다. docs/ 는 바꾸지 않았습니다.", file=sys.stderr)
        for it in e.issues:
            print("  ", it, file=sys.stderr)
        return 2
    print("빌드 완료:", ", ".join(res["built"]))
    print("최신 주보:", res["latest"])
    if res["expired"]:
        print("공개 폴더에서 내려야 할 만료 주보:", ", ".join(res["expired"]), "(--prune 으로 지움)")
    if "--prune" in argv:
        keep = set(res["built"])
        removed = bulletin.prune(os.path.join(root, "docs"), keep)
        print("지운 폴더:", ", ".join(removed) or "없음")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
