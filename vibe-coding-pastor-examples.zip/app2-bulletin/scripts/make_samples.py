# -*- coding: utf-8 -*-
"""가짜 샘플 만들기 (골든 주보, 함정 주보, 사진, 엑셀 양식). 모두 지어낸 데이터다.

    python scripts/make_samples.py

승인(봉인) 뒤에는 다시 실행하지 않는다. samples/ 와 tests/ 는 AI 가 고치지 않는다.
"""
import copy
import json
import os
import struct
import sys
import zlib

sys.dont_write_bytecode = True
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")


def make_png(path, w, h, c1, c2):
    """가로 줄무늬 그라데이션 PNG (표준 라이브러리만)."""
    rows = []
    for y in range(h):
        t = y / (h - 1)
        px = bytes(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
        rows.append(b"\x00" + px * w)
    raw = b"".join(rows)

    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(png)


def golden(date, title, sermon_title, hymn_a, hymn_b):
    return {
        "date": date,
        "title": title,
        "sermon": {"title": sermon_title, "passage": "요 3:16-21", "preacher": "김 목사"},
        "order": [
            {"name": "묵도"},
            {"name": "찬송", "hymn": {"no": hymn_a, "title": "(예시) 아침 찬송"}},
            {"name": "대표 기도", "note": "가상 성도 A"},
            {"name": "성경 봉독", "ref": "요 3:16-21"},
            {"name": "설교", "note": sermon_title},
            {"name": "찬송", "hymn": {"no": hymn_b, "title": "(예시) 결단의 찬송"}},
            {"name": "봉헌"},
            {"name": "광고"},
            {"name": "축도"},
        ],
        "scripture_quotes": [
            {"ref": "요 3:16", "translation": "개역한글",
             "text": "하나님이 세상을 이처럼 사랑하사 독생자를 주셨으니 이는 저를 믿는 자마다 멸망치 않고 영생을 얻게 하려 하심이니라"}
        ],
        "announcements": [
            {"title": "새벽기도회", "body": "월요일부터 토요일까지 오전 5시 30분입니다. 이번 주 말씀은 시 23편입니다."},
            {"title": "주일 오후 모임", "body": "예배 후 2층 교육관에서 점심을 함께 나눕니다. 가상 교회의 예시 광고입니다."},
            {"title": "가을 일손 돕기", "body": "다음 주 토요일 오전 10시, 교회 앞마당에서 모입니다. 장갑을 준비해 주세요."},
        ],
        "news": [
            {"kind": "새가족환영", "text": "가상 성도 B 가정이 새가족으로 등록하셨습니다. 환영합니다.", "consent": True},
            {"kind": "경조소식", "text": "가상 성도 C 가정에 아기가 태어났습니다. 함께 기뻐합니다.", "consent": True},
        ],
        "photos": [
            {"file": "photos/autumn_yard.png", "alt": "가을 햇살이 비치는 교회 앞마당의 그림(예시 이미지)",
             "caption": "교회 앞마당 (예시 이미지)", "width": 640, "height": 360, "child": False, "guardian_consent": None}
        ],
    }


def main():
    # 사진 (가짜 그라데이션 이미지)
    make_png(os.path.join(ROOT, "photos", "autumn_yard.png"), 640, 360, (236, 196, 120), (120, 150, 90))

    # 운영용 content: 3주치
    write_json(os.path.join(ROOT, "content", "2026-10-18.json"), golden("2026-10-18", "", "빛으로 오신 예수", 12, 34))
    write_json(os.path.join(ROOT, "content", "2026-10-25.json"), golden("2026-10-25", "", "빛 가운데 걷는 삶", 15, 40))
    write_json(os.path.join(ROOT, "content", "2026-11-01.json"), golden("2026-11-01", "", "감사로 드리는 예배", 20, 41))

    # 골든 샘플 (검사기를 통과해야 한다)
    g = golden("2026-11-01", "", "감사로 드리는 예배", 20, 41)
    write_json(os.path.join(ROOT, "samples", "golden", "golden_01_기본.json"), g)
    g2 = copy.deepcopy(g)
    g2["date"] = "2026-11-08"
    g2["scripture_quotes"] = [{"ref": "시 23:1-3", "translation": "개역한글",
                               "text": "여호와는 나의 목자시니 내가 부족함이 없으리로다 그가 나를 푸른 초장에 누이시며 쉴만한 물 가으로 인도하시는도다 내 영혼을 소생시키시고 자기 이름을 위하여 의의 길로 인도하시는도다"}]
    g2["news"] = []
    g2["photos"] = []
    write_json(os.path.join(ROOT, "samples", "golden", "golden_02_세절인용_소식없음.json"), g2)

    # 함정 샘플: 파일 하나가 정확히 한 가지 이유로만 걸려야 한다
    traps = {}

    def trap(name, codes, mutate):
        c = copy.deepcopy(g)
        c["date"] = "2026-12-06"
        mutate(c)
        write_json(os.path.join(ROOT, "samples", "trap", name), c)
        traps[name] = codes

    trap("trap_01_동의없음.json", ["CONSENT_MISSING"], lambda c: c["news"][0].update(consent=False))
    trap("trap_02_동의칸없음.json", ["CONSENT_MISSING"], lambda c: c["news"][0].pop("consent"))
    trap("trap_03_병환소식.json", ["KIND_FORBIDDEN"],
         lambda c: c["news"].append({"kind": "병환", "text": "가상 성도 D 가정에 위로를 전합니다.", "consent": True}))
    trap("trap_04_기도제목.json", ["KIND_FORBIDDEN"],
         lambda c: c["news"].append({"kind": "기도제목", "text": "가상 성도 E의 기도제목을 나눕니다.", "consent": True}))
    trap("trap_05_헌금자명단.json", ["KIND_FORBIDDEN"],
         lambda c: c["news"].append({"kind": "헌금자명단", "text": "이번 주 감사헌금 명단입니다.", "consent": True}))
    trap("trap_06_민감낱말.json", ["SENSITIVE_WORD"],
         lambda c: c["news"].append({"kind": "경조소식", "text": "가상 성도 F께서 수술을 앞두고 계십니다.", "consent": True}))
    trap("trap_07_가사의심_네줄.json", ["LYRICS_SUSPECT"],
         lambda c: c["announcements"].append({"title": "함께 부르는 노래", "body": "가나다라 마바사\n아자차카 타파하\n하나 둘 셋 넷\n다섯 여섯 일곱"}))
    trap("trap_08_가사칸.json", ["FORBIDDEN_FIELD"],
         lambda c: c["order"][1]["hymn"].update(lyrics="가상 가사 한 줄"))
    trap("trap_09_본문4절.json", ["SCRIPTURE_TOO_LONG"], lambda c: c.update(scripture_quotes=[
        {"ref": "시 23:1-4", "translation": "개역한글",
         "text": "여호와는 나의 목자시니 내가 부족함이 없으리로다 그가 나를 푸른 초장에 누이시며 쉴만한 물 가으로 인도하시는도다 내 영혼을 소생시키시고 자기 이름을 위하여 의의 길로 인도하시는도다"}]))
    trap("trap_10_광고칸에본문.json", ["SCRIPTURE_IN_FREETEXT"],
         lambda c: c["announcements"].append({"title": "오늘의 말씀", "body": "여호와는 나의 목자시니 내가 부족함이 없으리로다 그가 나를 푸른 초장에 누이시며"}))
    trap("trap_11_개역개정표기.json", ["TRANSLATION_NOT_ALLOWED"],
         lambda c: c.update(scripture_quotes=[{"ref": "요 3:16", "translation": "개역개정", "text": "(허가 없이 쓸 수 없는 번역본을 가정한 예시 문장입니다)"}]))
    trap("trap_12_번역본표기없음.json", ["TRANSLATION_MISSING"], lambda c: c["scripture_quotes"][0].pop("translation"))
    trap("trap_13_어린이사진.json", ["CHILD_PHOTO_NO_GUARDIAN"], lambda c: c["photos"][0].update(child=True, guardian_consent=None))
    trap("trap_14_사진대체글없음.json", ["PHOTO_ALT_MISSING"], lambda c: c["photos"][0].update(alt=""))
    trap("trap_15_전화번호.json", ["PHONE_IN_PUBLIC"],
         lambda c: c["announcements"].append({"title": "문의", "body": "가상 성도 G에게 010-1234-5678 로 연락하세요."}))
    trap("trap_16_없는장절.json", ["INVALID_REF"], lambda c: c["sermon"].update(passage="유 1:30"))
    trap("trap_17_찬송번호범위밖.json", ["HYMN_NO_RANGE"], lambda c: c["order"][1]["hymn"].update(no=999))
    write_json(os.path.join(ROOT, "samples", "trap", "expected.json"), traps)

    # 엑셀 양식 (같은 내용을 JSON 대신 표로)
    import openpyxl
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "기본"
    ws.append(["항목", "값"])
    for k, v in [("날짜", "2026-11-08"), ("제목", ""), ("설교제목", "감사의 고백"), ("본문", "시 23:1-6"), ("설교자", "김 목사")]:
        ws.append([k, v])
    ws2 = wb.create_sheet("순서")
    ws2.append(["순서이름", "찬송장", "찬송제목", "장절", "메모"])
    ws2.append(["묵도", None, None, None, None])
    ws2.append(["찬송", 15, "(예시) 아침 찬송", None, None])
    ws2.append(["성경 봉독", None, None, "시 23:1-6", None])
    ws2.append(["설교", None, None, None, "감사의 고백"])
    ws2.append(["축도", None, None, None, None])
    ws3 = wb.create_sheet("광고")
    ws3.append(["제목", "내용"])
    ws3.append(["새벽기도회", "오전 5시 30분입니다. 이번 주 말씀은 시 23편입니다."])
    ws4 = wb.create_sheet("소식")
    ws4.append(["종류", "내용", "동의(예/아니오)"])
    ws4.append(["새가족환영", "가상 성도 H 가정을 환영합니다.", "예"])
    os.makedirs(os.path.join(ROOT, "samples", "golden"), exist_ok=True)
    wb.save(os.path.join(ROOT, "samples", "golden", "golden_03_엑셀양식.xlsx"))
    print("샘플을 만들었습니다:", len(traps), "개 함정, 골든 3개, 사진 1개, 운영 content 3주")


if __name__ == "__main__":
    main()
