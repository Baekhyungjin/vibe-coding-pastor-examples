# -*- coding: utf-8 -*-
"""주보 생성기: content/YYYY-MM-DD.json -> docs/YYYY-MM-DD/index.html (+ docs/index.html)

빌드 없는 정적 HTML 한 장. 게시 전 검사기(publish_gate)를 통과하지 못하면 아무것도 쓰지 않는다.
"""
import datetime
import html
import json
import os
import re
import shutil
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "lib"))
import canon as canon_mod  # noqa: E402
import refparse  # noqa: E402
import publish_gate  # noqa: E402


class GateError(Exception):
    def __init__(self, issues):
        self.issues = issues
        super().__init__("게시 전 검사 실패: " + ", ".join(sorted({i.code for i in issues})))


def load_config(root=ROOT):
    with open(os.path.join(root, "config", "church.json"), encoding="utf-8") as f:
        return json.load(f)


def load_codes(cfg, root=ROOT):
    with open(os.path.join(root, cfg["bible"]["codes_file"]), encoding="utf-8") as f:
        return json.load(f)["by_id"]


def esc(s):
    return html.escape(str(s), quote=True)


WEEKDAY = "월화수목금토일"


def korean_date(d):
    dt = datetime.date.fromisoformat(d)
    return "%d년 %d월 %d일 %s요일" % (dt.year, dt.month, dt.day, WEEKDAY[dt.weekday()])


# ------------------------------------------------------------ 성경 링크
def bible_url(ref, cfg, codes):
    """장 단위 주소. 책 코드는 data/bible_codes.json (66권 확인)."""
    if ref.book is None or str(ref.book.id) not in codes:
        return None
    return cfg["bible"]["link_template"].format(code=codes[str(ref.book.id)]["code"], chapter=ref.c1)


def linkify(text, cfg, codes, parser):
    """글 속의 장절을 성경 사이트 링크로 바꾼다. 나머지는 이스케이프."""
    out, pos = [], 0
    for ref in parser.parse(text):
        if ref.start < pos:
            continue
        out.append(esc(text[pos:ref.start]))
        url = bible_url(ref, cfg, codes)
        label = esc(text[ref.start:ref.end])
        if url:
            out.append('<a class="ref" href="%s" target="_blank" rel="noopener noreferrer">%s</a>' % (esc(url), label))
        else:
            out.append(label)
        pos = ref.end
    out.append(esc(text[pos:]))
    return "".join(out)


# ------------------------------------------------------------ HTML 조각
CSS = """
:root{--fs:17px;--bg:#fbf8f1;--card:#ffffff;--ink:#23201b;--sub:#6a645a;--line:#e4dccb;--accent:#8a4b1f;--link:#1f5fa8}
@media (prefers-color-scheme:dark){:root{--bg:#171512;--card:#211e1a;--ink:#efe9dd;--sub:#b7ae9e;--line:#3a352d;--accent:#e0a56f;--link:#8fbcf0}}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font-family:"Malgun Gothic","Apple SD Gothic Neo","Noto Sans KR",sans-serif;font-size:var(--fs);line-height:1.7;word-break:keep-all;overflow-wrap:anywhere}
.wrap{max-width:640px;margin:0 auto;padding:12px 14px 40px}
header.top{padding:18px 4px 6px}
.church{font-size:.9em;color:var(--sub);letter-spacing:.04em}
h1{font-size:1.45em;line-height:1.35;margin:.2em 0 .1em}
.date{color:var(--sub);font-size:.95em}
.tools{display:flex;gap:8px;align-items:center;margin:10px 0 4px}
.tools span{font-size:.85em;color:var(--sub)}
.tools button{font:inherit;font-size:.95em;min-width:44px;min-height:44px;border:1px solid var(--line);background:var(--card);color:var(--ink);border-radius:10px;cursor:pointer}
section.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:14px 16px;margin:14px 0}
h2{font-size:1.1em;margin:0 0 .5em;color:var(--accent)}
ol.order{list-style:none;margin:0;padding:0}
ol.order li{display:flex;gap:10px;padding:8px 0;border-top:1px solid var(--line)}
ol.order li:first-child{border-top:0}
.n{flex:none;width:2.4em;color:var(--sub);font-variant-numeric:tabular-nums}
.step b{font-weight:700}
.step small{display:block;color:var(--sub)}
a.ref{color:var(--link);text-decoration:underline;text-underline-offset:3px}
.sermon{font-size:1.05em}
.sermon .t{font-weight:700;font-size:1.1em}
blockquote.q{margin:.6em 0 0;padding:.6em .9em;border-left:4px solid var(--accent);background:rgba(138,75,31,.07);border-radius:6px}
blockquote.q cite{display:block;margin-top:.3em;font-style:normal;font-size:.85em;color:var(--sub)}
.ad+.ad{border-top:1px solid var(--line);margin-top:.7em;padding-top:.7em}
.ad .t{font-weight:700}
.news .tag{display:inline-block;font-size:.78em;padding:0 .6em;border:1px solid var(--line);border-radius:99px;color:var(--sub);margin-right:.4em}
figure{margin:.8em 0 0}
figure img{display:block;width:100%;height:auto;border-radius:10px}
figcaption{font-size:.85em;color:var(--sub);margin-top:.3em}
nav.past ul{list-style:none;margin:0;padding:0}
nav.past li{border-top:1px solid var(--line)}
nav.past li:first-child{border-top:0}
nav.past a{display:block;padding:10px 2px;min-height:44px;color:var(--link)}
footer{font-size:.82em;color:var(--sub);margin-top:22px}
footer p{margin:.3em 0}
"""

JS = """
(function(){
  var KEY='bulletin-font-step', steps=%STEPS%, base=%BASE%, i=1;
  try{var s=parseInt(window.localStorage.getItem(KEY),10); if(s>=0&&s<steps.length) i=s;}catch(e){}
  function apply(){document.documentElement.style.setProperty('--fs',(base+steps[i])+'px');
    var l=document.getElementById('fslabel'); if(l) l.textContent=(base+steps[i])+'px';}
  function set(n){ if(n<0||n>=steps.length) return; i=n; apply(); try{window.localStorage.setItem(KEY,String(i));}catch(e){} }
  document.getElementById('fs-down').addEventListener('click',function(){set(i-1)});
  document.getElementById('fs-reset').addEventListener('click',function(){set(1)});
  document.getElementById('fs-up').addEventListener('click',function(){set(i+1)});
  apply();
})();
"""


def render_order(content, cfg, codes, parser):
    items = []
    for n, step in enumerate(content.get("order", []), 1):
        name = esc(step.get("name", ""))
        detail = []
        if step.get("hymn"):
            h = step["hymn"]
            detail.append("%s %d장 %s" % (esc(cfg["hymnal"]["name"]), h["no"], esc(h["title"])))
        if step.get("ref"):
            detail.append(linkify(step["ref"], cfg, codes, parser))
        if step.get("note"):
            detail.append(esc(step["note"]))
        small = "<small>%s</small>" % " · ".join(detail) if detail else ""
        items.append('<li><span class="n">%d</span><span class="step"><b>%s</b>%s</span></li>' % (n, name, small))
    return '<section class="card" aria-labelledby="h-order"><h2 id="h-order">예배 순서</h2><ol class="order">%s</ol></section>' % "".join(items)


def render_sermon(content, cfg, codes, parser):
    s = content["sermon"]
    parts = ['<div class="t">%s</div>' % esc(s.get("title", ""))]
    if s.get("passage"):
        parts.append("<div>본문 %s</div>" % linkify(s["passage"], cfg, codes, parser))
    if s.get("preacher"):
        parts.append('<div class="date">%s</div>' % esc(s["preacher"]))
    q_html = []
    for q in content.get("scripture_quotes", []):
        q_html.append('<blockquote class="q">%s<cite>%s (%s)</cite></blockquote>' % (
            esc(q.get("text", "")), linkify(q.get("ref", ""), cfg, codes, parser), esc(q.get("translation", ""))))
    return '<section class="card sermon" aria-labelledby="h-sermon"><h2 id="h-sermon">말씀</h2>%s%s</section>' % ("".join(parts), "".join(q_html))


def render_ads(content, cfg, codes, parser):
    ads = content.get("announcements", [])
    if not ads:
        return ""
    rows = []
    for a in ads:
        body = "<div>%s</div>" % linkify(a.get("body", ""), cfg, codes, parser) if a.get("body") else ""
        rows.append('<div class="ad"><div class="t">%s</div>%s</div>' % (esc(a.get("title", "")), body))
    return '<section class="card" aria-labelledby="h-ad"><h2 id="h-ad">광고</h2>%s</section>' % "".join(rows)


def render_news(content, cfg, codes, parser, photo_prefix=""):
    news = content.get("news", [])
    photos = content.get("photos", [])
    if not news and not photos:
        return ""
    rows = []
    for n in news:
        rows.append('<div class="ad news"><div><span class="tag">%s</span>%s</div></div>' % (
            esc(n.get("kind", "")), linkify(n.get("text", ""), cfg, codes, parser)))
    figs = []
    for p in photos:
        figs.append('<figure><img src="%s%s" alt="%s" loading="lazy"%s><figcaption>%s</figcaption></figure>' % (
            esc(photo_prefix), esc(p["file"]), esc(p["alt"]),
            ' width="%d" height="%d"' % (p["width"], p["height"]) if p.get("width") and p.get("height") else "",
            esc(p.get("caption", p["alt"]))))
    return '<section class="card" aria-labelledby="h-news"><h2 id="h-news">교우 소식</h2>%s%s</section>' % ("".join(rows), "".join(figs))


def render_past(past, cfg, prefix):
    if not past:
        return ""
    lis = "".join('<li><a href="%s%s/index.html">%s 주보</a></li>' % (prefix, d, esc(korean_date(d))) for d in past)
    return '<nav class="card past" aria-labelledby="h-past"><h2 id="h-past">지난 주보 (최근 %d주)</h2><ul>%s</ul></nav>' % (cfg["keep_weeks"], lis)


def render_page(content, cfg, codes, past=(), prefix="", photo_prefix=""):
    parser = refparse.Parser(canon_mod.load())
    d = content["date"]
    title = content.get("title") or "%s 주보" % korean_date(d)
    desc = "%s %s 주보. 예배 순서와 광고, 교우 소식." % (cfg["church_name"], korean_date(d))
    sermon_title = (content.get("sermon") or {}).get("title", "")
    og_desc = desc + (" 설교: %s" % sermon_title if sermon_title else "")
    robots = '<meta name="robots" content="noindex, nofollow">' if cfg.get("noindex", True) else ""
    steps = json.dumps(cfg["ui"]["font_steps"])
    js = JS.replace("%STEPS%", steps).replace("%BASE%", str(cfg["ui"]["base_px"]))
    css = CSS.replace("--fs:17px", "--fs:%dpx" % cfg["ui"]["base_px"])
    body = [
        '<header class="top"><div class="church">%s</div><h1>%s</h1><div class="date">%s</div>'
        '<div class="tools" role="group" aria-label="글자 크기"><span>글자</span>'
        '<button type="button" id="fs-down" aria-label="글자 작게">가-</button>'
        '<button type="button" id="fs-reset" aria-label="글자 기본 크기">가</button>'
        '<button type="button" id="fs-up" aria-label="글자 크게">가+</button>'
        '<span id="fslabel" aria-live="polite"></span></div></header>' % (esc(cfg["church_name"]), esc(title), esc(korean_date(d))),
        render_sermon(content, cfg, codes, parser),
        render_order(content, cfg, codes, parser),
        render_ads(content, cfg, codes, parser),
        render_news(content, cfg, codes, parser, photo_prefix),
        render_past(past, cfg, prefix),
        '<footer><p>성경 장절을 누르면 대한성서공회 성경플랫폼(%s)으로 이동합니다.</p>'
        '<p>이 주보에는 찬송 가사와 성경 본문 전문을 싣지 않습니다.</p><p>%s</p></footer>' % (esc(cfg["bible"]["link_version_label"]), esc(cfg["church_contact"])),
    ]
    return ("<!doctype html>\n<html lang=\"%s\"><head><meta charset=\"utf-8\">"
            "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
            "<title>%s | %s</title>%s"
            "<meta name=\"description\" content=\"%s\">"
            "<meta property=\"og:type\" content=\"website\"><meta property=\"og:locale\" content=\"ko_KR\">"
            "<meta property=\"og:site_name\" content=\"%s\"><meta property=\"og:title\" content=\"%s\">"
            "<meta property=\"og:description\" content=\"%s\">"
            "<meta name=\"color-scheme\" content=\"light dark\"><style>%s</style></head>"
            "<body><div class=\"wrap\">%s</div><script>%s</script></body></html>\n") % (
        cfg["language"], esc(title), esc(cfg["church_name"]), robots, esc(desc), esc(cfg["church_name"]),
        esc(title), esc(og_desc), css, "".join(body), js)


# ------------------------------------------------------------ 빌드
def list_content(root):
    cdir = os.path.join(root, "content")
    return sorted(f[:-5] for f in os.listdir(cdir) if re.fullmatch(r"\d{4}-\d{2}-\d{2}\.json", f))


def expired_weeks(dates, keep_weeks):
    """가장 최근 주를 기준으로 keep_weeks 주를 넘은 날짜들 (공개 폴더에서 내려야 할 주보)."""
    if not dates:
        return []
    latest = datetime.date.fromisoformat(max(dates))
    limit = latest - datetime.timedelta(weeks=keep_weeks)
    return sorted(d for d in dates if datetime.date.fromisoformat(d) < limit)


def build(root=ROOT, out_dir=None, content_dir=None, today=None):
    """content 폴더의 모든 주보를 검사하고 빌드한다. 하나라도 걸리면 아무것도 쓰지 않는다."""
    cfg = load_config(root)
    codes = load_codes(cfg, root)
    cdir = content_dir or os.path.join(root, "content")
    out = out_dir or os.path.join(root, "docs")
    dates = sorted(f[:-5] for f in os.listdir(cdir) if re.fullmatch(r"\d{4}-\d{2}-\d{2}\.json", f))
    if not dates:
        raise FileNotFoundError("content 폴더에 주보 파일이 없습니다")
    contents, all_issues = {}, []
    for d in dates:
        with open(os.path.join(cdir, d + ".json"), encoding="utf-8") as f:
            c = json.load(f)
        if c.get("date") != d:
            all_issues.append(publish_gate.Issue(publish_gate.DATE_INVALID, d, "파일 이름과 date 가 다릅니다"))
        all_issues.extend(publish_gate.check(c, cfg))
        contents[d] = c
    if all_issues:
        raise GateError(all_issues)
    expired = set(expired_weeks(dates, cfg["keep_weeks"]))
    shown = [d for d in dates if d not in expired]
    latest = shown[-1]
    os.makedirs(out, exist_ok=True)
    for d in shown:
        past = [x for x in reversed(shown) if x != d]
        page_dir = os.path.join(out, d)
        os.makedirs(page_dir, exist_ok=True)
        for p in contents[d].get("photos", []):
            src = os.path.join(root, p["file"])
            dst = os.path.join(page_dir, p["file"])
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
        page = render_page(contents[d], cfg, codes, past=[x for x in past], prefix="../", photo_prefix="")
        with open(os.path.join(page_dir, "index.html"), "w", encoding="utf-8", newline="\n") as f:
            f.write(page)
    # 최신 주보 = docs/index.html
    top_past = [x for x in reversed(shown) if x != latest]
    top = render_page(contents[latest], cfg, codes, past=top_past, prefix="", photo_prefix=latest + "/")
    with open(os.path.join(out, "index.html"), "w", encoding="utf-8", newline="\n") as f:
        f.write(top)
    return {"built": shown, "latest": latest, "expired": sorted(expired)}


def prune(out_dir, keep_dates):
    """공개 폴더에서 만료된 주보 폴더를 지운다. 사람이 명시적으로 부를 때만."""
    removed = []
    for name in sorted(os.listdir(out_dir)):
        p = os.path.join(out_dir, name)
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", name) and os.path.isdir(p) and name not in keep_dates:
            shutil.rmtree(p)
            removed.append(name)
    return removed
