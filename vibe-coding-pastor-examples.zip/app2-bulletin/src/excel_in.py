# -*- coding: utf-8 -*-
"""엑셀 입력 양식 -> content JSON 과 같은 dict (openpyxl 로 읽기만 한다)

시트 구성(첫 줄은 제목 줄):
  기본   : 항목 | 값           날짜, 제목, 설교제목, 본문, 설교자
  순서   : 순서이름 | 찬송장 | 찬송제목 | 장절 | 메모
  광고   : 제목 | 내용
  소식   : 종류 | 내용 | 동의(예/아니오)
"""
import datetime

import openpyxl


def _s(v):
    if v is None:
        return ""
    if isinstance(v, (datetime.date, datetime.datetime)):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()


def _rows(ws):
    rows = list(ws.iter_rows(min_row=2, values_only=True))
    return [r for r in rows if any(_s(c) for c in r)]


def load_xlsx(path):
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    base = {_s(r[0]): _s(r[1]) for r in _rows(wb["기본"]) if len(r) >= 2}
    order = []
    for r in _rows(wb["순서"]):
        r = list(r) + [None] * 5
        step = {"name": _s(r[0])}
        if _s(r[1]):
            try:
                no = int(float(_s(r[1])))
            except ValueError:
                no = _s(r[1])  # 숫자가 아니면 검사기가 걸러낸다
            step["hymn"] = {"no": no, "title": _s(r[2])}
        if _s(r[3]):
            step["ref"] = _s(r[3])
        if _s(r[4]):
            step["note"] = _s(r[4])
        order.append(step)
    ads = [{"title": _s(r[0]), "body": _s(r[1])} for r in _rows(wb["광고"])]
    news = []
    for r in _rows(wb["소식"]):
        r = list(r) + [None] * 3
        consent = _s(r[2])
        news.append({"kind": _s(r[0]), "text": _s(r[1]),
                     "consent": True if consent == "예" else (False if consent == "아니오" else None)})
    content = {
        "date": base.get("날짜", ""),
        "title": base.get("제목", ""),
        "sermon": {"title": base.get("설교제목", ""), "passage": base.get("본문", ""), "preacher": base.get("설교자", "")},
        "order": order,
        "announcements": ads,
        "news": news,
    }
    wb.close()
    return content
