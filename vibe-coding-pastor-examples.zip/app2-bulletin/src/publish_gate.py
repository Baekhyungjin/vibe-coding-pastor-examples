# -*- coding: utf-8 -*-
"""게시 전 검사기 (공개 웹에 올려도 되는 주보인가?)

공개 게시 규칙(사양서 7.2)을 코드로 강제한다. 하나라도 걸리면 빌드를 중단한다.
이 검사기는 "기계가 판정할 수 있는 것"만 본다. 동의서를 실제로 받았는지는 간사님이 확인한다.

반환: Issue 목록. 비어 있으면 통과.
"""
import os
import re
import sys
from dataclasses import dataclass

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "lib"))
import canon as canon_mod  # noqa: E402
import refparse  # noqa: E402
import validate  # noqa: E402

# 오류 코드 (expected.json 과 테스트가 이 이름을 쓴다)
CONSENT_MISSING = "CONSENT_MISSING"            # 교인 소식에 동의 표시가 없거나 false
KIND_FORBIDDEN = "KIND_FORBIDDEN"              # 병환, 기도제목, 헌금자 명단 등 종류 자체가 금지
KIND_UNKNOWN = "KIND_UNKNOWN"                  # 허용 목록에 없는 소식 종류
SENSITIVE_WORD = "SENSITIVE_WORD"              # 질병, 수술 등을 암시하는 낱말
LYRICS_SUSPECT = "LYRICS_SUSPECT"              # 찬송 가사로 보이는 글
FORBIDDEN_FIELD = "FORBIDDEN_FIELD"            # lyrics, 가사 같은 칸
SCRIPTURE_TOO_LONG = "SCRIPTURE_TOO_LONG"      # 본문 인용이 3절을 넘음
SCRIPTURE_IN_FREETEXT = "SCRIPTURE_IN_FREETEXT"  # 인용 칸이 아닌 곳에 성경 본문이 들어 있음
TRANSLATION_MISSING = "TRANSLATION_MISSING"    # 인용에 번역본 표기가 없음
TRANSLATION_NOT_ALLOWED = "TRANSLATION_NOT_ALLOWED"  # 허가가 확인되지 않은 번역본
PHOTO_ALT_MISSING = "PHOTO_ALT_MISSING"        # 사진 대체 글이 없음
CHILD_PHOTO_NO_GUARDIAN = "CHILD_PHOTO_NO_GUARDIAN"  # 어린이 사진에 보호자 동의 없음
PHONE_IN_PUBLIC = "PHONE_IN_PUBLIC"            # 개인 전화번호 형식
EMAIL_IN_PUBLIC = "EMAIL_IN_PUBLIC"            # 이메일 형식
INVALID_REF = "INVALID_REF"                    # 없는 장절
HYMN_NO_RANGE = "HYMN_NO_RANGE"                # 찬송 장 번호가 찬송가 범위 밖
DATE_INVALID = "DATE_INVALID"                  # 날짜 형식
REQUIRED_MISSING = "REQUIRED_MISSING"          # 필수 칸 없음


@dataclass
class Issue:
    code: str
    where: str
    message: str

    def __str__(self):
        return "%s @ %s: %s" % (self.code, self.where, self.message)


_PHONE = re.compile(r"(?<!\d)(0\d{1,2})[-.\s]?(\d{3,4})[-.\s]?(\d{4})(?!\d)")
_EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
FORBIDDEN_FIELDS = {"lyrics", "가사", "prayer", "기도제목", "offering_list", "헌금자"}


def _texts(obj, path="$"):
    """JSON 안의 모든 문자열을 (경로, 값)으로 돌려준다."""
    if isinstance(obj, str):
        yield path, obj
    elif isinstance(obj, dict):
        for k, v in obj.items():
            yield from _texts(v, "%s.%s" % (path, k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _texts(v, "%s[%d]" % (path, i))


def _lyrics_like(text):
    """짧은 줄이 여러 줄 이어지면 가사로 의심한다 (4줄 이상, 줄마다 30자 이하)."""
    lines = [l.strip() for l in re.split(r"[\r\n]+", text) if l.strip()]
    if len(lines) >= 4 and all(len(l) <= 30 for l in lines):
        return True
    return False


def _verse_count(ref, cn):
    """참조 구간이 몇 절인지. 장 전체는 그 장의 절 수."""
    if ref.book is None:
        return 0
    if ref.c1 == ref.c2:
        if ref.v1 is None:
            return cn.verse_count(ref.book, ref.c1) or 0
        return (ref.v2 or ref.v1) - ref.v1 + 1
    total = 0
    for ch in range(ref.c1, ref.c2 + 1):
        n = cn.verse_count(ref.book, ch) or 0
        lo = ref.v1 if (ch == ref.c1 and ref.v1) else 1
        hi = ref.v2 if (ch == ref.c2 and ref.v2) else n
        total += max(0, hi - lo + 1)
    return total


def load_bible_texts(path=None):
    """개발용 개역한글 소량 데이터. 자유 글에 성경 본문이 섞였는지 대조하는 데만 쓴다."""
    import json
    p = path or os.path.join(ROOT, "lib", "data", "bible_sample_gaehan.json")
    try:
        with open(p, encoding="utf-8") as f:
            return list(json.load(f)["verses"].values())
    except (OSError, ValueError, KeyError):
        return []


def check(content, config, bible_texts=None):
    """content(dict)를 게시 규칙으로 검사한다. config 는 config/church.json."""
    issues = []
    cn = canon_mod.load()
    parser = refparse.Parser(cn)
    rules = config.get("rules", {})
    bible_texts = load_bible_texts() if bible_texts is None else bible_texts

    def add(code, where, msg):
        issues.append(Issue(code, where, msg))

    # 0. 필수 칸
    for key in ("date", "sermon", "order"):
        if key not in content:
            add(REQUIRED_MISSING, "$." + key, "필수 칸이 없습니다")
    if "date" in content and not _DATE.match(str(content["date"])):
        add(DATE_INVALID, "$.date", "YYYY-MM-DD 형식이 아닙니다")

    # 1. 금지 칸 이름 (어디에 있든)
    def walk_keys(o, path="$"):
        if isinstance(o, dict):
            for k, v in o.items():
                if str(k).lower() in FORBIDDEN_FIELDS:
                    add(FORBIDDEN_FIELD, path + "." + k, "공개 주보에 둘 수 없는 칸입니다")
                walk_keys(v, path + "." + k)
        elif isinstance(o, list):
            for i, v in enumerate(o):
                walk_keys(v, "%s[%d]" % (path, i))
    walk_keys(content)

    # 2. 개인 연락처 형식
    for path, text in _texts(content):
        if path.startswith("$.church_contact"):
            continue
        if _PHONE.search(text):
            add(PHONE_IN_PUBLIC, path, "전화번호 형식이 있습니다. 공개 주보에는 교회 대표번호만 둡니다")
        if _EMAIL.search(text):
            add(EMAIL_IN_PUBLIC, path, "이메일 형식이 있습니다")

    # 3. 장절 존재 (설교 본문, 순서의 ref, 인용 ref, 글 속 장절)
    def check_ref_text(text, where):
        for ref in parser.parse(text):
            res = validate.validate_ref(ref, cn)
            if not res.ok:
                add(INVALID_REF, where, "%s: %s" % (ref.raw, res.code))
    sermon = content.get("sermon") or {}
    if sermon.get("passage"):
        check_ref_text(sermon["passage"], "$.sermon.passage")
    for i, step in enumerate(content.get("order", [])):
        if step.get("ref"):
            check_ref_text(step["ref"], "$.order[%d].ref" % i)

    # 4. 찬송: 장 번호와 제목만, 가사 금지
    hymn_max = int(config.get("hymnal", {}).get("max_no", 645))
    for i, step in enumerate(content.get("order", [])):
        h = step.get("hymn")
        if not h:
            continue
        where = "$.order[%d].hymn" % i
        no = h.get("no")
        if not isinstance(no, int) or not (1 <= no <= hymn_max):
            add(HYMN_NO_RANGE, where + ".no", "찬송 장 번호는 1~%d 사이여야 합니다" % hymn_max)
        title = str(h.get("title", ""))
        if len(title) > int(rules.get("hymn_title_max_chars", 30)) or "\n" in title:
            add(LYRICS_SUSPECT, where + ".title", "제목이 길거나 줄바꿈이 있어 가사로 의심됩니다")
    for path, text in _texts(content):
        if _lyrics_like(text):
            add(LYRICS_SUSPECT, path, "짧은 줄이 4줄 이상 이어집니다. 찬송 가사는 게시하지 않습니다")

    # 5. 성경 본문 인용: 3절 이하, 번역본 표기, 허가된 번역본만
    max_verses = int(rules.get("scripture_max_verses", 3))
    allowed = set(config.get("translations_allowed", ["개역한글"]))
    for i, q in enumerate(content.get("scripture_quotes", [])):
        where = "$.scripture_quotes[%d]" % i
        tr = q.get("translation")
        if not tr:
            add(TRANSLATION_MISSING, where, "번역본 이름을 적어야 합니다")
        elif tr not in allowed:
            add(TRANSLATION_NOT_ALLOWED, where, "%s 은(는) 허가가 확인된 번역본 목록에 없습니다" % tr)
        refs = parser.parse(q.get("ref", ""))
        if not refs:
            add(INVALID_REF, where + ".ref", "장절을 읽을 수 없습니다")
        for ref in refs:
            res = validate.validate_ref(ref, cn)
            if not res.ok:
                add(INVALID_REF, where + ".ref", "%s: %s" % (ref.raw, res.code))
            n = _verse_count(ref, cn)
            if n > max_verses:
                add(SCRIPTURE_TOO_LONG, where, "%d절 인용입니다. %d절을 넘으면 허가가 필요합니다. 장절과 링크만 싣습니다" % (n, max_verses))
        # 글자 수로도 한 번 더: 절 표기를 속이고 긴 본문을 넣는 경우
        if len(q.get("text", "")) > int(rules.get("scripture_max_chars", 330)):
            add(SCRIPTURE_TOO_LONG, where + ".text", "인용 글이 너무 깁니다")
    # 인용 칸이 아닌 곳에 성경 본문이 있는지
    window = int(rules.get("freetext_scripture_window", 16))
    for path, text in _texts(content):
        if path.startswith("$.scripture_quotes"):
            continue
        flat = re.sub(r"\s+", "", text)
        for v in bible_texts:
            vf = re.sub(r"\s+", "", v)
            if len(vf) >= window and any(vf[j:j + window] in flat for j in range(0, len(vf) - window + 1)):
                add(SCRIPTURE_IN_FREETEXT, path, "성경 본문으로 보이는 글이 인용 칸 밖에 있습니다")
                break

    # 6. 교인 소식: 종류 허용 목록, 동의, 민감 낱말
    allowed_kinds = set(rules.get("news_kinds_allowed", []))
    forbidden_kinds = set(rules.get("news_kinds_forbidden", []))
    sensitive = rules.get("sensitive_words", [])
    for i, n in enumerate(content.get("news", [])):
        where = "$.news[%d]" % i
        kind = n.get("kind", "")
        if kind in forbidden_kinds:
            add(KIND_FORBIDDEN, where + ".kind", "'%s' 소식은 공개 주보에 싣지 않습니다(동의가 있어도)" % kind)
        elif kind not in allowed_kinds:
            add(KIND_UNKNOWN, where + ".kind", "허용 목록에 없는 종류입니다: %s" % (kind or "(비어 있음)"))
        if n.get("consent") is not True:
            add(CONSENT_MISSING, where + ".consent", "본인(또는 가족) 동의가 기록되지 않았습니다")
        blob = " ".join(_s for _p, _s in _texts({k: v for k, v in n.items() if k != "kind"}))
        for w in sensitive:
            if w in blob:
                add(SENSITIVE_WORD, where, "'%s' 낱말이 있습니다. 건강, 사정은 공개 주보에 싣지 않습니다" % w)
                break

    # 7. 사진
    photos = list(content.get("photos", []))
    for i, p in enumerate(photos):
        where = "$.photos[%d]" % i
        if not str(p.get("alt", "")).strip():
            add(PHOTO_ALT_MISSING, where + ".alt", "사진마다 대체 글이 필요합니다")
        if p.get("child") is True and p.get("guardian_consent") is not True:
            add(CHILD_PHOTO_NO_GUARDIAN, where, "어린이 사진은 보호자 동의가 기록돼야 합니다")
    return issues


def codes(issues):
    return sorted({i.code for i in issues})


if __name__ == "__main__":
    import json
    cfg = json.load(open(os.path.join(ROOT, "config", "church.json"), encoding="utf-8"))
    for p in sys.argv[1:]:
        c = json.load(open(p, encoding="utf-8"))
        res = check(c, cfg)
        print(os.path.basename(p), "통과" if not res else "중단")
        for it in res:
            print("  ", it)
