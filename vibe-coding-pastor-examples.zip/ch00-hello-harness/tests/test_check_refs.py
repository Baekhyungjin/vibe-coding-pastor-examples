"""CRITERIA.md 의 S, N 항목을 하나씩 확인하는 단위 테스트 (표준 라이브러리 unittest)."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from check_refs import check_text, find_refs  # noqa: E402


class TestS1_표기인식(unittest.TestCase):
    def test_S1_약어와_정식이름_모두_인식(self):
        refs = find_refs("요 3:16 과 요한복음 3장 16절, 롬8:28")
        self.assertEqual([(r["book"], r["chapter"], r["start"]) for r in refs],
                         [("요한복음", 3, 16), ("요한복음", 3, 16), ("로마서", 8, 28)])

    def test_S1_긴이름_우선(self):
        refs = find_refs("요일 4:8")
        self.assertEqual(refs[0]["book"], "요한일서")

    def test_S1_범위표기(self):
        refs = find_refs("마 5:3-12")
        self.assertEqual((refs[0]["start"], refs[0]["end"]), (3, 12))


class TestS2_범위판정(unittest.TestCase):
    def test_S2_있는장절은_통과(self):
        passed, _ = check_text("시 23:1, 고전 13:13")
        self.assertTrue(passed)

    def test_S2_없는장은_실패(self):
        passed, _ = check_text("시 151:1")
        self.assertFalse(passed)

    def test_S2_없는절은_실패(self):
        passed, _ = check_text("유 1:30")
        self.assertFalse(passed)

    def test_S2_범위끝이_넘치면_실패(self):
        passed, _ = check_text("요 3:16-40")
        self.assertFalse(passed)


class TestN1_오탐금지(unittest.TestCase):
    def test_N1_시각은_장절로_보지_않음(self):
        self.assertEqual(find_refs("주일 예배는 오전 11:00, 오후 2:30 입니다"), [])

    def test_N1_장절이_없으면_통과시키지_않음(self):
        passed, _ = check_text("이번 주 광고입니다.")
        self.assertFalse(passed)


if __name__ == "__main__":
    unittest.main()
