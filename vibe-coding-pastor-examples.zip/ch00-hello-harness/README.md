# ch00-hello-harness (Ch 0 연습 예제)
설교 메모 속 성경 장절 표기가 범위표에 있는지 검사하는 아주 작은 예제입니다.
표준 라이브러리만 쓰므로 Python 3.11 이상만 있으면 됩니다.

## 실행 (3줄)
    python scripts/verify.py                         # 하네스 전체 실행, 마지막 줄 RESULT 확인
    python src/check_refs.py samples/golden/note_01_주일설교메모.txt   # 메모 하나만 검사
    python -m unittest discover tests                # 단위 테스트만 실행

## 폴더
- CRITERIA.md : 성공 기준서 (목회자 작성, 승인 후 잠금)
- CLAUDE.md   : AI 작업 규칙 (Codex 를 쓰면 같은 내용을 AGENTS.md 로 복사)
- src/        : 검사기 (canon.py 범위표, check_refs.py 판정)
- tests/      : 단위 테스트
- samples/golden : 통과해야 하는 가짜 메모
- samples/trap   : 반드시 FAIL 나야 하는 가짜 메모
- scripts/verify.py : 하네스 진입점, output/verify_report.json 생성
- .claude/settings.json : AI가 일을 끝내려 할 때 하네스를 자동 실행하는 훅 예시

## 주의
- src/canon.py 의 절 수 표는 연습용 축소판(13개 장)입니다. 표에 없는 장은 "절 수가 범위표에 아직 없습니다"로 FAIL 처리됩니다.
- 장 수 표는 66권 전체를 담았습니다.
- 대조 기록: 2026-10-27에 대한성서공회 성경 사이트(bible.bskorea.or.kr)의 개역한글판 본문 화면과 대조했습니다.
  66권 모두 마지막 장이 있고 그 다음 장이 없는 것을 확인했고(요엘 3장, 말라기 4장 포함), 연습용 13개 장의 절 수도 모두 일치했습니다.
  대조 방법은 해당 장 화면에 표시된 절 번호를 세는 것입니다. 본문 데이터는 이 폴더에 넣지 않았습니다.