"""글 속의 성경 장절 표기를 찾아 범위표에 있는지 검사한다.

사용법: python src/check_refs.py 파일경로
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from canon import ALIASES, CHAPTERS, VERSES  # noqa: E402

# 긴 이름부터 맞춰야 '요한일서'가 '요'로 잘못 잘리지 않는다.
_NAMES = sorted(ALIASES, key=len, reverse=True)
REF_RE = re.compile(
    r"(?<![가-힣])(" + "|".join(map(re.escape, _NAMES)) + r")\s*"
    r"(\d+)\s*(?::|장\s*)(\d+)\s*절?"
    r"(?:\s*[-~]\s*(\d+)\s*절?)?"
)


def find_refs(text):
    """글에서 장절 표기를 모두 찾는다."""
    refs = []
    for m in REF_RE.finditer(text):
        book = ALIASES[m.group(1)]
        start = int(m.group(3))
        end = int(m.group(4)) if m.group(4) else start
        refs.append({
            "raw": m.group(0).strip(),
            "book": book,
            "chapter": int(m.group(2)),
            "start": start,
            "end": end,
        })
    return refs


def check_ref(ref):
    """장절 하나를 판정한다. (통과 여부, 이유)"""
    book, ch, start, end = ref["book"], ref["chapter"], ref["start"], ref["end"]
    max_ch = CHAPTERS[book]
    if ch < 1 or ch > max_ch:
        unit = "편" if book == "시편" else "장"
        return False, f"{book}은(는) {max_ch}{unit}까지만 있습니다"
    if start < 1 or end < start:
        return False, "절 범위의 앞뒤가 맞지 않습니다"
    max_v = VERSES.get((book, ch))
    if max_v is None:
        return False, f"{book} {ch}장의 절 수가 범위표에 아직 없습니다"
    if end > max_v:
        return False, f"{book} {ch}장은 {max_v}절까지만 있습니다"
    return True, "범위표에 있음"


def check_text(text):
    """글 전체를 판정한다. 장절이 하나도 없으면 실패로 본다."""
    refs = find_refs(text)
    results = []
    for ref in refs:
        ok, reason = check_ref(ref)
        results.append({**ref, "ok": ok, "reason": reason})
    passed = bool(results) and all(r["ok"] for r in results)
    return passed, results


def main():
    try:  # 윈도우 콘솔 한글 깨짐 방지
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    if len(sys.argv) != 2:
        print("사용법: python src/check_refs.py 파일경로")
        return 1
    text = Path(sys.argv[1]).read_text(encoding="utf-8")
    passed, results = check_text(text)
    for r in results:
        mark = "OK  " if r["ok"] else "틀림"
        print(f"  [{mark}] {r['raw']}  ->  {r['reason']}")
    if not results:
        print("  장절 표기를 하나도 찾지 못했습니다")
    print("PASS" if passed else "FAIL")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
