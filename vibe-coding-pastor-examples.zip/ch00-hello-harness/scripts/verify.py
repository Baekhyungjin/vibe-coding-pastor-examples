"""하네스 실행 진입점 (모든 앱 공통 이름: scripts/verify.py).

1) tests/ 의 단위 테스트를 돌린다.
2) samples/golden 은 전부 PASS 여야 한다.
3) samples/trap 은 전부 FAIL 로 잡혀야 한다.
4) 결과를 output/verify_report.json 에 기록하고
   마지막 줄에 RESULT: PASSED (n/n) 또는 FAILED (k/n) 를 출력한다.
종료 코드: 통과 0, 실패 2 (훅에서 AI가 계속 고치도록)
"""
import hashlib
import io
import json
import sys
import unittest
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from check_refs import check_text  # noqa: E402

try:  # 윈도우 콘솔 한글 깨짐 방지
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def run_unit_tests():
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    buf = io.StringIO()
    result = unittest.TextTestRunner(stream=buf, verbosity=0).run(suite)
    total = result.testsRun
    failed = len(result.failures) + len(result.errors)
    return total, failed, buf.getvalue()


def main():
    quiet = "--quiet" in sys.argv
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    checks = []
    print(f"[하네스] ch00-hello-harness 검증 시작 ({now})")

    total, failed, log = run_unit_tests()
    ok = total > 0 and failed == 0
    checks.append({"name": "단위 테스트", "ok": ok, "detail": f"{total - failed}/{total} 통과"})
    print(f"[테스트] tests/ 단위 테스트 {total}개 중 {total - failed}개 통과")
    if failed and not quiet:
        print(log)

    for kind, expect_pass in (("golden", True), ("trap", False)):
        for f in sorted((ROOT / "samples" / kind).glob("*.txt")):
            passed, results = check_text(f.read_text(encoding="utf-8"))
            ok = passed == expect_pass
            bad = [f"{r['raw']} ({r['reason']})" for r in results if not r["ok"]]
            if kind == "golden":
                label = "골든"
                detail = (f"PASS, 장절 {len(results)}개 모두 범위표에 있음" if ok
                          else "FAIL, 통과해야 하는데 틀림: " + "; ".join(bad or ["장절 없음"]))
            else:
                label = "함정"
                detail = ("FAIL로 잡음: " + "; ".join(bad or ["장절 없음"]) if ok
                          else "놓침, 틀린 장절이 있는데 PASS로 판정함")
            mark = "통과" if ok else "실패"
            print(f"[{label}] {f.name} ... {mark} ({detail})")
            checks.append({"name": f"{kind}/{f.name}", "ok": ok, "detail": detail,
                           "sha256": sha256(f)})

    n = len(checks)
    k = sum(1 for c in checks if not c["ok"])
    result = f"PASSED ({n}/{n})" if k == 0 else f"FAILED ({k}/{n})"
    report = {"app": "ch00-hello-harness", "run_at": now, "checks": checks,
              "result": result}
    out = ROOT / "output"
    out.mkdir(exist_ok=True)
    (out / "verify_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print("[리포트] output/verify_report.json 저장")
    print(f"RESULT: {result}")
    return 0 if k == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
