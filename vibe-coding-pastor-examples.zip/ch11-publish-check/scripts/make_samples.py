"""골든/함정 샘플 폴더를 만든다. 모든 값은 가짜다.

    python scripts/make_samples.py

- 전화번호는 실제로 쓰이지 않는 010-0xxx 형식만 쓴다.
- 키 문자열은 누가 봐도 가짜인 'FAKE' 표시를 넣는다.
- 교인 이름은 refdata/members_sample.csv 의 가짜 명부에서 가져온다.
- 찬송 가사는 이 책이 지어낸 가짜 가사다. 실제 찬송 가사는 한 줄도 쓰지 않는다.
- 성경 본문은 refdata 의 개역한글 소량 표본만 쓴다. 개역개정 본문은 어디에도 없다.
"""
import csv
import json
import shutil
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
SAMPLES = ROOT / "samples"
REF = ROOT / "refdata"

STD_IGNORE = "# 실데이터와 결과물은 올리지 않는다\ndata/\noutput/\n.env\n__pycache__/\n"
FAKE_PHONE = "010-0123-4567"
FAKE_KEY = "sk-test-FAKE0000example0000NOTREAL"
README = "# 가상교회 소식 모음\n\n공개용 예제입니다. 성경 본문은 대한성서공회 사이트로 연결합니다. 개역개정은 허가가 필요한 번역본이므로 본문을 싣지 않습니다.\n"
INDEX = ('<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="robots" content="noindex, nofollow">'
         "<title>가상교회 주보</title></head><body><h1>가상교회 주보</h1><p>오늘 말씀: 요한복음 3:16</p>"
         '<p><a href="https://bible.bskorea.or.kr/">대한성서공회 성경 보기</a></p></body></html>\n')


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_xlsx(path, cell_texts):
    """표준 라이브러리만으로 만든 아주 작은 엑셀 파일(셀 문자열만 들어 있음)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    si = "".join(f"<si><t>{t}</t></si>" for t in cell_texts)
    rows = "".join(f'<row r="{i + 1}"><c r="A{i + 1}" t="s"><v>{i}</v></c></row>' for i in range(len(cell_texts)))
    files = {
        "[Content_Types].xml": (
            '<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
            '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/></Types>'),
        "_rels/.rels": (
            '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'),
        "xl/workbook.xml": (
            '<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>'),
        "xl/_rels/workbook.xml.rels": (
            '<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
            '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>'),
        "xl/worksheets/sheet1.xml": (
            f'<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>{rows}</sheetData></worksheet>'),
        "xl/sharedStrings.xml": (
            f'<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="{len(cell_texts)}" uniqueCount="{len(cell_texts)}">{si}</sst>'),
    }
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n, c in files.items():
            z.writestr(n, c)


def verses(book_ref_prefix, nums):
    data = json.loads((REF / "bible_gaehan.json").read_text(encoding="utf-8"))["verses"]
    return [f"{n} {data[f'{book_ref_prefix}:{n}']}" for n in nums]


def basic(folder, ignore=STD_IGNORE, readme=README, index=INDEX, data=("members.csv", "이름,직분\n곽도율,집사\n")):
    write(folder / ".gitignore", ignore)
    write(folder / "README.md", readme)
    write(folder / "docs" / "index.html", index)
    write(folder / "data" / data[0], data[1])  # 무시되는 폴더: 점검 대상이 아님
    write(folder / ".env", f"KEY={FAKE_KEY}\n")                         # 무시되는 파일: 점검 대상이 아님


def build():
    if SAMPLES.exists():
        shutil.rmtree(SAMPLES)
    g, t = SAMPLES / "golden", SAMPLES / "trap"

    # ---- 골든: 모두 통과해야 한다
    basic(g / "clean_church_site")
    basic(g / "gitignore_variants", ignore="/data/\noutput/**\n.env\n")
    basic(g / "three_verses_ok")
    write(g / "three_verses_ok" / "docs" / "word.md", "## 오늘의 시편 23편 (개역한글)\n\n" + "\n".join(verses("시 23", [1, 2, 3])) + "\n")
    basic(g / "allowed_fake_samples")
    write(g / "allowed_fake_samples" / ".publish-allow", "samples/  # 교육용 가짜 명단. 승인: 김 목사 2026-10-27\n")
    write(g / "allowed_fake_samples" / "samples" / "fake_members.csv", "이름,직분\n곽도율,집사\n")
    basic(g / "json_hymn_title_ok")
    write(g / "json_hymn_title_ok" / "content" / "2026-11-01.json", json.dumps({"date": "2026-11-01", "title": "", "sermon": {"title": "작은 등불", "passage": "시 23:1-3", "preacher": "김 목사"}, "worship": [{"item": "찬송", "number": 100, "title": "가상 찬송 제목"}, {"item": "기도", "who": "맡은이"}, {"item": "성경봉독", "ref": "시 23:1-3"}, {"item": "설교", "title": "작은 등불"}, {"item": "찬송", "number": 200, "title": "다른 제목"}, {"item": "봉헌", "who": "맡은이"}, {"item": "축도", "who": "담임"}]}, ensure_ascii=False, indent=2))
    write(g / "payload_only" / "index.html", INDEX)
    write(g / "payload_only" / "2026-11-01" / "index.html", INDEX)

    # ---- 함정: 각각 expected.json 의 이유로 차단되어야 한다
    basic(t / "phone_in_readme", readme=README + f"\n문의: {FAKE_PHONE}\n")
    basic(t / "roster_name_in_notice")
    write(t / "roster_name_in_notice" / "docs" / "notice.md", "## 교우 소식\n\n곽도율 집사님 가정에 기쁜 일이 있습니다.\n")
    basic(t / "fake_key_in_config")
    write(t / "fake_key_in_config" / "src" / "config.py", f'API_KEY = "{FAKE_KEY}"\n')
    basic(t / "gitignore_missing_data", ignore="output/\n.env\n", data=("notes.txt", "내부 메모: 다음 주 청소 당번 정하기\n"))
    basic(t / "data_file_not_ignored")
    write_xlsx(t / "data_file_not_ignored" / "10월_수련회_정산.xlsx", ["항목", "합계"])
    basic(t / "phone_in_xlsx")
    write_xlsx(t / "phone_in_xlsx" / "명단.xlsx", ["이름", FAKE_PHONE])
    basic(t / "allow_without_reason")
    write(t / "allow_without_reason" / ".publish-allow", "samples/\n")
    write(t / "allow_without_reason" / "samples" / "list.md", "가짜 목록\n")
    basic(t / "key_in_allowed_path")
    write(t / "key_in_allowed_path" / ".publish-allow", "samples/  # 가짜 설정 예시. 승인: 김 목사 2026-10-27\n")
    write(t / "key_in_allowed_path" / "samples" / "settings.json", json.dumps({"key": FAKE_KEY}))
    basic(t / "bible_long_quote")
    write(t / "bible_long_quote" / "docs" / "word.md", "## 오늘의 시편 23편 (개역한글)\n\n" + "\n".join(verses("시 23", [1, 2, 3, 4, 5])) + "\n")
    basic(t / "hymn_lyrics")
    write(t / "hymn_lyrics" / "docs" / "praise.md", "## 가상 찬송 (이 책이 지어낸 가사, 1절)\n\n"
          + "\n".join(["새벽 빛이 마을 위에 내려오면", "작은 등불 하나 창가에 켜 두고", "지나는 이웃 발걸음 비추리라",
                       "어둔 길도 두렵지 않으리", "따뜻한 손길 맞잡고 걸으리", "(후렴)", "빛이 되리 우리 모두 빛이 되리",
                       "작은 불씨가 큰 아침 되리"]) + "\n")
    basic(t / "gaegae_file_name")
    write(t / "gaegae_file_name" / "docs" / "bible_개역개정.json", json.dumps({"verses": {"가상 1:1": "시험용 자리표시 문장입니다"}}, ensure_ascii=False))
    basic(t / "gaegae_meta")
    write(t / "gaegae_meta" / "docs" / "translation.json", json.dumps({"translation_name": "성경전서 개역개정판", "verses": {}}, ensure_ascii=False))

    expected = {
        "_설명": "함정 폴더마다 어떤 검사(check)로, 그리고 그 검사로만 '차단'되어야 하는지 적은 정답표(엑셀 파일은 D1과 P1 둘 다 맞다)",
        "phone_in_readme": "P1", "roster_name_in_notice": "P1", "fake_key_in_config": "K1",
        "gitignore_missing_data": "G1", "data_file_not_ignored": "D1", "phone_in_xlsx": ["D1", "P1"],
        "allow_without_reason": "A1", "key_in_allowed_path": "K1", "bible_long_quote": "B1",
        "hymn_lyrics": "H1", "gaegae_file_name": "L1", "gaegae_meta": "L1",
    }
    write(t / "expected.json", json.dumps(expected, ensure_ascii=False, indent=2))
    print("샘플 폴더 생성 완료:", SAMPLES)


if __name__ == "__main__":
    build()
