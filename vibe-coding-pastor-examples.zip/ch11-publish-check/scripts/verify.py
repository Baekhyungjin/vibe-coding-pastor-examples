"""하네스 실행 진입점 (모든 앱 공통 이름)

    python scripts/verify.py          # 자세히
    python scripts/verify.py --quiet  # 요약만
"""
import sys
from pathlib import Path
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from verify_core import run_harness
if __name__ == "__main__":
    sys.exit(run_harness(HERE.parent, quiet="--quiet" in sys.argv))