"""교회용 공개 전 점검기 테스트 (CRITERIA.md 의 S, N 항목 번호를 이름에 붙였다)"""
import hashlib
import json
import sys
import time
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

from publish_check import check  # noqa: E402
from verify_core import record_metric  # noqa: E402

GOLDEN = ROOT / "samples" / "golden"
TRAP = ROOT / "samples" / "trap"
ROSTER = str(ROOT / "refdata" / "members_sample.csv")
FAKE_PHONE = "010-0123-4567"
FAKE_KEY = "sk-test-FAKE0000example0000NOTREAL"


def run(folder, **kw):
    return check(folder, roster=ROSTER, **kw)


def blocked(result):
    return [f for f in result["findings"] if f["level"] == "차단"]


def tree_hash(folder):
    h = hashlib.sha256()
    for p in sorted(Path(folder).rglob("*")):
        if p.is_file():
            h.update(p.relative_to(folder).as_posix().encode("utf-8"))
            h.update(p.read_bytes())
    return h.hexdigest()


class TestPublishCheck(unittest.TestCase):
    def test_S1_골든폴더는_모두_통과(self):
        for folder in sorted(p for p in GOLDEN.iterdir() if p.is_dir()):
            r = run(folder, payload=(folder.name == "payload_only"))
            self.assertEqual(r["verdict"], "통과", f"{folder.name} 이 차단됨: {blocked(r)[:3]}")

    def test_S2_gitignore는_모양이_달라도_뜻으로_판정(self):
        r = run(GOLDEN / "gitignore_variants")
        g1 = [f for f in r["findings"] if f["check"] == "G1"]
        self.assertEqual(g1, [], f"같은 뜻의 .gitignore 를 틀렸다고 봄: {g1}")

    def test_S3_무시되는_폴더는_공개대상이_아님(self):
        r = run(GOLDEN / "clean_church_site")
        leaked = [f for f in r["findings"] if f["path"].startswith(("data/", "output/")) or f["path"] == ".env"]
        self.assertEqual(leaked, [], f".gitignore 로 빠지는 파일까지 문제 삼음: {leaked[:3]}")

    def test_S4_함정은_예상한_이유로만_차단(self):
        expected = json.loads((TRAP / "expected.json").read_text(encoding="utf-8"))
        wrong = []
        for name, check_id in expected.items():
            if name.startswith("_"):
                continue
            want = set(check_id) if isinstance(check_id, list) else {check_id}
            ids = {f["check"] for f in blocked(run(TRAP / name))}
            if ids != want:
                wrong.append(f"{name}: 기대 {sorted(want)}, 실제 차단 {sorted(ids) or '없음'}")
        self.assertEqual(wrong, [], "함정이 예상한 이유로만 차단되지 않음:\n" + "\n".join(wrong))

    def test_S5_허용목록은_사유가_있을때만_주의로_낮춤(self):
        r = run(GOLDEN / "allowed_fake_samples")
        warns = [f for f in r["findings"] if f["level"] == "주의" and f["check"] != "R1"]
        self.assertTrue(warns, "허용된 가짜 샘플도 '주의'로는 보여야 한다")
        self.assertEqual(r["verdict"], "통과")

    def test_S6_payload_모드는_폴더_전체가_공개대상(self):
        folder = GOLDEN / "payload_only"
        self.assertEqual(run(folder, payload=True)["verdict"], "통과")
        self.assertIn("G1", {f["check"] for f in run(folder)["findings"]}, "저장소 전체로 보면 .gitignore 가 없다고 알려야 한다")

    def test_S7_성경은_3절까지만_넘기면_차단(self):
        self.assertEqual(run(GOLDEN / "three_verses_ok")["verdict"], "통과", "3절은 허용해야 한다")
        self.assertIn("B1", {f["check"] for f in blocked(run(TRAP / "bible_long_quote"))})

    def test_S8_README의_개역개정_언급은_차단하지_않음(self):
        r = run(GOLDEN / "clean_church_site")
        self.assertEqual([f for f in r["findings"] if f["check"] == "L1"], [])

    def test_S10_찬송_제목과_번호만_있는_JSON은_가사로_보지_않음(self):
        r = run(GOLDEN / "json_hymn_title_ok")
        self.assertEqual([f for f in r["findings"] if f["check"] == "H1"], [], "보기 좋게 줄바꿈한 JSON 을 가사로 오해함")

    def test_S9_1000파일은_10초_안에(self):
        big = ROOT / "output" / "_speed"
        if big.exists():
            for p in big.rglob("*"):
                if p.is_file():
                    p.unlink()
        (big / "docs").mkdir(parents=True, exist_ok=True)
        (big / ".gitignore").write_text("data/\noutput/\n.env\n", encoding="utf-8")
        for i in range(1000):
            (big / "docs" / f"page{i:04d}.md").write_text(f"# 소식 {i}\n\n이번 주 모임은 토요일 오후입니다.\n", encoding="utf-8")
        # 새로 만든 파일은 처음 읽을 때 느릴 수 있다(바이러스 검사 등). 첫 읽기 시간과 점검기 시간을 나눠서 잰다.
        t0 = time.time()
        for p in (big / "docs").iterdir():
            p.read_bytes()
        first_read = time.time() - t0
        t0 = time.time()
        r = run(big)
        sec = time.time() - t0
        record_metric(ROOT, "1000파일 첫 읽기 시간(초)", round(first_read, 2))
        record_metric(ROOT, "1000파일 점검기 시간(초)", round(sec, 2))
        self.assertEqual(r["verdict"], "통과")
        self.assertLess(sec, 10, f"{sec:.1f}초 걸림")

    def test_N1_키는_허용목록으로도_못_피함(self):
        r = run(TRAP / "key_in_allowed_path")
        keys = [f for f in r["findings"] if f["check"] == "K1"]
        self.assertTrue(keys and all(f["level"] == "차단" for f in keys), f"키가 차단되지 않음: {keys}")

    def test_N2_리포트에_원문이_다시_새지_않음(self):
        for name in ("phone_in_readme", "fake_key_in_config", "phone_in_xlsx", "roster_name_in_notice"):
            text = json.dumps(run(TRAP / name), ensure_ascii=False)
            self.assertNotIn(FAKE_PHONE, text, f"{name} 리포트에 전화번호 원문이 그대로 있음")
            self.assertNotIn(FAKE_KEY, text, f"{name} 리포트에 키 원문이 그대로 있음")
            self.assertNotIn("곽도율", text, f"{name} 리포트에 교인 이름 원문이 그대로 있음")

    def test_N3_점검_대상_폴더는_읽기만(self):
        folder = TRAP / "phone_in_xlsx"
        before = tree_hash(folder)
        run(folder)
        self.assertEqual(before, tree_hash(folder), "점검기가 대상 폴더를 바꿨다")

    def test_N4_개역개정_데이터는_파일이름과_메타로_찾음(self):
        for name in ("gaegae_file_name", "gaegae_meta"):
            self.assertIn("L1", {f["check"] for f in blocked(run(TRAP / name))}, name)


if __name__ == "__main__":
    unittest.main()
