"""교회용 공개 전 점검기 (Ch 11)

폴더를 GitHub 등에 올리기 전에 여덟 가지를 검사한다.
  G1  .gitignore 에 data/, output/, .env 가 '뜻으로' 들어 있는가 (저장소 전체를 올릴 때만)
  P1  교인 명부 이름과 연락처, 이메일, 주소 같은 개인정보가 남아 있는가 (엑셀 셀 안까지 읽는다)
  K1  토큰/키처럼 보이는 문자열이 있는가 (어떤 경우에도 허용 불가)
  D1  엑셀/CSV 같은 실데이터 확장자 파일이 공개 대상에 있는가
  A1  .publish-allow (허용 목록) 줄에 사유가 빠져 있지 않은가
  B1  성경 본문이 3절을 넘겨 이어서 실려 있는가 (점검기가 가진 본문 표본과 대조)
  H1  찬송 가사로 보이는 글이 있는가
  L1  개역개정 같은 허가가 필요한 번역본 데이터 파일이 있는가 (파일 이름과 메타 정보만 본다)
  R1  공개 HTML 쪽에 noindex 가 없는가 (참고용 '주의', 차단하지 않는다)

공개 대상: .gitignore 로 빠지는 data/, output/, .env 는 공개 대상이 아니므로 검사하지 않는다.
--payload: 폴더 안 내용 전부가 그대로 공개되는 경우(예: docs/ 만 올림). 모든 파일이 공개 대상이고 G1 은 건너뛴다.
허용 목록: 'samples/  # 사유. 승인: 이름 날짜' 형식. 사유가 있는 줄만 유효하며,
           허용된 경로의 D1, P1, B1, H1, L1 은 '차단' 대신 '주의'로 낮춘다. K1 은 낮추지 않는다.

한계: 성경 본문 검사(B1)는 이 폴더 refdata/ 에 들어 있는 본문 표본과 대조한다.
      표본에 없는 구절이나 다른 번역본의 장문은 찾지 못한다. 찬송 가사 검사(H1)는 모양으로 짐작할 뿐이다.

사용법:
    python src/publish_check.py <검사할 폴더> [--payload] [--roster 명부.csv]
"""
import json
import re
import sys
import zipfile
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from anonymize import load_roster, residual_scan  # noqa: E402

REFDATA = HERE.parent / "refdata"
REQUIRED_IGNORES = ["data", "output", ".env"]
DATA_EXTS = {".xlsx", ".xls", ".xlsm", ".csv", ".eml", ".mbox", ".db", ".sqlite", ".hwp", ".hwpx", ".pst"}
TEXT_EXTS = {".md", ".txt", ".py", ".js", ".html", ".htm", ".css", ".json", ".yaml", ".yml", ".toml",
             ".ini", ".cfg", ".csv", ".eml", ".env", ".sh", ".ps1", ".bat", ""}
SKIP_DIRS = {".git", "__pycache__", "node_modules"}
MAX_TEXT_BYTES = 3_000_000
MAX_QUOTE_VERSES = 3
PERMIT_NAMES = ("개역개정", "nkrv")

SECRET_PATTERNS = {
    "sk- 형식 키": re.compile(r"\bsk-(?:ant-)?[A-Za-z0-9_\-]{16,}"),
    "GitHub 토큰": re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}|\bgithub_pat_[A-Za-z0-9_]{20,}"),
    "AWS 액세스 키": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "Google API 키": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}"),
    "Slack 토큰": re.compile(r"\bxox[abprs]-[A-Za-z0-9-]{10,}"),
    "개인 키 파일": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "비밀번호 직접 기입": re.compile(r"(?i)\b(?:password|passwd|pwd)\s*[:=]\s*['\"][^'\"\s]{4,}['\"]"),
}
_MAYBE_SECRET = re.compile(r"sk-|ghp_|gho_|ghu_|ghs_|ghr_|github_pat_|AKIA|AIza|xox[abprs]-|PRIVATE KEY|(?i:password|passwd|pwd)")
_NOISE = re.compile(r"[^0-9A-Za-z가-힣]")
_TAG = re.compile(r"<[^>]+>")
_BREAKS = re.compile(r"</(?:p|li|div|h[1-6]|tr|blockquote)>|<br\s*/?>", re.I)
HYMN_WORDS = re.compile(r"찬송|찬양|후렴|가사")
LYRIC_KEYS = {"lyrics", "lyric", "가사", "찬송가사"}


def hide(value):
    """리포트에 원문이 다시 새지 않도록 앞 4글자만 남긴다."""
    return value[:4] + "***" if len(value) > 4 else "***"


def normalize_ignore(line):
    """'/data/', 'data', 'output/**' 처럼 모양이 달라도 같은 이름이면 같은 뜻으로 본다."""
    s = line.strip()
    if not s or s.startswith("#") or s.startswith("!"):
        return None
    s = s.lstrip("/")
    for tail in ("/**", "/*", "/"):
        if s.endswith(tail):
            s = s[: -len(tail)]
    return s or None


def read_ignores(root):
    gi = root / ".gitignore"
    if not gi.exists():
        return set()
    return {n for n in (normalize_ignore(l) for l in gi.read_text(encoding="utf-8", errors="replace").splitlines()) if n}


def read_allow(root):
    """.publish-allow 읽기. 반환: (유효한 경로 접두어 목록, 사유 없는 줄 목록)"""
    path = root / ".publish-allow"
    ok, bad = [], []
    if not path.exists():
        return ok, bad
    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        target, _, reason = line.partition("#")
        target = target.strip().lstrip("/")
        if not target:
            continue
        if reason.strip():
            ok.append(target)
        else:
            bad.append(target)
    return ok, bad


def xlsx_text(path):
    """엑셀 안의 글자(공유 문자열, 인라인 문자열)를 모아 하나의 글로 돌려준다."""
    parts = []
    try:
        with zipfile.ZipFile(path) as z:
            for name in z.namelist():
                if name.startswith("xl/") and name.endswith(".xml") and (
                        "sharedStrings" in name or "worksheets/" in name):
                    xml = z.read(name).decode("utf-8", errors="replace")
                    parts.extend(re.findall(r">([^<>]+)<", xml))
    except (zipfile.BadZipFile, OSError):
        return ""
    return "\n".join(parts)


def is_ignored(rel_parts, ignores):
    return any(part in ignores for part in rel_parts)


# ---------------------------------------------------------------- 성경 본문 표본
def load_verse_index(refdir=REFDATA):
    """표본 본문을 (정규화한 글, 책, 장, 절) 목록으로 만든다. 8자 미만의 짧은 절은 오탐이 많아 뺀다."""
    index = []
    for fn in sorted(Path(refdir).glob("bible_*.json")):
        data = json.loads(fn.read_text(encoding="utf-8"))
        verses = data.get("verses", data)
        if not isinstance(verses, dict):
            continue
        for ref, text in verses.items():
            m = re.match(r"^(.+?)\s(\d+):(\d+)$", ref)
            if not m or not isinstance(text, str):
                continue
            norm = _NOISE.sub("", text)
            if len(norm) >= 8:
                index.append((norm, m.group(1), int(m.group(2)), int(m.group(3))))
    return index


def longest_verse_run(text, index):
    """글 안에서 같은 장의 연속된 절이 가장 길게 이어진 개수와 위치를 돌려준다."""
    norm = _NOISE.sub("", text)
    found = {}
    for vnorm, book, ch, v in index:
        if vnorm in norm:
            found.setdefault((book, ch), set()).add(v)
    best, where = 0, ""
    for (book, ch), vs in found.items():
        run, prev, start = 0, None, None
        for v in sorted(vs):
            if prev is not None and v == prev + 1:
                run += 1
            else:
                run, start = 1, v
            prev = v
            if run > best:
                best, where = run, f"{book} {ch}:{start}-{v}"
    return best, where


# ---------------------------------------------------------------- 찬송 가사 모양
def looks_like_lyrics(text, suffix):
    """가사 칸 이름이 있거나, 찬송 낱말과 함께 짧은 줄이 길게 이어지면 가사로 짐작한다."""
    if suffix == ".json":
        try:
            data = json.loads(text)
        except ValueError:
            data = None

        def walk(o):
            if isinstance(o, dict):
                for k, v in o.items():
                    if str(k).lower() in LYRIC_KEYS and isinstance(v, str) and len(v.strip()) >= 20:
                        return True
                    if walk(v):
                        return True
            elif isinstance(o, list):
                return any(walk(i) for i in o)
            return False
        if data is not None and walk(data):
            return True
    plain = _TAG.sub("", _BREAKS.sub("\n", text)) if suffix in (".html", ".htm") else text
    if not HYMN_WORDS.search(plain):
        return False
    run = best = 0
    for line in plain.splitlines():
        s = line.strip()
        if 4 <= len(s) <= 30 and not s.startswith(("-", "|", "#", "*", ">")) and not s.endswith((".", "?", "!", "다.")):
            run += 1
            best = max(best, run)
        else:
            run = 0
    return best >= 6


# ---------------------------------------------------------------- 개역개정 파일
def permit_file_reason(path, suffix, text):
    """파일 이름이나 JSON 메타 정보에 허가가 필요한 번역본 이름이 있으면 이유를 돌려준다."""
    low = path.name.lower()
    if any(n in low for n in PERMIT_NAMES):
        return "파일 이름"
    if suffix == ".json" and text:
        try:
            data = json.loads(text)
        except ValueError:
            return None
        if isinstance(data, dict):
            for k in ("translation_name", "translation_id", "translation", "version", "name", "title"):
                v = data.get(k)
                if isinstance(v, str) and any(n in v.lower() for n in PERMIT_NAMES):
                    return f"메타 정보({k})"
    return None


def check(root, payload=False, roster=None, refdir=REFDATA):
    root = Path(root).resolve()
    findings = []
    ignores = set() if payload else read_ignores(root)
    allow_ok, allow_bad = read_allow(root)
    roster_data = load_roster(roster) if roster else None
    index = load_verse_index(refdir)

    def allowed(rel):
        return any(rel == a.rstrip("/") or rel.startswith(a if a.endswith("/") else a + "/") for a in allow_ok)

    def add(check_id, path, detail, soften=False):
        level = "주의" if soften and allowed(path) and check_id != "K1" else "차단"
        findings.append({"check": check_id, "level": level, "path": path, "detail": detail})

    if not payload:
        for req in REQUIRED_IGNORES:
            if req not in ignores:
                add("G1", ".gitignore", f"{req} 가 .gitignore 에 없습니다")
    for target in allow_bad:
        add("A1", ".publish-allow", f"{target} 줄에 사유가 없어 허용하지 않습니다 ('경로  # 사유. 승인: 이름 날짜')")

    for p in sorted(root.rglob("*")):
        if not p.is_file():
            continue
        rel_parts = p.relative_to(root).parts
        if any(part in SKIP_DIRS for part in rel_parts):
            continue
        if is_ignored(rel_parts, ignores):
            continue  # .gitignore 로 빠지는 파일은 공개 대상이 아니다
        rel = p.relative_to(root).as_posix()
        ext = p.suffix.lower()
        if ext in DATA_EXTS:
            add("D1", rel, f"실데이터 확장자({ext}) 파일이 공개 대상에 있습니다", soften=True)
        if ext in (".xlsx", ".xlsm"):
            text = xlsx_text(p)
        elif ext in TEXT_EXTS and p.stat().st_size <= MAX_TEXT_BYTES:
            text = p.read_text(encoding="utf-8", errors="replace")
        else:
            text = ""
        reason = permit_file_reason(p, ext, text)
        if reason:
            add("L1", rel, f"허가가 필요한 번역본(개역개정 등) 데이터로 보입니다: {reason}", soften=True)
        if not text:
            continue
        for f in residual_scan(text, roster=roster_data):
            add("P1", rel, f"개인정보 의심({f['type']}): {f['value']}", soften=True)
        if _MAYBE_SECRET.search(text):
            for kind, pat in SECRET_PATTERNS.items():
                for m in pat.finditer(text):
                    add("K1", rel, f"{kind} 의심: {hide(m.group(0))}")
        body = _TAG.sub("", _BREAKS.sub("\n", text)) if ext in (".html", ".htm") else text
        run, where = longest_verse_run(body, index)
        if run > MAX_QUOTE_VERSES:
            add("B1", rel, f"성경 본문이 {run}절 이어서 실려 있습니다({where}). 3절을 넘기지 않습니다", soften=True)
        if looks_like_lyrics(text, ext):
            add("H1", rel, "찬송 가사로 보이는 글이 있습니다. 장 번호와 제목만 싣습니다", soften=True)
        if ext in (".html", ".htm") and "noindex" not in text.lower():
            findings.append({"check": "R1", "level": "주의", "path": rel,
                             "detail": "noindex 메타가 없어 검색에 노출될 수 있습니다"})
    blocked = [f for f in findings if f["level"] == "차단"]
    return {"folder": root.name, "payload": payload, "verdict": "통과" if not blocked else "차단", "findings": findings}


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(__doc__)
        return 2
    payload = "--payload" in args
    roster = None
    if "--roster" in args:
        roster = args[args.index("--roster") + 1]
    elif (REFDATA / "members_sample.csv").exists():
        roster = str(REFDATA / "members_sample.csv")
    folder = [a for a in args if not a.startswith("--") and a != roster][0]
    result = check(folder, payload=payload, roster=roster)
    for f in result["findings"]:
        print(f"  [{f['level']}] {f['check']} {f['path']}: {f['detail']}")
    n = sum(f["level"] == "차단" for f in result["findings"])
    print(f"공개 판정: {result['verdict']} (차단 {n}건)")
    return 0 if result["verdict"] == "통과" else 1


if __name__ == "__main__":
    sys.exit(main())
