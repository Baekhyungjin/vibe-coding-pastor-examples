# app5-event-settle: 행사 신청 & 회비 정산 (Ch 10)

Google 설문지 응답(CSV)과 은행 거래내역(CSV 또는 xlsx)을 맞춰 참가 유형별 정산표를 만듭니다. 실행 중 AI 를 쓰지 않습니다(모드 A). 표준 라이브러리만 쓰고, xlsx 거래내역을 읽을 때만 openpyxl 이 필요합니다.

## 쓰는 법
```
python scripts/make_samples.py                 # 가짜 샘플 만들기
python scripts/verify.py                       # 하네스 (마지막 줄 RESULT)
python scripts/run.py --apps samples/golden/applicants.csv --bank samples/golden/bank.csv --expenses samples/golden/expenses.csv
python scripts/run.py --purge-contacts data/신청자.csv data/신청자_연락처삭제.csv   # 행사 종료 후
python scripts/mutation_demo.py                # 검사 장치를 검사하는 실습(복사본만 고친다)
```

## 만드는 것 (output/)
| 파일 | 내용 | 공유 |
| --- | --- | --- |
| 정산_내부용.html, .csv | 이름이 들어 있는 상세 정산표 | 이 PC 안에서만 |
| 정산_보고용.html, .txt | 인원과 금액 합계만. 이름, 개인별 금액 없음 | 단체 대화방에 올려도 됨 |

## 규칙
- 입금자명이 신청자 이름과 **정확히 하나만** 같을 때만 자동으로 짝짓습니다. 동명이인, 가족 이름, 메모 입금은 "확인 필요"입니다. 사람이 정하면 `data/manual_match.json` 에 누가, 언제, 왜 했는지 남깁니다.
- 금액은 원 단위 정수입니다. 소수점이 있으면 거부합니다.
- 헌금, 십일조 표시가 있는 입금은 행사 수입에서 뺍니다. 신청서에 건강, 종교 열이 있으면 거부합니다.
- 원본은 읽기만 하고, 정산 전후 SHA-256 이 다르면 중단합니다.

## 한계 (정직하게)
- 샘플의 입금 내역 형식은 가짜입니다. 실제 은행의 내려받기 형식은 은행마다 달라서 열 이름(입금일, 입금자명, 금액, 메모)에 맞게 고쳐 써야 할 수 있습니다.
- 자동 매칭은 이름이 정확히 같을 때만 합니다. 입금자명이 줄거나 띄어쓰기가 다르면(띄어쓰기는 지움) 확인 필요로 갑니다.
- 가짜 이름은 우연히 실존 인물과 같을 수 있습니다. 전화번호는 010-0000-0001 처럼 명백한 가짜입니다.
- 정산표의 줄바꿈과 모양은 기계가 판정하지 않습니다(CRITERIA 의 사람 확인 항목).
- 개인정보 수집 안내문은 예시이며 법률 자문이 아닙니다(`config/privacy_notice_template.md`).
