# -*- coding: utf-8 -*-
import hashlib
import json
import os
import re
import shutil
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.dont_write_bytecode = True
import settle  # noqa: E402
import verify_core  # noqa: E402

G = os.path.join(ROOT, "samples", "golden")
T = os.path.join(ROOT, "samples", "trap")
CFG = os.path.join(ROOT, "config", "fees.json")
TMP = os.path.join(ROOT, "output", "_t")           # 시스템 TEMP 대신 output/ 아래(권한 문제 방지)
EXPECTED = json.load(open(os.path.join(T, "expected.json"), encoding="utf-8"))


def trap_path(name, f):
    return os.path.join(T, name, f)


def run_trap(name, **kw):
    d = os.path.join(T, name)
    cfg_p = os.path.join(d, "fees.json")
    cfg = settle.load_config(cfg_p if os.path.exists(cfg_p) else CFG)
    apps = settle.load_applicants(os.path.join(d, "applicants.csv"), cfg)
    deps = settle.load_deposits(os.path.join(d, "bank.csv"))
    exp = settle.load_expenses(os.path.join(d, "expenses.csv"))
    return settle.settle(apps, deps, exp, cfg, kw.get("manual"))


def golden():
    cfg = settle.load_config(CFG)
    apps = settle.load_applicants(os.path.join(G, "applicants.csv"), cfg)
    deps = settle.load_deposits(os.path.join(G, "bank.csv"))
    exp = settle.load_expenses(os.path.join(G, "expenses.csv"))
    return settle.settle(apps, deps, exp, cfg), apps, deps


def fresh(name):
    p = os.path.join(TMP, name)
    shutil.rmtree(p, ignore_errors=True)
    os.makedirs(p, exist_ok=True)
    return p


class TestApp5(unittest.TestCase):
    # ---------------- 사양서 T1~T6
    def test_T1_골든_미납0_잔액이_손으로_센_정답과_같다(self):
        res, apps, deps = golden()
        key = json.load(open(os.path.join(G, "answer_key.json"), encoding="utf-8"))
        t = res["totals"]
        self.assertEqual((len(apps), len(deps)), (key["신청인원"], key["입금건수"]))
        self.assertEqual(t["미납자"], key["미납자"])
        self.assertEqual(t["받을금액"], key["받을금액"])
        self.assertEqual(t["총입금"], key["총입금"])
        self.assertEqual(t["총지출"], key["총지출"])
        self.assertEqual(t["잔액"], key["잔액"])
        self.assertEqual({k: v["인원"] for k, v in res["by_type"].items()}, key["유형별인원"])
        self.assertEqual(t["완납자"], 40)
        self.assertEqual(res["check"], [])
        verify_core.record_metric(ROOT, "골든 자동 매칭", "%d/%d" % (t["자동매칭"], len(deps)))
        verify_core.record_metric(ROOT, "골든 잔액(원)", t["잔액"])

    def test_T2_함정_동명이인과_가족명_입금은_자동매칭_0_확인필요_5(self):
        e = EXPECTED["trap_01_동명이인_가족명"]
        res = run_trap("trap_01_동명이인_가족명")
        t = res["totals"]
        self.assertEqual(t["자동매칭"], e["자동매칭"])
        self.assertEqual(t["확인필요입금"], e["확인필요입금"])
        self.assertEqual(res["check_reasons"], e["이유"])
        self.assertEqual(t["미납자"], e["미납자"])
        verify_core.record_metric(ROOT, "함정1 자동/확인필요", "%d/%d" % (t["자동매칭"], t["확인필요입금"]))

    def test_T3_이중입금과_금액부족은_초과_부족이_원단위로_정확하다(self):
        e = EXPECTED["trap_02_이중입금_부족"]
        res = run_trap("trap_02_이중입금_부족")
        t = res["totals"]
        self.assertEqual(t["초과금액"], e["초과금액"])
        self.assertEqual(t["부족금액"], e["부족금액"])
        self.assertEqual(t["받을금액"], e["받을금액"])
        self.assertEqual(t["총입금"], e["총입금"])
        self.assertEqual(t["잔액"], e["잔액"])
        flags = {}
        for c in res["check"]:
            if c["scope"] == "applicant":
                flags[c["reason"]] = flags.get(c["reason"], 0) + 1
        self.assertEqual(flags, e["표시"])

    def test_T4_총입금_빼기_총지출은_잔액이고_배정과_미배정을_더하면_총입금(self):
        for res in (golden()[0], run_trap("trap_01_동명이인_가족명"), run_trap("trap_02_이중입금_부족")):
            t = res["totals"]
            self.assertEqual(t["총입금"] - t["총지출"], t["잔액"])
            self.assertEqual(t["배정된입금"] + t["미배정입금"], t["총입금"])
            self.assertEqual(sum(v["받은금액"] for v in res["by_type"].values()), t["배정된입금"])

    def test_T5_보고용_요약에는_이름과_연락처가_0건이다(self):
        out = fresh("t5")
        res = settle.run_settlement(os.path.join(G, "applicants.csv"), os.path.join(G, "bank.csv"), os.path.join(G, "expenses.csv"),
                                    CFG, None, out)
        text = open(os.path.join(out, "정산_보고용.txt"), encoding="utf-8").read() + open(os.path.join(out, "정산_보고용.html"), encoding="utf-8").read()
        found = [a["name"] for a in res["applicants"] if a["name"] in text]
        self.assertEqual(found, [])
        self.assertIsNone(settle.PHONE_RE.search(text))
        internal = open(os.path.join(out, "정산_내부용.html"), encoding="utf-8").read()
        self.assertIn(res["applicants"][0]["name"], internal)        # 내부용에는 이름이 있어야 한다
        verify_core.record_metric(ROOT, "보고용 요약의 이름 수", len(found))

    def test_T6_정산을_돌려도_원본_파일의_해시는_그대로다(self):
        out = fresh("t6")
        paths = [os.path.join(G, f) for f in ("applicants.csv", "bank.csv", "expenses.csv")] + [CFG]
        before = {p: hashlib.sha256(open(p, "rb").read()).hexdigest() for p in paths}
        res = settle.run_settlement(paths[0], paths[1], paths[2], CFG, None, out)
        after = {p: hashlib.sha256(open(p, "rb").read()).hexdigest() for p in paths}
        self.assertEqual(before, after)
        self.assertEqual(len(res["hashes"]), 4)

    # ---------------- Never Do
    def test_N1_헌금_표시_입금은_행사_수입에_섞이지_않는다(self):
        e = EXPECTED["trap_05_헌금표시"]
        res = run_trap("trap_05_헌금표시")
        t = res["totals"]
        self.assertEqual(t["행사밖입금건수"], e["행사밖입금건수"])
        self.assertEqual(t["총입금"], e["총입금"])
        self.assertEqual(t["미납자"], e["미납자"])
        self.assertTrue(all(d["kind"] == "offering" for d in res["deposits"] if "헌금" in d["memo"] or "십일조" in d["memo"]))

    def test_N2_신청서에_건강_열이_있으면_거부한다(self):
        with self.assertRaises(settle.SettleError) as cm:
            run_trap("trap_04_건강열")
        self.assertEqual(cm.exception.code, EXPECTED["trap_04_건강열"]["오류"])

    def test_N3_소수점_금액과_소수_회비는_거부한다(self):
        with self.assertRaises(settle.SettleError) as cm:
            run_trap("trap_03_분수금액")
        self.assertEqual(cm.exception.code, EXPECTED["trap_03_분수금액"]["오류"])
        with self.assertRaises(settle.SettleError) as cm2:
            run_trap("trap_07_회비소수")
        self.assertEqual(cm2.exception.code, EXPECTED["trap_07_회비소수"]["오류"])

    def test_N4_정산_코드는_AI_네트워크_실행_모듈을_쓰지_않는다(self):
        src = open(os.path.join(ROOT, "src", "settle.py"), encoding="utf-8").read()
        imports = set(re.findall(r"^\s*(?:import|from)\s+([A-Za-z_][\w]*)", src, re.M))
        for banned in ("subprocess", "socket", "urllib", "http", "requests", "ai_call", "os.system"):
            self.assertNotIn(banned, imports)
        self.assertNotIn("os.system", src)

    def test_N5_금액_계산에_float을_쓰지_않는다(self):
        src = open(os.path.join(ROOT, "src", "settle.py"), encoding="utf-8").read()
        self.assertIsNone(re.search(r"\bfloat\s*\(", src))
        total = 0
        for _ in range(1000):
            total += settle.parse_won("33,333")
        self.assertEqual(total, 33333000)

    def test_N6_원본을_고친_정산은_멈춘다(self):
        out = fresh("n6")
        apps = os.path.join(out, "applicants.csv")
        shutil.copy(os.path.join(G, "applicants.csv"), apps)
        original = settle.file_sha256
        calls = {"n": 0}

        def sneaky(path):          # 두 번째 해시부터 다른 값을 돌려준다(원본이 바뀐 상황을 흉내)
            calls["n"] += 1
            return original(path) + ("x" if calls["n"] > 4 else "")
        settle.file_sha256 = sneaky
        try:
            with self.assertRaises(settle.SettleError) as cm:
                settle.run_settlement(apps, os.path.join(G, "bank.csv"), None, CFG, None, os.path.join(out, "o"))
        finally:
            settle.file_sha256 = original
        self.assertEqual(cm.exception.code, "SOURCE_CHANGED")

    # ---------------- 수동 지정, 동의, 연락처 삭제
    def test_S1_수동_지정은_기록이_있어야_하고_정산에_반영된다(self):
        m = {"D001": {"deposit_id": "D001", "applicant_id": "A001", "by": "한 간사", "date": "2026-11-05", "reason": "통화로 확인"}}
        res = run_trap("trap_01_동명이인_가족명", manual=m)
        t = res["totals"]
        self.assertEqual((t["수동지정"], t["자동매칭"], t["확인필요입금"]), (1, 0, 4))
        self.assertEqual(res["applicants"][0]["received"], 80000)
        out = fresh("s1")
        p = os.path.join(out, "manual_match.json")
        json.dump([{"deposit_id": "D001", "applicant_id": "A001"}], open(p, "w", encoding="utf-8"))
        with self.assertRaises(settle.SettleError) as cm:
            settle.load_manual(p)
        self.assertEqual(cm.exception.code, "MANUAL_BAD_RECORD")

    def test_S2_동의_표시가_없는_신청자는_확인필요에_오른다(self):
        out = fresh("s2")
        p = os.path.join(out, "a.csv")
        open(p, "w", encoding="utf-8-sig").write("이름,연락처,부서,참가유형,동의\n선우하린,010-0000-0001,청년부,성인,\n")
        cfg = settle.load_config(CFG)
        apps = settle.load_applicants(p, cfg)
        res = settle.settle(apps, [], [], cfg)
        self.assertIn("NO_CONSENT", [c["reason"] for c in res["check"]])

    def test_S3_연락처_삭제는_새_파일에만_하고_원본은_그대로다(self):
        out = fresh("s3")
        src = os.path.join(G, "applicants.csv")
        h = settle.file_sha256(src)
        dst = os.path.join(out, "applicants_연락처삭제.csv")
        n = settle.purge_contacts(src, dst)
        self.assertEqual(n, 40)
        _, rows = settle.read_table(dst)
        self.assertEqual({r["연락처"] for r in rows}, {""})
        self.assertEqual(rows[0]["이름"], settle.read_table(src)[1][0]["이름"])
        self.assertEqual(settle.file_sha256(src), h)
        with self.assertRaises(settle.SettleError) as cm:
            settle.purge_contacts(src, src)
        self.assertEqual(cm.exception.code, "PURGE_SAME_FILE")

    def test_S4_xlsx_거래내역도_읽는다(self):
        import openpyxl
        out = fresh("s4")
        p = os.path.join(out, "bank.xlsx")
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.append(["입금일", "입금자명", "금액", "메모"])
        ws.append(["2026-11-02", "선우하린", 80000, ""])
        ws.append(["2026-11-03", "제갈도율", "50,000", "수련회"])
        wb.save(p)
        deps = settle.load_deposits(p)
        self.assertEqual([d["amount"] for d in deps], [80000, 50000])

    # ---------------- 하네스 자체를 검사하는 시험
    def test_H2_함정마다_expected_json의_이유로_걸린다(self):
        names = [k for k in EXPECTED if k.startswith("trap_")]
        self.assertGreaterEqual(len(names), 7)
        reasons = {}
        for name in names:
            e = EXPECTED[name]
            if "오류" in e:
                try:
                    run_trap(name)
                    reasons[name] = "통과해 버림"
                except settle.SettleError as ex:
                    reasons[name] = ex.code
                self.assertEqual(reasons[name], e["오류"], name)
            elif "보고용검사" in e:
                d = os.path.join(T, name)
                cfg = settle.load_config(CFG)
                apps = settle.load_applicants(os.path.join(d, "applicants.csv"), cfg)
                text = open(os.path.join(d, "report.txt"), encoding="utf-8").read()
                self.assertEqual(settle.check_report_clean(text, apps), e["보고용검사"], name)
            else:
                run_trap(name)       # 정산은 되지만 숫자가 다른 함정은 T2, T3, N1 이 이유까지 비교한다
        self.assertEqual({v for k, v in reasons.items()}, {"AMOUNT_NOT_INTEGER", "SENSITIVE_COLUMN", "CONFIG_FEE_NOT_INT"})

    def test_H3_골든_보고용_글은_검사기를_통과한다(self):
        res, apps, _ = golden()
        self.assertEqual(settle.check_report_clean("\n".join(settle.summary_lines(res)), apps), [])

    def test_G1_개인정보_파일은_gitignore에_있다(self):
        gi = open(os.path.join(ROOT, ".gitignore"), encoding="utf-8").read()
        for pat in ("data/*", "output/", ".env"):
            self.assertIn(pat, gi)


if __name__ == "__main__":
    unittest.main()
