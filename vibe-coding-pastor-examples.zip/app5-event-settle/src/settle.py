# -*- coding: utf-8 -*-
"""교회 행사 회비 정산 (모드 A: 실행 중 AI 미사용, 표준 라이브러리 중심).

- 금액은 모두 int(원 단위). 부동소수(float)로 계산하지 않는다.
- 헌금 내역은 다루지 않는다. 헌금 표시가 있는 입금은 행사 수입에서 뺀다.
- 원본 파일은 읽기만 한다. 실행 전후 SHA-256 이 다르면 중단한다.
- 입금자명이 신청자명과 정확히 하나만 같을 때만 자동으로 짝짓는다. 나머지는 사람이 확인한다.
"""
import csv
import hashlib
import html
import io
import json
import os
import re
from decimal import Decimal, InvalidOperation

CONSENT_YES = {"예", "네", "y", "yes", "동의", "동의함", "o", "true", "1"}
# 행사 신청서에 있으면 안 되는 열 이름(일부 글자). 꼭 필요하면 config 의 "허용열" 에 열 이름을 직접 적는다.
SENSITIVE = ("건강", "질병", "질환", "병력", "알레르기", "종교", "세례", "신앙", "헌금")
OFFERING_WORDS = ("헌금", "십일조")
APP_COLS = ("이름", "연락처", "부서", "참가유형", "동의")
BANK_COLS = ("입금일", "입금자명", "금액", "메모")
EXP_COLS = ("항목", "금액")
PHONE_RE = re.compile(r"0\d{1,2}[-\s.]?\d{3,4}[-\s.]?\d{4}")

STATUS_PAID, STATUS_NONE, STATUS_SHORT, STATUS_OVER = "완납", "미납", "부족", "초과"


class SettleError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def norm_name(s):
    return re.sub(r"\s+", "", str(s if s is not None else ""))


def file_sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------ 읽기
def read_table(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
        rows = [["" if c is None else c for c in r] for r in wb.worksheets[0].iter_rows(values_only=True)]
        wb.close()
    else:
        raw = open(path, "rb").read()
        text = None
        for enc in ("utf-8-sig", "cp949"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            raise SettleError("ENCODING", "UTF-8 도 CP949 도 아닙니다: %s" % os.path.basename(path))
        rows = list(csv.reader(io.StringIO(text)))
    rows = [r for r in rows if any(str(c).strip() for c in r)]
    if not rows:
        raise SettleError("EMPTY_FILE", "빈 파일입니다: %s" % os.path.basename(path))
    header = [str(h).strip() for h in rows[0]]
    body = []
    for r in rows[1:]:
        r = list(r) + [""] * (len(header) - len(r))
        body.append({header[i]: r[i] for i in range(len(header))})
    return header, body


def parse_won(value, where=""):
    """원 단위 정수만 허용한다. 소수점이 있으면 거부한다."""
    s = str(value).strip().replace(",", "").replace("원", "").replace(" ", "")
    if s == "":
        raise SettleError("AMOUNT_EMPTY", "금액이 비어 있습니다 %s" % where)
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise SettleError("AMOUNT_NOT_NUMBER", "금액을 숫자로 읽을 수 없습니다: %r %s" % (value, where))
    if d != d.to_integral_value():
        raise SettleError("AMOUNT_NOT_INTEGER", "금액은 원 단위 정수여야 합니다: %r %s" % (value, where))
    if d < 0:
        raise SettleError("AMOUNT_NEGATIVE", "금액이 음수입니다: %r %s" % (value, where))
    return int(d)


def _need_columns(header, needed, label):
    miss = [c for c in needed if c not in header]
    if miss:
        raise SettleError("MISSING_COLUMN", "%s 파일에 열이 없습니다: %s" % (label, ", ".join(miss)))


def load_config(path):
    cfg = json.load(open(path, encoding="utf-8"))
    fees = cfg.get("회비")
    if not isinstance(fees, dict) or not fees:
        raise SettleError("CONFIG_NO_FEES", "config 에 '회비' 표가 없습니다")
    for t, v in fees.items():
        if isinstance(v, bool) or not isinstance(v, int) or v < 0:
            raise SettleError("CONFIG_FEE_NOT_INT", "회비 '%s' 는 원 단위 정수여야 합니다: %r" % (t, v))
    cfg.setdefault("허용열", [])
    cfg.setdefault("행사명", "행사")
    return cfg


def load_applicants(path, cfg):
    header, rows = read_table(path)
    _need_columns(header, APP_COLS, "신청자")
    allowed = set(cfg.get("허용열", []))
    for h in header:
        if h in allowed:
            continue
        if any(k in h for k in SENSITIVE):
            raise SettleError("SENSITIVE_COLUMN", "수집하면 안 되는 열이 있습니다: '%s' (건강, 종교 정보는 받지 않습니다)" % h)
    apps = []
    for i, r in enumerate(rows, 1):
        t = str(r["참가유형"]).strip()
        if t not in cfg["회비"]:
            raise SettleError("UNKNOWN_TYPE", "회비표에 없는 참가 유형입니다: '%s' (행 %d)" % (t, i + 1))
        apps.append({
            "id": "A%03d" % i,
            "name": norm_name(r["이름"]),
            "dept": str(r["부서"]).strip(),
            "type": t,
            "fee": cfg["회비"][t],
            "consent": str(r["동의"]).strip().lower() in CONSENT_YES,
        })
    return apps


def load_deposits(path):
    header, rows = read_table(path)
    _need_columns(header, BANK_COLS, "거래내역")
    deps = []
    for i, r in enumerate(rows, 1):
        did = "D%03d" % i
        payer = norm_name(r["입금자명"])
        memo = str(r["메모"]).strip()
        text = payer + memo
        deps.append({
            "id": did,
            "date": str(r["입금일"]).strip(),
            "payer": payer,
            "amount": parse_won(r["금액"], "(%s)" % did),
            "memo": memo,
            "offering": any(w in text for w in OFFERING_WORDS),
        })
    return deps


def load_expenses(path):
    if not path or not os.path.exists(path):
        return []
    header, rows = read_table(path)
    _need_columns(header, EXP_COLS, "지출")
    return [{"item": str(r["항목"]).strip(), "amount": parse_won(r["금액"], "(지출 %s)" % r["항목"])} for r in rows]


def load_manual(path):
    if not path or not os.path.exists(path):
        return {}
    data = json.load(open(path, encoding="utf-8"))
    out = {}
    for rec in data:
        for k in ("deposit_id", "applicant_id", "by", "date", "reason"):
            if not str(rec.get(k, "")).strip():
                raise SettleError("MANUAL_BAD_RECORD", "수동 지정 기록에 '%s' 가 없습니다: %r" % (k, rec))
        if rec["deposit_id"] in out:
            raise SettleError("MANUAL_BAD_RECORD", "같은 입금을 두 번 지정했습니다: %s" % rec["deposit_id"])
        out[rec["deposit_id"]] = rec
    return out


# ------------------------------------------------------------------ 짝짓기와 정산
def assign(apps, deps, manual):
    by_name, by_id = {}, {a["id"]: a for a in apps}
    for a in apps:
        by_name.setdefault(a["name"], []).append(a)
    for d in deps:
        if d["offering"]:
            d.update(kind="offering", reason="OFFERING_MARK", app=None, hint="")
        elif d["id"] in manual:
            aid = manual[d["id"]]["applicant_id"]
            if aid not in by_id:
                raise SettleError("MANUAL_BAD_APPLICANT", "없는 신청자입니다: %s" % aid)
            d.update(kind="manual", reason="MANUAL", app=aid, hint="")
        else:
            cands = by_name.get(d["payer"], [])
            if len(cands) == 1:
                d.update(kind="auto", reason="NAME_EXACT", app=cands[0]["id"], hint="")
            elif len(cands) > 1:
                d.update(kind="check", reason="SAME_NAME", app=None, hint="같은 이름 %d명" % len(cands))
            else:
                found = sorted({a["name"] for a in apps if a["name"] and a["name"] in d["payer"] + norm_name(d["memo"])})
                d.update(kind="check", reason="NO_NAME_MATCH", app=None,
                         hint=("이름이 들어 있는 신청자: " + ", ".join(found)) if found else "")
    return deps


def settle(apps, deps, expenses, cfg, manual=None):
    manual = manual or {}
    assign(apps, deps, manual)
    got = {a["id"]: [] for a in apps}
    for d in deps:
        if d["kind"] in ("auto", "manual"):
            got[d["app"]].append(d)
    check = []
    for a in apps:
        ds = got[a["id"]]
        a["received"] = sum(d["amount"] for d in ds)
        a["deposit_ids"] = [d["id"] for d in ds]
        diff = a["received"] - a["fee"]
        if a["received"] == 0:
            a["status"], a["diff"] = STATUS_NONE, a["fee"]
        elif diff == 0:
            a["status"], a["diff"] = STATUS_PAID, 0
        elif diff < 0:
            a["status"], a["diff"] = STATUS_SHORT, -diff
        else:
            a["status"], a["diff"] = STATUS_OVER, diff
        a["flags"] = []
        if len(ds) >= 2:
            a["flags"].append("DOUBLE")
        if a["status"] == STATUS_SHORT:
            a["flags"].append("SHORT")
        if a["status"] == STATUS_OVER:
            a["flags"].append("OVER")
        if not a["consent"]:
            a["flags"].append("NO_CONSENT")
        for f in a["flags"]:
            check.append({"scope": "applicant", "id": a["id"], "reason": f, "name": a["name"], "amount": a["received"], "hint": ""})
    for d in deps:
        if d["kind"] == "check":
            check.append({"scope": "deposit", "id": d["id"], "reason": d["reason"], "name": d["payer"],
                          "amount": d["amount"], "hint": d["hint"], "memo": d["memo"]})
    by_type = {}
    for t, fee in cfg["회비"].items():
        grp = [a for a in apps if a["type"] == t]
        by_type[t] = {
            "회비": fee,
            "인원": len(grp),
            "받을금액": sum(a["fee"] for a in grp),
            "받은금액": sum(a["received"] for a in grp),
            "미납자": sum(1 for a in grp if a["status"] == STATUS_NONE),
            "부족자": sum(1 for a in grp if a["status"] == STATUS_SHORT),
            "초과자": sum(1 for a in grp if a["status"] == STATUS_OVER),
            "초과금액": sum(a["diff"] for a in grp if a["status"] == STATUS_OVER),
            "부족금액": sum(a["diff"] for a in grp if a["status"] == STATUS_SHORT),
        }
    matched = sum(a["received"] for a in apps)
    unassigned = sum(d["amount"] for d in deps if d["kind"] == "check")
    offering = [d for d in deps if d["kind"] == "offering"]
    total_in = matched + unassigned
    total_out = sum(e["amount"] for e in expenses)
    totals = {
        "신청인원": len(apps),
        "받을금액": sum(a["fee"] for a in apps),
        "배정된입금": matched,
        "미배정입금": unassigned,
        "총입금": total_in,
        "총지출": total_out,
        "잔액": total_in - total_out,
        "미납자": sum(1 for a in apps if a["status"] == STATUS_NONE),
        "미납액": sum(a["diff"] for a in apps if a["status"] == STATUS_NONE),
        "부족자": sum(1 for a in apps if a["status"] == STATUS_SHORT),
        "부족금액": sum(a["diff"] for a in apps if a["status"] == STATUS_SHORT),
        "초과자": sum(1 for a in apps if a["status"] == STATUS_OVER),
        "초과금액": sum(a["diff"] for a in apps if a["status"] == STATUS_OVER),
        "완납자": sum(1 for a in apps if a["status"] == STATUS_PAID),
        "행사밖입금건수": len(offering),
        "행사밖입금액": sum(d["amount"] for d in offering),
        "자동매칭": sum(1 for d in deps if d["kind"] == "auto"),
        "수동지정": sum(1 for d in deps if d["kind"] == "manual"),
        "확인필요입금": sum(1 for d in deps if d["kind"] == "check"),
    }
    non_offering = sum(d["amount"] for d in deps if d["kind"] != "offering")
    if total_in != non_offering:
        raise SettleError("INTERNAL_MISMATCH", "총입금(%d)과 헌금 표시를 뺀 입금 합계(%d)가 다릅니다" % (total_in, non_offering))
    reasons = {}
    for c in check:
        reasons[c["reason"]] = reasons.get(c["reason"], 0) + 1
    return {"cfg": cfg, "applicants": apps, "deposits": deps, "expenses": expenses, "check": check,
            "check_reasons": reasons, "by_type": by_type, "totals": totals}


# ------------------------------------------------------------------ 출력
def won(n):
    return "{:,}원".format(n)


REASON_TEXT = {
    "SAME_NAME": "같은 이름의 신청자가 둘 이상입니다",
    "NO_NAME_MATCH": "입금자명이 신청자 이름과 다릅니다(가족명, 메모 입금 등)",
    "DOUBLE": "같은 사람 앞으로 입금이 두 건 이상입니다",
    "SHORT": "받을 금액보다 적게 들어왔습니다",
    "OVER": "받을 금액보다 많이 들어왔습니다",
    "NO_CONSENT": "개인정보 수집 동의 표시가 없습니다",
}

CSS = ("@page{size:A5;margin:9mm}body{font-family:'Malgun Gothic','Noto Sans KR',sans-serif;color:#1b2333;font-size:10.5px;line-height:1.5}"
       "h1{font-size:17px;margin:0 0 2px}h2{font-size:12.5px;margin:14px 0 4px;border-bottom:1.5px solid #1b2333;padding-bottom:2px}"
       "table{border-collapse:collapse;width:100%;margin:4px 0}th,td{border:1px solid #b9bfcc;padding:3px 5px;text-align:left}"
       "th{background:#e6e9f0;white-space:nowrap}td.n{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}"
       ".note{background:#f4f1e4;border-left:3px solid #c0261a;padding:4px 8px;margin:6px 0}.ok{color:#14673d;font-weight:700}"
       ".bad{color:#b3261b;font-weight:700}.warn{color:#8a5a00;font-weight:700}small{color:#5a6377}")


def _page(title, body):
    return ("<!doctype html><html lang='ko'><head><meta charset='utf-8'><title>%s</title><style>%s</style></head><body>%s</body></html>"
            % (html.escape(title), CSS, body))


def _type_table(res):
    rows = "".join(
        "<tr><td>%s</td><td class='n'>%d</td><td class='n'>%s</td><td class='n'>%s</td><td class='n'>%d</td><td class='n'>%d</td><td class='n'>%d</td></tr>"
        % (html.escape(t), v["인원"], won(v["받을금액"]), won(v["받은금액"]), v["미납자"], v["부족자"], v["초과자"])
        for t, v in res["by_type"].items())
    return ("<table><tr><th>참가 유형</th><th>인원</th><th>받을 금액</th><th>받은 금액</th><th>미납</th><th>부족</th><th>초과</th></tr>%s</table>" % rows)


def _totals_table(res):
    t = res["totals"]
    rows = [("총 입금", t["총입금"]), ("총 지출", t["총지출"]), ("잔액 (총 입금 - 총 지출)", t["잔액"])]
    return "<table>%s</table>" % "".join("<tr><th>%s</th><td class='n'>%s</td></tr>" % (k, won(v)) for k, v in rows)


def render_internal_html(res):
    t = res["totals"]
    body = ["<h1>%s 정산 (내부용)</h1>" % html.escape(res["cfg"]["행사명"]),
            "<div class='note'>이 파일에는 이름이 들어 있습니다. 이 PC 밖으로 보내지 마세요. 공유는 '보고용' 파일로 합니다.</div>",
            "<h2>1. 참가 유형별</h2>", _type_table(res), "<h2>2. 수입과 지출</h2>", _totals_table(res),
            "<small>배정된 입금 %s + 확인 필요 입금 %s = 총 입금 %s</small>" % (won(t["배정된입금"]), won(t["미배정입금"]), won(t["총입금"]))]
    body.append("<h2>3. 확인 필요 (%d건)</h2>" % len(res["check"]))
    if res["check"]:
        rows = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td>%s</td></tr>" % (
            c["id"], html.escape(c["name"]), html.escape(REASON_TEXT.get(c["reason"], c["reason"])), won(c["amount"]), html.escape(c.get("hint", "")))
            for c in res["check"])
        body.append("<table><tr><th>번호</th><th>이름/입금자</th><th>이유</th><th>금액</th><th>참고</th></tr>%s</table>" % rows)
    else:
        body.append("<p class='ok'>확인할 것이 없습니다.</p>")
    body.append("<h2>4. 신청자별</h2>")
    cls = {STATUS_PAID: "ok", STATUS_NONE: "bad", STATUS_SHORT: "warn", STATUS_OVER: "warn"}
    rows = "".join("<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td class='n'>%s</td><td class='n'>%s</td><td class='%s'>%s</td><td class='n'>%s</td></tr>" % (
        a["id"], html.escape(a["name"]), html.escape(a["dept"]), html.escape(a["type"]), won(a["fee"]), won(a["received"]),
        cls[a["status"]], a["status"], won(a["diff"]) if a["diff"] else "") for a in res["applicants"])
    body.append("<table><tr><th>번호</th><th>이름</th><th>부서</th><th>유형</th><th>받을</th><th>받은</th><th>상태</th><th>차액</th></tr>%s</table>" % rows)
    return _page("정산 내부용", "".join(body))


def summary_lines(res):
    t = res["totals"]
    lines = ["[%s 정산 보고]" % res["cfg"]["행사명"], "신청 %d명" % t["신청인원"]]
    for name, v in res["by_type"].items():
        lines.append("- %s %d명 (받을 금액 %s, 받은 금액 %s)" % (name, v["인원"], won(v["받을금액"]), won(v["받은금액"])))
    lines += ["완납 %d명, 미납 %d명, 일부 입금 %d명, 초과 입금 %d명" % (t["완납자"], t["미납자"], t["부족자"], t["초과자"]),
              "총 입금 %s" % won(t["총입금"]), "총 지출 %s" % won(t["총지출"]), "잔액 %s" % won(t["잔액"]),
              "사람이 확인할 입금 %d건 (%s)" % (t["확인필요입금"], won(t["미배정입금"])),
              "행사와 무관해 제외한 입금 %d건" % t["행사밖입금건수"],
              "이 보고에는 이름과 개인별 금액이 없습니다."]
    return lines


def render_summary_html(res):
    t = res["totals"]
    body = ["<h1>%s 정산 보고</h1>" % html.escape(res["cfg"]["행사명"]),
            "<div class='note'>이 파일에는 이름과 개인별 금액이 없습니다. 단체 대화방에 올려도 됩니다.</div>",
            "<h2>참가 유형별</h2>", _type_table(res), "<h2>수입과 지출</h2>", _totals_table(res),
            "<p>완납 %d명, 미납 %d명, 일부 입금 %d명, 초과 입금 %d명</p>" % (t["완납자"], t["미납자"], t["부족자"], t["초과자"]),
            "<p>사람이 확인할 입금 %d건(%s) / 행사와 무관해 제외한 입금 %d건</p>" % (t["확인필요입금"], won(t["미배정입금"]), t["행사밖입금건수"])]
    return _page("정산 보고용", "".join(body))


def render_internal_csv(res):
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(["번호", "이름", "부서", "유형", "받을금액", "받은금액", "상태", "차액", "입금번호", "표시"])
    for a in res["applicants"]:
        w.writerow([a["id"], a["name"], a["dept"], a["type"], a["fee"], a["received"], a["status"], a["diff"],
                    " ".join(a["deposit_ids"]), " ".join(a["flags"])])
    return out.getvalue()


def check_report_clean(text, apps):
    """보고용 글에 이름, 전화번호가 있는지 본다. 위반 코드 목록을 돌려준다."""
    bad = set()
    for a in apps:
        if a["name"] and a["name"] in text:
            bad.add("NAME")
    if PHONE_RE.search(text):
        bad.add("PHONE")
    return sorted(bad)


def purge_contacts(in_path, out_path, col="연락처"):
    """행사가 끝난 뒤 연락처 열을 비운 '새 파일'을 만든다. 원본은 고치지 않는다."""
    if os.path.abspath(in_path) == os.path.abspath(out_path):
        raise SettleError("PURGE_SAME_FILE", "원본을 덮어쓰지 않습니다. 다른 파일 이름을 쓰세요")
    header, rows = read_table(in_path)
    if col not in header:
        raise SettleError("MISSING_COLUMN", "'%s' 열이 없습니다" % col)
    with open(out_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            r[col] = ""
            w.writerow([r[h] for h in header])
    return len(rows)


def run_settlement(apps_path, bank_path, exp_path, cfg_path, manual_path, out_dir):
    srcs = [p for p in (apps_path, bank_path, exp_path, cfg_path, manual_path) if p and os.path.exists(p)]
    before = {p: file_sha256(p) for p in srcs}
    cfg = load_config(cfg_path)
    apps = load_applicants(apps_path, cfg)
    deps = load_deposits(bank_path)
    res = settle(apps, deps, load_expenses(exp_path), cfg, load_manual(manual_path))
    os.makedirs(out_dir, exist_ok=True)
    text = "\n".join(summary_lines(res))
    page = render_summary_html(res)
    leak = check_report_clean(text + page, apps)
    if leak:
        raise SettleError("REPORT_LEAK", "보고용 요약에 개인정보가 섞였습니다: %s" % ",".join(leak))
    for name, content in (("정산_내부용.html", render_internal_html(res)), ("정산_내부용.csv", render_internal_csv(res)),
                          ("정산_보고용.html", page), ("정산_보고용.txt", text + "\n")):
        with open(os.path.join(out_dir, name), "w", encoding="utf-8-sig" if name.endswith(".csv") else "utf-8", newline="") as f:
            f.write(content)
    after = {p: file_sha256(p) for p in srcs}
    if before != after:
        raise SettleError("SOURCE_CHANGED", "원본 파일이 바뀌었습니다. 정산을 믿지 마세요")
    res["hashes"] = {os.path.basename(p): h[:12] for p, h in before.items()}
    return res
