# -*- coding: utf-8 -*-
"""가짜 샘플을 만든다. 이름, 전화번호는 모두 지어낸 것이며 우연히 실존 인물과 같을 수 있다.
정답표(answer_key.json, expected.json)는 settle.py 를 부르지 않고 손으로 센 값이다."""
import csv
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(ROOT, "samples", "golden")
T = os.path.join(ROOT, "samples", "trap")

SUR = ["남궁", "선우", "제갈", "황보", "독고", "사공"]
GIV = ["하린", "도율", "시안", "예준", "서아", "이현", "지후", "아윤"]


def names():
    pool = [s + g for s in SUR for g in GIV]
    seed, out = 11, []
    while pool:
        seed = (seed * 1103515245 + 12345) & 0x7FFFFFFF
        out.append(pool.pop(seed % len(pool)))
    return out


NAMES = names()
DEPTS = ["장년부", "청년부", "청소년부", "어린이부", "새가족부"]


def w(path, header, rows):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        cw = csv.writer(f)
        cw.writerow(header)
        cw.writerows(rows)


def phone(i):
    return "010-0000-%04d" % i


def apps_rows(items):
    """items: [(이름, 유형, 동의)]"""
    return [[n, phone(i + 1), DEPTS[i % 5], t, c] for i, (n, t, c) in enumerate(items)]


H_APP = ["이름", "연락처", "부서", "참가유형", "동의"]
H_BANK = ["입금일", "입금자명", "금액", "메모"]
FEES = {"성인": 80000, "청소년": 50000, "어린이": 30000}


def main():
    # ---- 골든: 신청 40명, 입금 40건 (성인 20, 청소년 12, 어린이 8)
    types = ["성인"] * 20 + ["청소년"] * 12 + ["어린이"] * 8
    w(os.path.join(G, "applicants.csv"), H_APP, apps_rows([(NAMES[i], types[i], "예") for i in range(40)]))
    bank = []
    for i in range(40):
        amt = FEES[types[i]]
        shown = "{:,}".format(amt) if i % 3 else str(amt)          # 쉼표 있는 표기와 없는 표기를 섞는다
        payer = NAMES[i] + (" " if i % 7 == 0 else "")             # 끝에 공백이 붙은 입금자명도 섞는다
        bank.append(["2026-11-%02d" % (1 + i % 9), payer, shown, "수련회 회비" if i % 4 == 0 else ""])
    w(os.path.join(G, "bank.csv"), H_BANK, bank)
    w(os.path.join(G, "expenses.csv"), ["항목", "금액"], [["숙소 대관", "1,300,000"], ["식비", "700000"], ["버스 임차", "250,000"]])
    key = {
        "설명": "손으로 센 정답. settle.py 를 부르지 않고 만들었다.",
        "신청인원": 40, "입금건수": 40,
        "유형별인원": {"성인": 20, "청소년": 12, "어린이": 8},
        "받을금액": 20 * 80000 + 12 * 50000 + 8 * 30000,
        "총입금": 20 * 80000 + 12 * 50000 + 8 * 30000,
        "총지출": 1300000 + 700000 + 250000,
        "잔액": 2440000 - 2250000,
        "미납자": 0,
    }
    json.dump(key, open(os.path.join(G, "answer_key.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    # ---- 함정 1: 동명이인 2쌍 + 가족명/메모 입금 3건 -> 자동 매칭 0, 확인 필요 5
    d = os.path.join(T, "trap_01_동명이인_가족명")
    a = [(NAMES[0], "성인", "예"), (NAMES[0], "청소년", "예"), (NAMES[1], "성인", "예"), (NAMES[1], "어린이", "예"),
         (NAMES[2], "어린이", "예"), (NAMES[3], "어린이", "예"), (NAMES[4], "청소년", "예")]
    w(os.path.join(d, "applicants.csv"), H_APP, apps_rows(a))
    w(os.path.join(d, "bank.csv"), H_BANK, [
        ["2026-11-02", NAMES[0], "80,000", ""], ["2026-11-02", NAMES[1], "80000", ""],
        ["2026-11-03", NAMES[10], "30,000", "수련회 (%s)" % NAMES[2]],
        ["2026-11-03", NAMES[11], "30,000", ""],
        ["2026-11-04", NAMES[4] + "수련회", "50,000", ""]])

    # ---- 함정 2: 이중 입금 1건, 금액 부족 1건
    d = os.path.join(T, "trap_02_이중입금_부족")
    a = [(NAMES[20], "성인", "예"), (NAMES[21], "성인", "예"), (NAMES[22], "성인", "예"), (NAMES[23], "청소년", "예"), (NAMES[24], "어린이", "예")]
    w(os.path.join(d, "applicants.csv"), H_APP, apps_rows(a))
    w(os.path.join(d, "bank.csv"), H_BANK, [
        ["2026-11-02", NAMES[20], "80,000", ""], ["2026-11-02", NAMES[21], "80,000", ""],
        ["2026-11-03", NAMES[22], "80,000", ""], ["2026-11-05", NAMES[22], "80,000", "다시 보냄"],
        ["2026-11-03", NAMES[23], "20,000", ""], ["2026-11-04", NAMES[24], "30,000", ""]])
    w(os.path.join(d, "expenses.csv"), ["항목", "금액"], [["간식", "100,000"]])

    # ---- 함정 3: 소수점 금액
    d = os.path.join(T, "trap_03_분수금액")
    w(os.path.join(d, "applicants.csv"), H_APP, apps_rows([(NAMES[30], "성인", "예"), (NAMES[31], "성인", "예")]))
    w(os.path.join(d, "bank.csv"), H_BANK, [["2026-11-02", NAMES[30], "80,000", ""], ["2026-11-02", NAMES[31], "80,000.50", ""]])

    # ---- 함정 4: 신청서에 건강 열
    d = os.path.join(T, "trap_04_건강열")
    w(os.path.join(d, "applicants.csv"), H_APP + ["건강상태"], [r + ["있음"] for r in apps_rows([(NAMES[32], "성인", "예")])])
    w(os.path.join(d, "bank.csv"), H_BANK, [["2026-11-02", NAMES[32], "80,000", ""]])

    # ---- 함정 5: 헌금 표시 입금
    d = os.path.join(T, "trap_05_헌금표시")
    w(os.path.join(d, "applicants.csv"), H_APP, apps_rows([(NAMES[33], "성인", "예"), (NAMES[34], "성인", "예"), (NAMES[35], "성인", "예")]))
    w(os.path.join(d, "bank.csv"), H_BANK, [
        ["2026-11-02", NAMES[33], "80,000", ""], ["2026-11-02", NAMES[34], "80,000", ""],
        ["2026-11-03", NAMES[35], "80,000", "주일헌금"], ["2026-11-03", NAMES[36], "100,000", "십일조"]])

    # ---- 함정 6: 이름과 전화번호가 섞인 '보고용' 글
    d = os.path.join(T, "trap_06_보고용_이름유출")
    w(os.path.join(d, "applicants.csv"), H_APP, apps_rows([(NAMES[37], "성인", "예"), (NAMES[38], "성인", "예")]))
    os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "report.txt"), "w", encoding="utf-8").write(
        "[가상 수련회 정산 보고]\n입금 확인: %s 80,000원\n연락처 010-0000-0001\n" % NAMES[37])

    # ---- 함정 7: 회비표에 소수
    d = os.path.join(T, "trap_07_회비소수")
    w(os.path.join(d, "applicants.csv"), H_APP, apps_rows([(NAMES[39], "청소년", "예")]))
    w(os.path.join(d, "bank.csv"), H_BANK, [["2026-11-02", NAMES[39], "50,000", ""]])
    json.dump({"행사명": "가상교회 수련회", "회비": {"성인": 80000, "청소년": 49999.5, "어린이": 30000}, "허용열": []},
              open(os.path.join(d, "fees.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)

    expected = {
        "_설명": "함정마다 '어떤 이유로' 걸려야 하는지. 엉뚱한 이유로 걸리면 실패로 본다.",
        "trap_01_동명이인_가족명": {"자동매칭": 0, "확인필요입금": 5, "이유": {"SAME_NAME": 2, "NO_NAME_MATCH": 3}, "미납자": 7},
        "trap_02_이중입금_부족": {"표시": {"DOUBLE": 1, "SHORT": 1, "OVER": 1}, "초과금액": 80000, "부족금액": 30000,
                           "총입금": 370000, "받을금액": 320000, "잔액": 270000},
        "trap_03_분수금액": {"오류": "AMOUNT_NOT_INTEGER"},
        "trap_04_건강열": {"오류": "SENSITIVE_COLUMN"},
        "trap_05_헌금표시": {"행사밖입금건수": 2, "총입금": 160000, "미납자": 1},
        "trap_06_보고용_이름유출": {"보고용검사": ["NAME", "PHONE"]},
        "trap_07_회비소수": {"오류": "CONFIG_FEE_NOT_INT"},
    }
    json.dump(expected, open(os.path.join(T, "expected.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print("샘플 생성 완료")


if __name__ == "__main__":
    main()
