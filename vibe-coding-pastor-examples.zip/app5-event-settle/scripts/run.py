# -*- coding: utf-8 -*-
"""행사 회비 정산 실행기.

정산:
  python scripts/run.py --apps data/신청자.csv --bank data/거래내역.csv [--expenses data/지출.csv]
                        [--config config/fees.json] [--manual data/manual_match.json] [--out output]
연락처 삭제(행사 종료 후, 새 파일을 만든다):
  python scripts/run.py --purge-contacts data/신청자.csv data/신청자_연락처삭제.csv
"""
import argparse
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

import settle  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--apps")
    ap.add_argument("--bank")
    ap.add_argument("--expenses")
    ap.add_argument("--config", default=os.path.join(ROOT, "config", "fees.json"))
    ap.add_argument("--manual", default=os.path.join(ROOT, "data", "manual_match.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "output"))
    ap.add_argument("--purge-contacts", nargs=2, metavar=("원본", "새파일"))
    a = ap.parse_args()
    try:
        if a.purge_contacts:
            n = settle.purge_contacts(*a.purge_contacts)
            print("연락처를 비운 새 파일을 만들었습니다: %d명. 원본은 그대로입니다. 원본 삭제는 직접 하세요." % n)
            return 0
        if not (a.apps and a.bank):
            ap.error("--apps 와 --bank 가 필요합니다")
        res = settle.run_settlement(a.apps, a.bank, a.expenses, a.config, a.manual, a.out)
    except settle.SettleError as e:
        print("정산 중단 [%s] %s" % (e.code, e), file=sys.stderr)
        return 2
    t = res["totals"]
    print("신청 %d명 / 총 입금 %s / 총 지출 %s / 잔액 %s" % (t["신청인원"], settle.won(t["총입금"]), settle.won(t["총지출"]), settle.won(t["잔액"])))
    print("자동 매칭 %d건, 수동 지정 %d건, 사람이 확인할 입금 %d건, 행사와 무관해 제외 %d건" % (t["자동매칭"], t["수동지정"], t["확인필요입금"], t["행사밖입금건수"]))
    print("완납 %d / 미납 %d / 일부 입금 %d / 초과 %d" % (t["완납자"], t["미납자"], t["부족자"], t["초과자"]))
    print("확인 필요 %d건: %s" % (len(res["check"]), res["check_reasons"]))
    print("원본 해시(앞 12자리): %s" % res["hashes"])
    print("만든 파일: %s" % ", ".join(sorted(f for f in os.listdir(a.out) if f.startswith("정산_"))))
    return 0


if __name__ == "__main__":
    sys.exit(main())
