# -*- coding: utf-8 -*-
"""검사 장치를 검사하는 실습: 복사본의 settle.py 를 일부러 느슨하게 고쳐 하네스가 실제로 실패하는지 본다.
원본 폴더는 건드리지 않는다(복사본은 output/_demo_<이름>/ 에 만든다).

사용: python scripts/mutation_demo.py
"""
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

MUTATIONS = [
    ("m1_이름이_들어있으면_자동매칭",
     'cands = by_name.get(d["payer"], [])',
     'cands = by_name.get(d["payer"], []) or [a for a in apps if a["name"] and a["name"] in d["payer"] + norm_name(d["memo"])][:1]'),
    ("m2_소수점_금액을_반올림",
     '    if d != d.to_integral_value():\n        raise SettleError("AMOUNT_NOT_INTEGER", "금액은 원 단위 정수여야 합니다: %r %s" % (value, where))',
     '    d = d.to_integral_value()'),
    ("m3_헌금_표시를_무시",
     'OFFERING_WORDS = ("헌금", "십일조")',
     'OFFERING_WORDS = ("@@없음@@",)'),
    ("m4_수동지정_기록_검사_삭제",
     '            if not str(rec.get(k, "")).strip():',
     '            if False:'),
]


def main():
    for name, find, rep in MUTATIONS:
        d = os.path.join(ROOT, "output", "_demo_" + name)
        shutil.rmtree(d, ignore_errors=True)
        os.makedirs(os.path.join(d, "output"))
        for part in ("src", "scripts", "tests", "config", "samples", ".gitignore"):
            s = os.path.join(ROOT, part)
            t = os.path.join(d, part)
            shutil.copytree(s, t) if os.path.isdir(s) else shutil.copy(s, t)
        f = os.path.join(d, "src", "settle.py")
        text = open(f, encoding="utf-8").read().replace("\r\n", "\n")
        if find not in text:
            print("[건너뜀] %s: 고칠 자리를 찾지 못했습니다(settle.py 가 바뀌었는지 보세요)" % name)
            continue
        open(f, "w", encoding="utf-8", newline="\n").write(text.replace(find, rep))
        p = subprocess.run([sys.executable, os.path.join(d, "scripts", "verify.py"), "--quiet"],
                           capture_output=True, text=True, encoding="utf-8", env={**os.environ, "PYTHONIOENCODING": "utf-8"})
        rep_path = os.path.join(d, "output", "verify_report.json")
        failed = []
        if os.path.exists(rep_path):
            failed = [t["test"] for t in json.load(open(rep_path, encoding="utf-8"))["tests"] if t["result"] != "PASS"]
        last = (p.stdout.strip().splitlines() or ["(출력 없음)"])[-1]
        print("=== %s" % name)
        print("    %s" % last)
        for t in failed:
            print("    실패: %s" % t)


if __name__ == "__main__":
    main()
