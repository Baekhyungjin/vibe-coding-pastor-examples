"""익명화와 AI 호출 차단 시험. 가짜 명부와 가짜 심방 메모만 쓴다(실존 인물과 무관)."""
import os
import re
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import ai_call  # noqa: E402
import anonymize  # noqa: E402
from verify_core import record_metric  # noqa: E402

ROSTER = anonymize.load_roster(os.path.join(ROOT, "data", "members_sample.csv"))
NAMES = [n for n, _ in ROSTER]
UNLISTED = ["고미르", "전다솜", "문하랑", "배소율", "허채온", "남가람", "심하늘", "노유건"]   # 명부에 없는 가짜 이름
INSTS = ["새솔병원", "달뜨리의원", "푸른들초등학교", "가온대학교", "한마루주식회사", "별빛약국"]
STREETS = ["서울특별시 가나구 달빛로 12", "경기도 다라시 마바구 해솔길 5-3", "부산광역시 사아구 별무리로 77, 301호"]
PHONES = ["010-1234-5678", "01098765432", "010 2345 6789", "031-123-4567", "02-345-6789", "010.4321.8765"]
EMAILS = ["sample.member@example.com", "gaon_kim@example.org", "a.b-c@test.example.net"]


def memos():
    """가짜 심방 메모 40개와 정답(남으면 안 되는 값 목록)"""
    out = []
    n = len(NAMES)
    for i in range(40):
        a, b = NAMES[i % n], NAMES[(i * 5 + 3) % n]
        u = UNLISTED[i % len(UNLISTED)]
        parts = [
            "%s 집사님 가정을 심방했다." % a,
            "%s 남편 수술 후 %s 입원 중이라 면회했다." % (a, INSTS[i % len(INSTS)]),
            "%s 권사님의 둘째 아들이 %s에 다닌다고 한다." % (b, INSTS[(i + 2) % len(INSTS)]),
            "연락처 %s, 메일 %s." % (PHONES[i % len(PHONES)], EMAILS[i % len(EMAILS)]),
            "주소는 %s." % STREETS[i % len(STREETS)],
            "%s 집사님도 같은 어려움이 있다고 했다." % u,
            "기도제목: 가정 예배 회복, 이혼 위기 극복, 요 3:16 말씀 묵상.",
        ]
        text = " ".join(parts)
        secrets = {
            "roster": [a, b],
            "unlisted": [u],
            "phone": [PHONES[i % len(PHONES)]],
            "email": [EMAILS[i % len(EMAILS)]],
            "address": [STREETS[i % len(STREETS)].split(",")[0]],
            "inst": [INSTS[i % len(INSTS)], INSTS[(i + 2) % len(INSTS)]],
            "sens": ["수술", "입원", "이혼"],
        }
        out.append((text, secrets))
    return out


BENIGN = [
    "바울은 로마서에서 은혜를 말했다.", "다윗이 시편 23편을 노래했다.", "새신자 청년부 모임이 있습니다.",
    "신입 청년 환영회를 준비합니다.", "우리 형제자매가 함께 기도했습니다.", "주일 예배는 오전 11:00에 드립니다.",
    "베드로와 요한이 성전에 올라갔다.", "모든 성도가 함께 찬양했다.", "대학 청년 수련회 안내", "교회 청년 모두 참석합니다.",
    "하나님은 사랑이십니다.", "요 3:16 말씀을 함께 읽었다.", "다니엘과 세 친구 이야기를 나누었다.", "마리아와 마르다의 이야기",
    "여러분 모두를 환영합니다.", "한국 교회의 미래를 생각했다.", "젊은 형제들이 봉사에 참여했다.", "이번 주 구역 모임은 쉽니다.",
    "에스더와 룻의 믿음을 배웠다.", "주님께 감사하는 하루가 되기를 기도했다.",
]


class TestAnonymize(unittest.TestCase):
    def run_all(self, mode):
        an_list = []
        for text, sec in memos():
            an = anonymize.Anonymizer(ROSTER, mode=mode)
            out = an.anonymize(text)
            an_list.append((text, sec, an, out))
        return an_list

    def test_명부이름_누락_0건(self):
        miss = tot = 0
        for text, sec, an, out in self.run_all("pastor"):
            for n in sec["roster"]:
                tot += 1
                miss += n in out
        record_metric(ROOT, "명부 이름 누락/전체", "%d/%d" % (miss, tot))
        self.assertEqual(miss, 0)

    def test_연락처_이메일_주소_누락_0건(self):
        miss = tot = 0
        for text, sec, an, out in self.run_all("pastor"):
            for k in ("phone", "email", "address"):
                for v in sec[k]:
                    tot += 1
                    miss += v in out
        record_metric(ROOT, "연락처/이메일/주소 누락/전체", "%d/%d" % (miss, tot))
        self.assertEqual(miss, 0)

    def test_기관과_민감단어_누락_0건(self):
        miss = tot = 0
        for text, sec, an, out in self.run_all("share"):
            for k in ("inst", "sens"):
                for v in sec[k]:
                    tot += 1
                    miss += v in out
        record_metric(ROOT, "기관/민감단어 누락/전체(공유용)", "%d/%d" % (miss, tot))
        self.assertEqual(miss, 0)

    def test_명부에_없는_이름_탐지율(self):
        hit = tot = 0
        for text, sec, an, out in self.run_all("pastor"):
            for u in sec["unlisted"]:
                tot += 1
                hit += u not in out
        rate = hit / tot
        record_metric(ROOT, "명부 외 이름 탐지율('OOO 집사님' 꼴)", round(rate, 3))
        self.assertGreaterEqual(rate, 0.95)

    def test_성이_없는_이름은_놓칠수_있다_한계_명시(self):
        out = anonymize.Anonymizer(ROSTER).anonymize("철수 형제가 찾아왔다.")
        self.assertIn("철수", out)       # 정직한 한계: 명부에 없고 성이 없는 이름은 못 잡는다

    def test_오탐률_5퍼센트_이하(self):
        changed = 0
        for s in BENIGN:
            out = anonymize.Anonymizer(ROSTER, mode="share").anonymize(s)
            changed += out != s
        rate = changed / len(BENIGN)
        record_metric(ROOT, "성경 인물/일반 문장 오탐률", "%d/%d" % (changed, len(BENIGN)))
        self.assertLessEqual(rate, 0.05)

    def test_같은_사람은_같은_가명(self):
        an = anonymize.Anonymizer(ROSTER)
        out = an.anonymize("곽도율 집사님을 만났다. 곽도율 집사님은 석하람 권사님과 함께 왔다.")
        self.assertEqual(out.count("성도 A"), 2)
        self.assertIn("성도 B", out)

    def test_가명은_26명_넘어도_이어진다(self):
        self.assertEqual(anonymize.label(0), "A")
        self.assertEqual(anonymize.label(25), "Z")
        self.assertEqual(anonymize.label(26), "AA")

    def test_가족관계_표현(self):
        out = anonymize.Anonymizer(ROSTER).anonymize("곽도율 집사님의 둘째 아들이 입대했다.")
        self.assertIn("성도 A의 가족", out)
        self.assertNotIn("둘째 아들", out)

    def test_목회자용은_대응표로_복원된다(self):
        an = anonymize.Anonymizer(ROSTER, mode="pastor")
        src = "곽도율 집사님 연락처 010-1234-5678, 새솔병원 입원."
        out = an.anonymize(src)
        self.assertNotIn("곽도율", out)
        self.assertNotIn("010-1234-5678", out)
        self.assertEqual(an.restore(out).count("010-1234-5678"), 1)
        self.assertIn("곽도율", an.restore(out))
        self.assertTrue(an.mapping_rows)

    def test_공유용은_복원할수_없고_대응표가_없다(self):
        an = anonymize.Anonymizer(ROSTER, mode="share")
        out = an.anonymize("곽도율 집사님 연락처 010-1234-5678.")
        self.assertIn("[연락처]", out)
        self.assertEqual(an.mapping_rows[:0], [])
        self.assertFalse([r for r in an.mapping_rows if r["종류"] != "이름"])
        with self.assertRaises(ValueError):
            an.restore(out)

    def test_주민번호_형식(self):
        out = anonymize.Anonymizer(ROSTER).anonymize("주민번호 900101-1234567 확인")
        self.assertNotIn("1234567", out)

    def test_익명화_뒤_잔여검사는_비어있다(self):
        bad = 0
        for text, sec, an, out in self.run_all("pastor") + self.run_all("share"):
            bad += bool(anonymize.residual_scan(out, ROSTER))
        record_metric(ROOT, "익명화 뒤 잔여검사 걸린 메모", "%d/80" % bad)
        self.assertEqual(bad, 0)

    def test_잔여검사는_원문에서_걸린다(self):
        for text, sec, an, out in self.run_all("pastor")[:10]:
            self.assertTrue(anonymize.residual_scan(text, ROSTER))

    def test_성경_인물은_이름으로_보지_않는다(self):
        out = anonymize.Anonymizer(ROSTER).anonymize("바울 사도와 다윗 왕의 이야기를 나눴다.")
        self.assertIn("바울", out)
        self.assertIn("다윗", out)

    def test_대응표는_파일로_저장된다(self):
        an = anonymize.Anonymizer(ROSTER)
        an.anonymize("곽도율 집사님 010-1234-5678")
        path = os.path.join(ROOT, "output", "mapping_test.csv")
        an.mapping_csv(path)
        self.assertTrue(os.path.getsize(path) > 0)
        os.remove(path)


class TestAICall(unittest.TestCase):
    def test_개인정보가_남은_글은_호출이_막힌다(self):
        ai = ai_call.MockAI('{"summary": "x"}')
        with self.assertRaises(ai_call.MaskingNotPassed):
            ai_call.call_ai("곽도율 집사님 010-1234-5678 심방 요약", ai, roster=ROSTER)
        self.assertEqual(ai.received, [])                  # AI 에는 한 글자도 가지 않았다

    def test_익명화한_글은_호출된다(self):
        out = anonymize.Anonymizer(ROSTER).anonymize("곽도율 집사님 가정 심방, 연락처 010-1234-5678")
        ai = ai_call.MockAI('결과: {"summary": "가정 심방"}')
        data = ai_call.call_ai(out, ai, schema={"required": {"summary": str}}, roster=ROSTER)
        self.assertEqual(data["summary"], "가정 심방")
        self.assertEqual(len(ai.received), 1)
        self.assertNotIn("곽도율", ai.received[0])

    def test_JSON이_아닌_응답은_거부(self):
        ai = ai_call.MockAI("그냥 말로만 답합니다")
        with self.assertRaises(ai_call.BadAIResponse):
            ai_call.call_ai("성도 A 가정 심방", ai, retries=1)
        self.assertEqual(len(ai.received), 2)

    def test_허용_목록_밖_값은_거부(self):
        ai = ai_call.MockAI('{"kind": "엉뚱"}')
        with self.assertRaises(ai_call.BadAIResponse):
            ai_call.call_ai("성도 A", ai, schema={"enum": {"kind": ["위로", "권면"]}}, retries=0)

    def test_bare_옵션은_쓰지_않는다(self):
        cmd = ai_call.build_command("claude", "안녕")
        self.assertEqual(cmd[:2], ["claude", "-p"])
        self.assertNotIn("--bare", cmd)
        self.assertEqual(ai_call.build_command("codex", "안녕")[:2], ["codex", "exec"])
        with self.assertRaises(ValueError):
            ai_call.build_command("other", "x")

    def test_소스에_bare_실행코드가_없다(self):
        with open(os.path.join(ROOT, "ai_call.py"), encoding="utf-8") as f:
            code = f.read()
        self.assertEqual(len(re.findall(r'"--bare"\s*[,\]]', code.replace('"--bare" in cmd', ''))), 0)


if __name__ == "__main__":
    unittest.main()
