"""범위표, 장절 존재 검증, 번역본 저장소 시험"""
import json
import os
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import bible_store  # noqa: E402
import canon  # noqa: E402
import refparse  # noqa: E402
import validate  # noqa: E402
from verify_core import record_metric  # noqa: E402

CN = canon.load()
P = refparse.Parser(CN)


class TestCanon(unittest.TestCase):
    def test_66권(self):
        self.assertEqual(len(CN.books), 66)

    def test_구약39_신약27(self):
        self.assertEqual(sum(b.testament == "OT" for b in CN.books), 39)
        self.assertEqual(sum(b.testament == "NT" for b in CN.books), 27)

    def test_기준구조_총절수_31102(self):
        self.assertEqual(CN.total_verses(), 31102)
        record_metric(ROOT, "기준 구조 총 절 수(KJV)", CN.total_verses())

    def test_장수_표본(self):
        self.assertEqual(CN.find("시편").chapter_count, 150)
        self.assertEqual(CN.find("창").chapter_count, 50)
        self.assertEqual(CN.find("요한계시록").chapter_count, 22)
        self.assertEqual(CN.find("유").chapter_count, 1)
        self.assertEqual(CN.find("요엘").chapter_count, 3)
        self.assertEqual(CN.find("말라기").chapter_count, 4)

    def test_절수_표본(self):
        self.assertEqual(CN.verse_count(CN.find("시"), 119), 176)
        self.assertEqual(CN.verse_count(CN.find("요"), 3), 36)
        self.assertEqual(CN.verse_count(CN.find("유"), 1), 25)

    def test_개역한글_차이_3곳이_기록됨(self):
        keys = {(v["book"], v["chapter"]) for v in CN.variants}
        self.assertEqual(keys, {("아가", 6), ("고린도후서", 13), ("요한삼서", 1)})

    def test_약어는_모두_다르다(self):
        abbr = [b.abbr for b in CN.books]
        self.assertEqual(len(abbr), len(set(abbr)))

    def test_본문이_들어있지_않다(self):
        with open(os.path.join(ROOT, "data", "canon.json"), encoding="utf-8") as f:
            raw = f.read()
        self.assertNotIn("태초에", raw)
        self.assertNotIn("In the beginning", raw)


def _v(text):
    r = P.parse(text)
    return validate.validate_ref(r[0], CN)


class TestValidate(unittest.TestCase):
    def test_존재함(self):
        for s in ("요 3:16", "시 23:1-6", "창 1:1-2:3", "시 119:176", "요삼 1:14", "계 22:21"):
            self.assertEqual(_v(s).code, "OK", s)

    def test_없는_장(self):
        self.assertEqual(_v("시 151:1").code, "CHAPTER_OUT_OF_RANGE")

    def test_없는_절(self):
        self.assertEqual(_v("유 1:30").code, "VERSE_OUT_OF_RANGE")
        self.assertEqual(_v("요 3:37").code, "VERSE_OUT_OF_RANGE")

    def test_순서_거꾸로(self):
        self.assertEqual(_v("요 3:18-16").code, "RANGE_REVERSED")

    def test_영장_영절(self):
        self.assertEqual(_v("요한복음 0:1").code, "CHAPTER_ZERO")
        self.assertEqual(_v("요한복음 3:0").code, "VERSE_ZERO")

    def test_모호한_약어(self):
        self.assertEqual(_v("삼 1:1").code, "AMBIGUOUS_BOOK")

    def test_개역한글과_다를수있는_장은_경고(self):
        c = _v("요삼 1:15")
        self.assertTrue(c.ok)
        self.assertIn("VARIANT_CHAPTER", c.warnings)
        self.assertEqual(_v("요삼 1:16").code, "VERSE_OUT_OF_RANGE")

    def test_글_전체_검사(self):
        checks = validate.validate_text("본문은 요 3:16, 인용은 유 1:30, 시 151:1 입니다", P, CN)
        s = validate.summarize(checks)
        self.assertEqual(s["total"], 3)
        self.assertEqual(s["bad"], 2)
        self.assertEqual(s["codes"], ["CHAPTER_OUT_OF_RANGE", "VERSE_OUT_OF_RANGE"])


class TestBibleStore(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = bible_store.BibleStore(base_dir=ROOT)

    def test_번역본은_설정으로_정한다(self):
        self.assertEqual(self.store.active.name, "개역한글")
        with open(os.path.join(ROOT, "config", "bible.json"), encoding="utf-8") as f:
            cfg = json.load(f)
        self.assertIn("gaehan", cfg["translations"])

    def test_개역개정_본문_데이터가_없다(self):
        for t in self.store.translations.values():
            self.assertNotIn("개정", t.name)
        for fn in os.listdir(os.path.join(ROOT, "data")):
            self.assertNotIn("gaejung", fn.lower())

    def test_개역한글_샘플은_30절_이내(self):
        self.assertLessEqual(len(self.store.translations["gaehan"].verses), 30)

    def test_본문_조회(self):
        t = self.store.text_of("요 3:16")
        self.assertTrue(t.startswith("하나님이 세상을"))
        six = self.store.text_of("시 23:1-6")
        self.assertTrue(six.startswith("여호와는 나의 목자시니"))
        self.assertIn("내가 여호와의 집에 영원히 거하리로다", six)

    def test_정확히_같은_인용은_통과(self):
        q = self.store.text_of("요 3:16")
        r = self.store.check_quotes([(q, "요 3:16")])[0]
        self.assertEqual((r["status"], r["code"]), ("PASS", "OK"))
        self.assertEqual(r["translation"], "개역한글")

    def test_공백과_문장부호만_다르면_통과(self):
        q = "아무 것도 염려하지 말고 오직 모든 일에 기도와 간구로 너희 구할 것을 감사함으로 하나님께 아뢰라"
        r = self.store.check_quotes([(q, "빌 4:6")])[0]
        self.assertEqual(r["code"], "OK")

    def test_한글자_바뀐_인용은_불일치(self):
        q = self.store.text_of("요일 1:9").replace("자백하면", "자복하면")
        r = self.store.check_quotes([(q, "요일 1:9")])[0]
        self.assertEqual(r["code"], "MISMATCH")
        self.assertTrue(r["diffs"])

    def test_없는_장절은_본문_대조_전에_걸린다(self):
        r = self.store.check_quotes([("아무 글", "유 1:30")])[0]
        self.assertEqual(r["code"], "REF_NOT_EXIST:VERSE_OUT_OF_RANGE")

    def test_저장소에_없는_절은_대조불가로_표시(self):
        r = self.store.check_quotes([("글", "요 3:17")])[0]
        self.assertEqual(r["code"], "NOT_IN_STORE")

    def test_번역본_혼용_탐지(self):
        b = self.store.translations["fakeB"].get("요 3:16")
        r = self.store.check_quotes([(b, "요 3:16")])[0]
        self.assertEqual(r["code"], "MIXED_TRANSLATION")
        self.assertIn("번역본 B(가상)", r["message"])

    def test_가짜_번역본B는_시험전용이고_표시된다(self):
        t = self.store.translations["fakeB"]
        self.assertTrue(t.test_only)
        self.assertEqual(t.name, "번역본 B(가상)")

    def test_글자_위치_차이_표시(self):
        q = self.store.text_of("창 1:1").replace("천지", "하늘땅")
        c = self.store.compare(q, "창 1:1")
        self.assertFalse(c.ok)
        self.assertEqual(c.diffs[0][3], 7)       # 정규화한 본문("태초에하나님이천지를...")에서 천지가 시작하는 글자 위치

    def test_본문을_바꾸지_않는다(self):
        before = self.store.text_of("시 23:1")
        self.store.compare("다른 글", "시 23:1")
        self.assertEqual(self.store.text_of("시 23:1"), before)


if __name__ == "__main__":
    unittest.main()
