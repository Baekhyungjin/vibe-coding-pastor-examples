"""공통 모듈 하네스 진입점: python scripts/verify.py"""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.dont_write_bytecode = True

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

import verify_core  # noqa: E402

if __name__ == "__main__":
    sys.exit(verify_core.run_harness(ROOT, quiet="--quiet" in sys.argv))
