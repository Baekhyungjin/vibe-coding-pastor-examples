"""하네스 진입점: python scripts/verify.py [--quiet]
종료 코드: 0 통과, 2 실패. 마지막 줄은 RESULT: PASSED (n/n) 또는 RESULT: FAILED (k/n)."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

import verify_core  # noqa: E402

if __name__ == "__main__":
    sys.exit(verify_core.run_harness(ROOT, quiet="--quiet" in sys.argv))
