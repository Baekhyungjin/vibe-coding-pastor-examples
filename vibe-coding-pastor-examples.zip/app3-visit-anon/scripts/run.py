"""심방 메모를 익명화하고 기도제목을 정리한다.

사용:
  python scripts/run.py                      # data/ 의 실제 메모(실습은 --demo)
  python scripts/run.py --demo               # samples/golden 의 가짜 메모로 연습, 결과는 output/demo/ 에 저장
  python scripts/run.py --ai none            # AI 를 쓰지 않는다(기본값, 민감 교구는 이 경로)
  python scripts/run.py --ai claude|codex    # 익명화를 통과한 글만 구독 CLI 로 보낸다(모드 B)
  python scripts/run.py --due                # 보관 기한이 지난 기록을 알려 준다(지우지 않는다)
"""
import argparse
import datetime
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import ai_call  # noqa: E402
import pastoral  # noqa: E402


def load_sensitive(path):
    """data/sensitive.txt: 한 줄에 `단어` 또는 `단어=분류`(건강 사정, 가정 사정, 경제 사정, 기타 사정)"""
    out = {}
    for line in pastoral.load_lines(path):
        w, _, k = line.partition("=")
        out[w.strip()] = k.strip() or "기타 사정"
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", action="store_true")
    ap.add_argument("--ai", choices=["none", "claude", "codex"], default="none")
    ap.add_argument("--due", action="store_true")
    ap.add_argument("--days", type=int, default=365)
    a = ap.parse_args()
    if a.demo:
        src = os.path.join(ROOT, "samples", "golden")
        visits, roster, inst = os.path.join(src, "visits"), os.path.join(src, "members.csv"), os.path.join(src, "institutions.txt")
        data = os.path.join(ROOT, "output", "demo")
    else:
        data = os.path.join(ROOT, "data")
        visits, roster, inst = os.path.join(data, "visits"), os.path.join(data, "members.csv"), os.path.join(data, "institutions.txt")
    if a.due:
        con = pastoral.init_db(os.path.join(data, "pastoral.db"))
        print(pastoral.due_message(pastoral.retention_due(con, days=a.days)))
        return 0
    if not os.path.isdir(visits) or not os.path.exists(roster):
        print("data/visits 폴더와 data/members.csv 가 필요합니다. 연습은 --demo 로 하세요.")
        return 1
    backend = None if a.ai == "none" else ai_call.cli_backend(a.ai)
    try:
        r = pastoral.run(visits, roster, data, pastoral.load_lines(inst), sensitive=load_sensitive(os.path.join(data, "sensitive.txt")) if not a.demo else None, backend=backend)
    except pastoral.ResidualFound as e:
        print("멈춤:", e)
        return 2
    for w in r["warnings"]:
        print("경고:", w)
    print("저장한 메모: %d건  (DB %s)" % (len(r["saved"]), os.path.relpath(r["db"], ROOT)))
    print("대응표: %s  (실명이 들어 있습니다. 메일, 클라우드, Git 으로 보내지 마세요)" % os.path.relpath(r["mapping"], ROOT))
    out = os.path.join(ROOT, "output")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "share_prayers.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(dict.fromkeys(r["share_lines"])) + "\n")
    print("공유용 기도제목: output/share_prayers.txt (%d줄). 보내기 전에 목회자가 한 번 읽어 확인하세요." % len(set(r["share_lines"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
