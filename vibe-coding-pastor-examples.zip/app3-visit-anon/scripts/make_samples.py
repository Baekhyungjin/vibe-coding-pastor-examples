"""가짜 심방 메모와 가짜 교인 명부를 만든다 (표준 라이브러리만, 같은 입력이면 늘 같은 결과).

모든 이름, 번호, 주소, 기관, 사연은 시험을 위해 지어낸 것이다. 우연히 실존 인물이나 단체와 같을 수 있으나 관계가 없다.
성경 인물 이름은 가짜 성도 이름으로 쓰지 않는다.
사용: python scripts/make_samples.py
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(ROOT, "samples", "golden")
T = os.path.join(ROOT, "samples", "trap")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROSTER = [
    ("곽도율", "집사"), ("석하람", "권사"), ("진이솔", "장로"), ("편누리", "집사"), ("마루빈", "성도"),
    ("방가온", "권사"), ("함세린", "집사"), ("탁서담", "성도"), ("옥해랑", "청년"), ("맹소율", "자매"),
    ("엄다솜", "권사"), ("위예람", "집사"), ("염보라", "자매"), ("모아린", "청년"), ("제담휘", "형제"),
    ("육시울", "장로"), ("선채온", "성도"), ("설나래", "집사"), ("표유한", "형제"), ("명지온", "집사"),
    ("반세아", "자매"), ("길라온", "청년"), ("기윤슬", "권사"), ("어지안", "성도"), ("은빛나", "집사"),
    ("용가람", "장로"), ("노다인", "자매"), ("심해든", "청년"), ("공시현", "집사"), ("변소담", "권사"),
    ("도서아", "자매"), ("인서하", "성도"), ("추은결", "형제"), ("배하린", "집사"), ("허도현", "청년"),
    ("소담이", "성도"),
]
HONOR = {"집사": "님", "권사": "님", "장로": "님", "성도": "님", "청년": "", "자매": "", "형제": ""}
PARTS = ["새빛병원", "다솜초등학교", "한울은행", "미래한의원", "푸른어린이집", "나래요양원", "해든대학교", "바른약국", "새봄치과", "믿음고등학교"]
CUSTOM_INST = ["가온전자", "해솔식품", "누리건설", "별빛물류", "다온상사"]
TERMS = ["수술", "입원", "항암", "투석", "치매", "우울증", "이혼", "실직", "빚"]
SIDO = ["서울특별시", "경기도", "인천광역시", "부산광역시", "대전광역시"]
GU = ["가온구", "다온시", "해솔군", "한빛구", "새암시"]
ROAD = ["샘터로", "별빛로", "푸른길", "고운로", "늘봄길"]
APTS = ["푸른마을아파트", "해든빌라", "새봄맨션"]
BIBLE = ["다윗", "바울", "베드로", "마리아"]
EMAILS = ["dowool.k", "haram.s", "isol.j", "nuri.p", "gaon.b", "serin.h", "seodam.t", "haerang.o"]
TOPICS = ["직장 일", "자녀 진학 문제", "이사 준비", "부모님 돌봄", "새로 시작하는 일"]
WHEN = ["오전", "오후", "저녁"]
KIND = ["가정 심방", "병원 심방", "직장 심방", "전화 상담 기록"]

_seed = [20261027]


def rnd(n):
    _seed[0] = (_seed[0] * 1103515245 + 12345) & 0x7FFFFFFF
    return (_seed[0] >> 8) % n


def phone(i):
    a, b = "%04d" % (1000 + rnd(8999)), "%04d" % (1000 + rnd(8999))
    v = i % 6
    return ["010-%s-%s", "010 %s %s", "010%s%s", "010.%s.%s", "+82 10-%s-%s", "031-%s-%s"][v] % ((a, b) if v != 5 else (a[:3], b))


def mention(name, title, style):
    h = HONOR[title]
    return [name + " " + title + h, name + " " + title, name + title + h, name + " 가정"][style]


def build_memo(i, labels):
    p1 = ROSTER[i % len(ROSTER)]
    p2 = ROSTER[(i * 7 + 3) % len(ROSTER)]
    if p2 == p1:
        p2 = ROSTER[(i + 1) % len(ROSTER)]
    L = {"names": [], "phones": [], "emails": [], "addresses": [], "institutions": [], "sensitive": [], "family": 0, "bible": []}

    def m(p, style=None):
        st = rnd(4) if style is None else style
        L["names"].append(p[0])
        return mention(p[0], p[1], st)

    day = 1 + (i * 3) % 28
    month = 1 + (i % 9)
    date = "2026-%02d-%02d" % (month, day)
    lines = ["%s %s %s." % (date, WHEN[i % 3], KIND[i % 4])]
    lines.append("대상은 %s이다. 동행은 %s." % (m(p1, i % 3), m(p2, (i + 1) % 3)))
    # 주소
    if i % 2 == 0:
        a = "%s %s %s %d길 %d" % (SIDO[i % 5], GU[i % 5], ROAD[i % 5], 3 + i % 17, 1 + i % 9)
    else:
        a = "%s %s %s %d, %d동 %d호" % (SIDO[(i + 2) % 5], GU[(i + 1) % 5], ROAD[(i + 3) % 5], 10 + i, 100 + i % 8, 300 + i)
    L["addresses"].append(a)
    lines.append("장소는 %s였다." % a)
    if i % 5 == 1:
        apt = "%s %d동 %d호" % (APTS[i % 3], 101 + i % 5, 1100 + i)
        L["addresses"].append(apt)
        lines.append("이사 예정지는 %s라고 했다." % apt)
    # 연락처
    if i % 3 != 2:
        ph = phone(i)
        L["phones"].append(ph)
        if i % 4 == 0:
            em = "%s%d@example.com" % (EMAILS[i % len(EMAILS)], i)
            L["emails"].append(em)
            lines.append("연락처는 %s, 이메일은 %s 이다." % (ph, em))
        else:
            lines.append("연락처는 %s 이다." % ph)
    if i % 6 == 4:
        ph2 = phone(i + 1)
        L["phones"].append(ph2)
        lines.append("가족 연락처는 %s 이다." % ph2)
    # 생활
    lines.append("%s은 요즘 %s로 마음이 무겁다고 했다." % (m(p1, 0), TOPICS[i % 5]))
    term = TERMS[i % len(TERMS)]
    L["sensitive"].append(term)
    if i % 3 == 0:
        inst = PARTS[i % len(PARTS)]
        L["institutions"].append(inst)
        lines.append("가족이 %s 때문에 %s에 다니고 있다고 했다." % (term, inst))
    elif i % 3 == 1:
        inst = CUSTOM_INST[i % len(CUSTOM_INST)]
        L["institutions"].append(inst)
        lines.append("직장은 %s이고, 요즘 %s 걱정이 크다고 했다." % (inst, term))
    else:
        lines.append("집안에 %s 문제가 있어 오래 이야기했다." % term)
    # 가족 관계
    fam_forms = ["%s 둘째 아들", "%s네 막내딸", "%s의 남편", "%s 어머니", "%s 첫째 딸"]
    if i % 2 == 0:
        who = p2 if i % 4 == 0 else p1
        mm = mention(who[0], who[1], 0 if i % 4 else 1)
        L["names"].append(who[0])
        L["family"] += 1
        lines.append("%s 이야기를 나누며 오래 대화했다." % (fam_forms[i % 5] % mm))
    # 성경 인물
    if i % 4 == 1:
        b = BIBLE[i % 4]
        L["bible"].append(b)
        lines.append("시 23편을 함께 읽고 %s의 고백을 나누었다." % b)
    # 기도
    lines.append("%s의 %s 문제를 위해 기도했다." % (m(p1, 1), term))
    lines.append("자녀의 진로와 직장의 안정을 위해서도 함께 기도했다.")
    if i % 3 == 0:
        lines.append("기도제목은 건강 회복과 가정의 평안이다.")
    if i % 5 == 2:
        lines.append("%s의 새 출발을 위해 기도했다." % m(p2, 2))
    return date, "\n".join(lines) + "\n", L


FP = [
    "바울은 빌립보 교회에 편지를 썼다.", "다윗의 시편을 함께 읽었다.", "새로 오신 청년들이 예배에 참석했다.",
    "성도들이 함께 식사를 했다.", "장로회 모임이 있었다.", "청년부 수련회 준비를 했다.", "마리아와 마르다의 이야기를 나누었다.",
    "베드로 사도의 고백을 묵상했다.", "예수님의 사랑을 전하자는 말씀을 나누었다.", "한 가정이 새로 등록했다.",
    "김장 나눔 모임을 준비한다.", "임원 회의에서 전도 계획을 정했다.", "목사님 말씀 후에 기도회를 가졌다.",
    "주일학교 교사 모임이 있었다.", "남자 청년과 여자 청년이 함께 섬겼다.", "이번 주 새벽기도회에 많은 성도님이 참석했다.",
    "소그룹 형제 모임은 토요일에 있다.", "청소년 자매 수련회가 열렸다.", "한국 교회를 위해 기도했다.", "주님의 은혜를 구했다.",
    "다니엘의 세 친구 이야기를 읽었다.", "에스더서를 함께 읽었다.", "안수집사 모임은 첫째 주에 있다.", "서리집사 임명 예배를 준비한다.",
]

LIMITS = [
    {"text": "도율이가 오늘 처음 예배에 왔다.", "leak": "도율", "why": "성 없이 이름만 부름(명부는 성과 이름이 함께 있어야 찾음)"},
    {"text": "철수 형제가 새로 왔다.", "leak": "철수", "why": "명부에 없고 성이 없는 이름"},
    {"text": "하람 엄마가 전화했다.", "leak": "하람", "why": "애칭 호칭"},
    {"text": "샘터로 12길 5에 산다고 했다.", "leak": "샘터로 12길 5", "why": "시도 이름 없는 주소"},
    {"text": "공일공 일이삼사 오육칠팔로 연락하면 된다.", "leak": "공일공", "why": "한글로 쓴 전화번호"},
]

TRAPS = {
    "trap_01_이름남은공유용.txt": ("곽도율 집사님의 건강 회복을 위해 기도해 주세요.\n", ["명부이름"]),
    "trap_02_가명단서.txt": ("성도 A의 건강 문제를 위해 기도해 주세요.\n", ["가명단서"]),
    "trap_03_대응표섞임.txt": ("성도 A = 곽도율\n성도 B = 석하람\n", ["가명단서", "대응표흔적", "명부이름"]),
    "trap_04_연락처남음.txt": ("문의는 010-2468-1357 로 해 주세요. 기도 부탁드립니다.\n", ["연락처"]),
    "trap_05_기관과민감단어.txt": ("새빛병원에서 항암 치료 중인 가정을 위해 기도해 주세요.\n", ["기관", "민감단어"]),
    "trap_06_AI프롬프트에이름.txt": ("다음 메모를 요약하세요. 마루빈 성도님 가정 심방, 기도제목 정리.\n", ["명부이름"]),
    "trap_07_가족단서.txt": ("성도 B의 가족을 위해 기도합니다.\n", ["가명단서", "가족단서"]),
}
GOLDEN_SHARE = [
    "한 성도의 건강 문제를 위해 기도해 주세요.", "한 가정의 평안을 위해 기도해 주세요.", "자녀의 진로와 직장의 안정을 위해 함께 기도해 주세요.",
    "새로 시작하는 일을 위해 기도해 주세요.", "경제 문제로 어려움을 겪는 가정을 위해 기도해 주세요.",
]


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def main():
    labels = {}
    for i in range(32):
        date, text, L = build_memo(i, labels)
        mid = "V%02d" % (i + 1)
        write(os.path.join(G, "visits", mid + ".txt"), text)
        labels[mid] = L
    write(os.path.join(G, "members.csv"), "이름,직분\n" + "".join("%s,%s\n" % r for r in ROSTER))
    write(os.path.join(G, "institutions.txt"), "# 명부 밖 직장, 단체 이름 (패턴으로 찾기 어려운 것)\n" + "\n".join(CUSTOM_INST) + "\n")
    write(os.path.join(G, "labels.json"), json.dumps(labels, ensure_ascii=False, indent=1))
    write(os.path.join(G, "fp_sentences.txt"), "\n".join(FP) + "\n")
    write(os.path.join(G, "share_ok.txt"), "\n".join(GOLDEN_SHARE) + "\n")
    write(os.path.join(ROOT, "samples", "limits.json"), json.dumps(LIMITS, ensure_ascii=False, indent=1))
    for fn, (txt, _) in TRAPS.items():
        write(os.path.join(T, fn), txt)
    write(os.path.join(T, "expected.json"), json.dumps({fn: r for fn, (_, r) in TRAPS.items()}, ensure_ascii=False, indent=1))
    n_names = sum(len(v["names"]) for v in labels.values())
    print("메모 %d개, 이름 %d건, 연락처 %d건, 이메일 %d건, 주소 %d건, 기관 %d건, 민감단어 %d건, 가족 표현 %d건, 오탐 시험문 %d개" % (
        len(labels), n_names, sum(len(v["phones"]) for v in labels.values()), sum(len(v["emails"]) for v in labels.values()),
        sum(len(v["addresses"]) for v in labels.values()), sum(len(v["institutions"]) for v in labels.values()),
        sum(len(v["sensitive"]) for v in labels.values()), sum(v["family"] for v in labels.values()), len(FP)))


if __name__ == "__main__":
    main()
