이 폴더는 실제 교인 정보를 두는 곳입니다. Git, 메일, 클라우드 동기화 폴더로 내보내지 마세요.
  data/members.csv   교인 명부(이름,직분)
  data/visits/*.txt  심방 메모
  data/institutions.txt  직장 단체 이름
  data/pastoral.db   저장소(자동 생성)
  data/mapping.csv   대응표(실명 포함, 자동 생성)
실습은 samples/golden 의 가짜 데이터로만 하세요.
