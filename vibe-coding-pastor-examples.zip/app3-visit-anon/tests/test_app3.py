"""앱 3 하네스 (T1~T7 + 보조). 표준 라이브러리 unittest.
가짜 메모는 samples/golden, 함정은 samples/trap. 임시 파일은 output/ 아래에만 만든다(시스템 TEMP는 막혀 있을 수 있다)."""
import json
import os
import re
import shutil
import subprocess
import sys
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.dont_write_bytecode = True

import ai_call  # noqa: E402
import anonymize  # noqa: E402
import pastoral  # noqa: E402
import verify_core  # noqa: E402

G = os.path.join(ROOT, "samples", "golden")
T = os.path.join(ROOT, "samples", "trap")
ROSTER = pastoral.load_roster(os.path.join(G, "members.csv"))
INST = pastoral.load_lines(os.path.join(G, "institutions.txt"))
MEMOS = pastoral.load_memos(os.path.join(G, "visits"))
LABELS = json.load(open(os.path.join(G, "labels.json"), encoding="utf-8"))
OUT = os.path.join(ROOT, "output")
os.makedirs(OUT, exist_ok=True)


def digits(s):
    return re.sub(r"\D", "", s)


class T1_이름(unittest.TestCase):
    def test_T1_명부이름_누락0(self):
        total = missed = 0
        for mid, text in MEMOS.items():
            p, _ = pastoral.pastor_view(text, ROSTER, INST)
            for name in LABELS[mid]["names"]:
                total += 1
                if name in p:
                    missed += 1
            self.assertEqual(pastoral.check_pastor_text(p, ROSTER, INST), [], mid + " 잔여 검사")
        verify_core.record_metric(ROOT, "T1 명부 이름 건수", total)
        verify_core.record_metric(ROOT, "T1 명부 이름 누락", missed)
        self.assertGreaterEqual(total, 120, "시험 이름이 120건 미만")
        self.assertEqual(missed, 0, "누락 %d/%d" % (missed, total))


class T2_연락처(unittest.TestCase):
    def test_T2_연락처_주소_변형_누락0(self):
        total = missed = 0
        for mid, text in MEMOS.items():
            p, _ = pastoral.pastor_view(text, ROSTER, INST)
            s = "\n".join(pastoral.share_prayers(text, ROSTER, INST))
            lab = LABELS[mid]
            for kind in ("phones", "emails", "addresses"):
                for v in lab[kind]:
                    total += 1
                    if v in p or v in s or (kind == "phones" and digits(v) in digits(p)):
                        missed += 1
            self.assertIsNone(anonymize.PHONE.search(p), mid)
        verify_core.record_metric(ROOT, "T2 연락처/이메일/주소 건수", total)
        verify_core.record_metric(ROOT, "T2 연락처/이메일/주소 누락", missed)
        self.assertEqual(missed, 0)


class T3_AI차단(unittest.TestCase):
    def test_T3_익명화_미통과_텍스트는_AI호출이_막힌다(self):
        for fn in sorted(os.listdir(T)):
            if fn.startswith("trap_06"):
                mock = ai_call.MockAI('{"summary": "x", "prayers": []}')
                with self.assertRaises(ai_call.MaskingNotPassed):
                    ai_call.call_ai(open(os.path.join(T, fn), encoding="utf-8").read(), mock, roster=ROSTER)
                self.assertEqual(mock.received, [], "막았는데 AI가 받았다")

    def test_T3_통과한_글만_AI가_받는다(self):
        mock = ai_call.MockAI('{"summary": "세 문장 요약", "prayers": ["일반화한 기도제목"]}')
        for mid, text in MEMOS.items():
            p, _ = pastoral.pastor_view(text, ROSTER, INST)
            pastoral.ai_summarize(p, mock, ROSTER, INST)
        self.assertEqual(len(mock.received), len(MEMOS))
        for sent in mock.received:
            for name, _ in ROSTER:
                self.assertNotIn(name, sent)

    def test_T3_AI응답이_약속한_형식이_아니면_거부(self):
        mock = ai_call.MockAI("그냥 글로만 답합니다")
        p, _ = pastoral.pastor_view(MEMOS["V01"], ROSTER, INST)
        with self.assertRaises(ai_call.BadAIResponse):
            pastoral.ai_summarize(p, mock, ROSTER, INST)


class T4_같은사람(unittest.TestCase):
    def test_T4_같은_사람은_메모_안에서_같은_가명(self):
        for mid, text in MEMOS.items():
            p, an = pastoral.pastor_view(text, ROSTER, INST)
            self.assertEqual(len(set(an.alias.values())), len(an.alias), mid + " 서로 다른 사람이 같은 가명")
            for name, alias in an.alias.items():
                n_orig = LABELS[mid]["names"].count(name)
                n_now = len(re.findall(re.escape(alias) + r"(?![A-Z])", p))
                self.assertGreaterEqual(n_now, n_orig, "%s %s: 원문 %d번, 가명 %d번" % (mid, name, n_orig, n_now))

    def test_T4_목회자용은_대응표로_복원된다(self):
        p, an = pastoral.pastor_view(MEMOS["V03"], ROSTER, INST)
        back = an.restore(p)
        for name in LABELS["V03"]["names"]:
            self.assertIn(name, back)

    def test_T4_공유용은_복원할_수_없다(self):
        an = anonymize.Anonymizer(ROSTER, institutions=INST, mode="share")
        an.anonymize(MEMOS["V03"])
        with self.assertRaises(ValueError):
            an.restore("성도 A")


class T5_공유용(unittest.TestCase):
    def test_T5_공유용에는_식별_단서가_없다(self):
        empty = 0
        for mid, text in MEMOS.items():
            lines = pastoral.share_prayers(text, ROSTER, INST)
            s = "\n".join(lines)
            self.assertEqual(pastoral.check_share_text(s, ROSTER, INST), [], "%s: %s" % (mid, s))
            for kind in ("names", "institutions", "phones", "emails", "addresses", "sensitive"):
                for v in LABELS[mid][kind]:
                    self.assertNotIn(v, s, "%s 에 %s 남음" % (mid, v))
            if not lines:
                empty += 1
        verify_core.record_metric(ROOT, "T5 공유용 기도제목이 비어 버린 메모", "%d/%d" % (empty, len(MEMOS)))
        self.assertLessEqual(empty, len(MEMOS) * 0.1, "다 지워서 통과한 것은 소용이 없다")

    def test_T5_정상_공유_문장은_통과한다(self):
        for line in open(os.path.join(G, "share_ok.txt"), encoding="utf-8").read().splitlines():
            self.assertEqual(pastoral.check_share_text(line, ROSTER, INST), [], line)


class T6_오탐(unittest.TestCase):
    def test_T6_성경인물과_일반말은_가리지_않는다(self):
        sents = [s for s in open(os.path.join(G, "fp_sentences.txt"), encoding="utf-8").read().splitlines() if s]
        changed = []
        for s in sents:
            p, _ = pastoral.pastor_view(s, ROSTER, INST)
            if p != s:
                changed.append((s, p))
        rate = len(changed) / len(sents)
        verify_core.record_metric(ROOT, "T6 오탐률", "%.3f (%d/%d)" % (rate, len(changed), len(sents)))
        self.assertGreaterEqual(len(sents), 20)
        self.assertLessEqual(rate, 0.05, "오탐 %s" % changed)

    def test_T6_성경인물은_메모에서도_그대로(self):
        for mid, text in MEMOS.items():
            p, _ = pastoral.pastor_view(text, ROSTER, INST)
            for b in LABELS[mid]["bible"]:
                self.assertIn(b, p)


class T7_저장위치(unittest.TestCase):
    def setUp(self):
        self.gi = open(os.path.join(ROOT, ".gitignore"), encoding="utf-8").read()

    def test_T7_대응표와_DB는_gitignore에_있다(self):
        for rel in ("data/mapping.csv", "data/pastoral.db", "data/visits/V01.txt", "data/members.csv"):
            self.assertTrue(pastoral.gitignored(rel, self.gi), rel + " 이 .gitignore 에 없다")
        self.assertFalse(pastoral.gitignored("src/pastoral.py", self.gi), "코드까지 무시하면 안 된다")

    def test_T7_Git_추적_0(self):
        git = shutil.which("git")
        if git and os.path.isdir(os.path.join(ROOT, ".git")):
            out = subprocess.run([git, "ls-files", "data"], cwd=ROOT, capture_output=True, text=True, encoding="utf-8").stdout.split()
            bad = [f for f in out if os.path.basename(f) not in ("README.txt", ".gitkeep")]
            self.assertEqual(bad, [])
            verify_core.record_metric(ROOT, "T7 Git 추적 검사", "git ls-files data: %d건" % len(bad))
        else:
            verify_core.record_metric(ROOT, "T7 Git 추적 검사", "Git 저장소가 아니라 .gitignore 판정만 함")

    def test_S_클라우드_동기화_폴더는_경고(self):
        self.assertTrue(pastoral.cloud_warnings(r"C:\Users\user\OneDrive\문서\data\mapping.csv"))
        self.assertTrue(pastoral.cloud_warnings("/Users/u/Dropbox/church/pastoral.db"))
        self.assertTrue(pastoral.cloud_warnings(r"D:\Google Drive\data\pastoral.db"))
        self.assertEqual(pastoral.cloud_warnings(os.path.join(ROOT, "data", "pastoral.db")), [])


class 보조(unittest.TestCase):
    def test_H2_함정은_정해진_이유로_걸린다(self):
        expected = json.load(open(os.path.join(T, "expected.json"), encoding="utf-8"))
        for fn, reasons in expected.items():
            text = open(os.path.join(T, fn), encoding="utf-8").read()
            self.assertEqual(sorted(pastoral.check_share_text(text, ROSTER, INST)), sorted(reasons), fn)

    def test_S_잔여검사에_걸리면_저장을_멈춘다(self):
        db = os.path.join(OUT, "_test_stop.db")
        if os.path.exists(db):
            os.remove(db)
        con = pastoral.init_db(db)
        with self.assertRaises(pastoral.ResidualFound):
            pastoral.save_record(con, "X1", "2026-01-01", "곽도율 집사님 가정 심방", "", ROSTER, INST)
        with self.assertRaises(pastoral.ResidualFound):
            pastoral.save_record(con, "X2", "2026-01-01", "[이름] 가정", "문의 010-1111-2222", ROSTER, INST)
        self.assertEqual(con.execute("select count(*) from visits").fetchone()[0], 0)
        con.close()
        os.remove(db)

    def test_S_보관기한은_알리기만_하고_자동삭제는_없다(self):
        import datetime
        db = os.path.join(OUT, "_test_ret.db")
        if os.path.exists(db):
            os.remove(db)
        con = pastoral.init_db(db)
        old = datetime.datetime(2025, 9, 1)
        new = datetime.datetime(2026, 9, 1)
        pastoral.save_record(con, "OLD", "2025-09-01", "[이름] 가정 심방", "한 성도를 위해 기도해 주세요.", ROSTER, INST, now=old)
        pastoral.save_record(con, "NEW", "2026-09-01", "[이름] 가정 심방", "한 성도를 위해 기도해 주세요.", ROSTER, INST, now=new)
        due = pastoral.retention_due(con, today=datetime.date(2026, 10, 27))
        self.assertEqual([r[0] for r in due], ["OLD"])
        self.assertIn("삭제할까요", pastoral.due_message(due))
        self.assertEqual(con.execute("select count(*) from visits").fetchone()[0], 2, "알림만 하고 지웠다")
        with self.assertRaises(pastoral.DeleteNotConfirmed):
            pastoral.delete_records(con, ["OLD"])
        with self.assertRaises(pastoral.DeleteNotConfirmed):
            pastoral.delete_records(con, ["OLD"], "네")
        self.assertEqual(con.execute("select count(*) from visits").fetchone()[0], 2)
        pastoral.delete_records(con, ["OLD"], pastoral.CONFIRM_PHRASE)
        self.assertEqual(con.execute("select count(*) from visits").fetchone()[0], 1)
        con.close()
        os.remove(db)

    def test_S_처음부터_끝까지(self):
        d = os.path.join(OUT, "_test_run")
        shutil.rmtree(d, ignore_errors=True)
        r = pastoral.run(os.path.join(G, "visits"), os.path.join(G, "members.csv"), d, INST,
                         backend=ai_call.MockAI('{"summary": "요약", "prayers": []}'))
        self.assertEqual(len(r["saved"]), len(MEMOS))
        self.assertTrue(os.path.exists(r["mapping"]) and os.path.exists(r["db"]))
        mapping = open(r["mapping"], encoding="utf-8-sig").read()
        self.assertIn("곽도율", mapping, "대응표에는 원문이 있어야 복원된다")
        shared = "\n".join(r["share_lines"])
        self.assertNotIn("곽도율", shared)
        import sqlite3
        con = sqlite3.connect(r["db"])
        for (pt,) in con.execute("select pastor_text from visits"):
            for name, _ in ROSTER:
                self.assertNotIn(name, pt, "DB 에 실명이 들어 있다")
        con.close()
        shutil.rmtree(d, ignore_errors=True)


class 한계(unittest.TestCase):
    def test_L_알려진_한계는_실제로_새어_나간다(self):
        """고치지 못한 한계를 시험으로 고정한다. 누가 고치면 이 시험이 실패하고, 그때 책의 설명을 고친다."""
        cases = json.load(open(os.path.join(ROOT, "samples", "limits.json"), encoding="utf-8"))
        leaked = 0
        for c in cases:
            p, _ = pastoral.pastor_view(c["text"], ROSTER, INST)
            if c["leak"] in p:
                leaked += 1
        verify_core.record_metric(ROOT, "한계 사례 중 실제로 새어 나간 것", "%d/%d" % (leaked, len(cases)))
        self.assertGreaterEqual(leaked, 3, "한계가 해결됐다면 책의 설명을 고쳐야 한다")


if __name__ == "__main__":
    unittest.main()
