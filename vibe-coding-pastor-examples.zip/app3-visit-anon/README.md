# app3-visit-anon: 심방 메모 익명화 & 기도제목 정리 (Ch 8 예제)

로컬 익명화가 먼저, AI는 그다음. 표준 라이브러리만 씁니다(파이썬 3.11 이상, 이 책은 3.13 에서 검증).

```
python scripts/verify.py            # 하네스. 마지막 줄 RESULT: PASSED (n/n)
python scripts/run.py --demo        # 가짜 메모 32개로 연습 (결과는 output/demo/, output/share_prayers.txt)
python scripts/run.py               # data/ 의 실제 메모 (data/visits/*.txt, data/members.csv)
python scripts/run.py --due         # 보관 기한 알림 (지우지 않음)
python scripts/run.py --ai claude   # 익명화를 통과한 글만 구독 CLI 로 (실제 호출은 이 책을 쓴 PC에서 검증하지 못함)
```

| 위치 | 하는 일 |
| --- | --- |
| `src/anonymize.py` | 공통 모듈 복사본(목회자용, 공유용 익명화, 잔여 검사). SAFE_WORDS 에 안수, 서리를 더했다 |
| `src/ai_call.py` | 익명화 검사 미통과 시 호출 차단, 가짜 AI(MockAI) 시험 |
| `src/pastoral.py` | 공유용 일반화, 저장(sqlite3), 보관 기한 알림, 대응표, 클라우드 경로 경고, .gitignore 판정 |
| `samples/golden` | 가짜 심방 메모 32개, 가짜 명부 36명, 오탐 시험문 24개 |
| `samples/trap` | 걸려야 하는 샘플 7개와 expected.json |
| `samples/limits.json` | 고치지 못한 한계 5개(시험으로 고정) |
| `data/` | 실제 교인 정보를 두는 곳. Git 제외. `visits/*.txt`, `members.csv`, `institutions.txt`(직장, 단체 이름), `sensitive.txt`(`단어` 또는 `단어=건강 사정`) |

## 꼭 지킬 것
- 실제 메모, 명부, 대응표(mapping.csv), pastoral.db 는 data/ 에만 둡니다. Git, 메일, 클라우드 동기화 폴더(OneDrive, Dropbox, Google Drive, iCloud 등)로 내보내지 마세요. 경로에 그런 이름이 있으면 경고합니다.
- "누락 0건"은 이 폴더의 가짜 메모 기준입니다. 명부에 없는 별명, 성 없는 이름, 시도 이름 없는 주소, 한글로 쓴 전화번호는 놓칩니다(samples/limits.json). 공유 전에 목회자가 읽어 확인하세요.
- 공유용 기도제목은 일반화해도 작은 교회에서는 짐작될 수 있습니다.
- 이 앱은 법률 자문이 아닙니다. 종교, 건강 정보 처리에는 법적 요건이 있을 수 있으니 교회 개인정보 담당자와 확인하세요.
- 샘플의 모든 이름, 번호, 주소, 기관은 지어낸 것이며 우연히 실존과 같을 수 있습니다.

## 만든 이유 기록
공유용 가명 문제, 안수집사 오탐 등 실제로 겪은 실수는 CLAUDE.md 에 있습니다. 첫 하네스 결과는 output/run1_verify_report.json 에 남겼습니다.