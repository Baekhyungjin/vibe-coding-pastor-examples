"""심방 메모 익명화 & 기도제목 정리 (앱 3)

핵심 원칙: 로컬 익명화가 먼저, AI는 그다음.
  1) 목회자용 요약: 이름, 연락처 등을 번호 붙은 가명으로 바꾼다. 대응표로 복원할 수 있다(로컬 전용).
  2) 공유용 기도제목: 복원할 수 없게 일반화한다. 성도를 알아볼 단서가 없어야 한다.
  3) 남은 정보 검사(잔여 검사)를 통과하지 못하면 저장도, AI 전송도 하지 않는다.
표준 라이브러리만 쓴다.
"""
import csv
import datetime
import fnmatch
import os
import re
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import anonymize  # noqa: E402
import ai_call  # noqa: E402

TOKEN_GENERAL = {
    "건강 사정": "건강",
    "가정 사정": "가정",
    "경제 사정": "경제",
    "기타 사정": "사정",
}
DROP_TOKENS = ("연락처", "이메일", "주소", "주민번호", "기관")
ALIAS = re.compile(r"성도 [A-Z]+")
FAMILY_CLUE = re.compile(r"성도 [A-Z]+의 가족|가족의 |[가-힣]+(?:집사|권사|장로)님?네")
MAP_TRACE = re.compile(r"(?:성도 [A-Z]+|\[[가-힣 ]+\d+\])\s*(?:=|->|→|:)\s*[가-힣]{2,4}")


class ResidualFound(Exception):
    """익명화한 글에 개인정보가 남아 있을 때: 저장과 전송을 멈춘다"""


class DeleteNotConfirmed(Exception):
    """사람이 확인 문구를 직접 입력하지 않았을 때: 자동 삭제를 막는다"""


def load_roster(path):
    return anonymize.load_roster(path)


def load_lines(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8-sig") as f:
        return [l.strip() for l in f if l.strip() and not l.startswith("#")]


def load_memos(directory):
    memos = {}
    for fn in sorted(os.listdir(directory)):
        if fn.endswith(".txt"):
            with open(os.path.join(directory, fn), encoding="utf-8") as f:
                memos[fn[:-4]] = f.read()
    return memos


def visit_date(text):
    m = re.search(r"(20\d\d)[-.](\d\d)[-.](\d\d)", text)
    return "%s-%s-%s" % m.groups() if m else ""


# ---------------------------------------------------------------- 목회자용
def pastor_view(text, roster, institutions=None, sensitive=None):
    an = anonymize.Anonymizer(roster, sensitive=sensitive, institutions=institutions, mode="pastor")
    out = an.anonymize(text)
    return out, an


def check_pastor_text(text, roster, institutions=None, sensitive=None):
    """목회자용 가명 글에도 실명과 연락처가 남으면 안 된다."""
    return anonymize.residual_scan(text, roster, sensitive, institutions)


# ---------------------------------------------------------------- 공유용
def share_prayers(text, roster, institutions=None, sensitive=None):
    """공유용 기도제목: 기도 문장만 남기고, 성도를 알 수 있는 단서를 모두 지운다."""
    an = anonymize.Anonymizer(roster, sensitive=sensitive, institutions=institutions, mode="share")
    anon = an.anonymize(text)
    lines = []
    for sent in re.split(r"(?<=[.!?다요])\s+|\n+", anon):
        sent = sent.strip(" -*·\t")
        if "기도" not in sent:
            continue
        if any("[%s]" % t in sent for t in DROP_TOKENS):
            continue
        for tok, general in TOKEN_GENERAL.items():
            sent = sent.replace("[%s]" % tok, general)
        sent = re.sub(r"성도 [A-Z]+의 가족", "한 가정", sent)
        sent = re.sub(r"성도 [A-Z]+", "한 성도", sent)
        lines.append(sent)
    return lines


def check_share_text(text, roster, institutions=None, sensitive=None):
    """공유용 글에서 이유 코드를 찾는다. 빈 목록이어야 공유할 수 있다."""
    reasons = set()
    kind = {"명부이름": "명부이름", "연락처": "연락처", "이메일": "이메일", "주소": "주소", "주민번호": "주민번호",
            "기관": "기관", "민감단어": "민감단어", "이름후보": "이름후보"}
    for f in anonymize.residual_scan(text, roster, sensitive, institutions):
        reasons.add(kind.get(f["type"], f["type"]))
    if "명부이름" in reasons:
        reasons.discard("이름후보")   # 명부 이름이면 후보는 같은 말이라 하나로 합친다
    if ALIAS.search(text):
        reasons.add("가명단서")
    if FAMILY_CLUE.search(text):
        reasons.add("가족단서")
    if MAP_TRACE.search(text):
        reasons.add("대응표흔적")
    return sorted(reasons)


# ---------------------------------------------------------------- AI (모드 B)
SUMMARY_SCHEMA = {"required": {"summary": str, "prayers": list}}


def ai_summarize(pastor_text, backend, roster, institutions=None, sensitive=None):
    """익명화를 통과한 글만 AI에 보낸다. 통과하지 못하면 MaskingNotPassed 로 호출 자체가 막힌다."""
    prompt = ("다음은 이미 익명화한 심방 메모입니다. JSON 으로만 답하세요: "
              '{"summary": "세 문장 요약", "prayers": ["일반화한 기도제목"]}\n\n' + pastor_text)
    return ai_call.call_ai(prompt, backend, schema=SUMMARY_SCHEMA, roster=roster,
                           sensitive=sensitive, institutions=institutions)


# ---------------------------------------------------------------- 저장
def init_db(path):
    con = sqlite3.connect(path)
    con.execute("""CREATE TABLE IF NOT EXISTS visits(
        memo_id TEXT PRIMARY KEY, visit_date TEXT, pastor_text TEXT, share_text TEXT, created_at TEXT)""")
    con.commit()
    return con


def save_record(con, memo_id, date, pastor_text, share_text, roster, institutions=None, sensitive=None, now=None):
    left = check_pastor_text(pastor_text, roster, institutions, sensitive)
    if left:
        raise ResidualFound("저장을 멈춥니다. %s 에 남은 정보: %s" % (memo_id, sorted({f["type"] for f in left})))
    reasons = check_share_text(share_text, roster, institutions, sensitive)
    if reasons:
        raise ResidualFound("공유용 글 저장을 멈춥니다. %s: %s" % (memo_id, reasons))
    now = now or datetime.datetime.now()
    con.execute("INSERT OR REPLACE INTO visits VALUES(?,?,?,?,?)",
                (memo_id, date, pastor_text, share_text, now.isoformat(timespec="seconds")))
    con.commit()


def retention_due(con, today=None, days=365):
    """보관 기한이 지난 기록을 알려 주기만 한다. 지우지 않는다."""
    today = today or datetime.date.today()
    limit = (today - datetime.timedelta(days=days)).isoformat()
    rows = con.execute("SELECT memo_id, created_at FROM visits WHERE substr(created_at,1,10) < ? ORDER BY created_at",
                       (limit,)).fetchall()
    return rows


def due_message(rows):
    if not rows:
        return "보관 기한이 지난 기록이 없습니다."
    ids = ", ".join(r[0] for r in rows)
    return "보관 기한이 지난 기록 %d건이 있습니다: %s. 삭제할까요? 지우려면 사람이 직접 확인 문구를 입력해야 합니다." % (len(rows), ids)


CONFIRM_PHRASE = "삭제합니다"


def delete_records(con, ids, confirm_phrase=None):
    if confirm_phrase != CONFIRM_PHRASE:
        raise DeleteNotConfirmed("확인 문구가 없어 지우지 않았습니다.")
    con.executemany("DELETE FROM visits WHERE memo_id=?", [(i,) for i in ids])
    con.commit()


# ---------------------------------------------------------------- 대응표와 저장 위치
def write_mapping(path, rows_by_memo):
    with open(path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow(["메모ID", "가명", "원문", "종류"])
        for memo_id, rows in rows_by_memo.items():
            for r in rows:
                w.writerow([memo_id, r["가명"], r["원문"], r["종류"]])


CLOUD_NAMES = ("onedrive", "dropbox", "google drive", "googledrive", "icloud", "iclouddrive", "box sync", "mybox",
               "네이버 mybox", "synology", "nextcloud", "pcloud", "mega")


def cloud_warnings(path):
    """경로에 클라우드 동기화 폴더 이름이 들어 있으면 경고 문구를 돌려준다."""
    parts = [p.lower() for p in re.split(r"[\\/]+", os.path.abspath(path))]
    hits = sorted({c for c in CLOUD_NAMES for p in parts if c in p})
    return ["%s 은(는) 클라우드 동기화 폴더 안에 있습니다(%s). 대응표와 DB는 동기화되지 않는 폴더로 옮기세요." % (path, ", ".join(hits))] if hits else []


def gitignored(rel_path, gitignore_text):
    """아주 단순한 .gitignore 판정(마지막으로 맞는 줄이 이긴다). 슬래시는 / 로 통일."""
    rel = rel_path.replace("\\", "/").lstrip("./")
    result = False
    for raw in gitignore_text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        neg = line.startswith("!")
        pat = line[1:] if neg else line
        anchored = pat.startswith("/")
        pat = pat.lstrip("/")
        hit = False
        if pat.endswith("/"):
            hit = rel.startswith(pat) or ("/" + pat) in ("/" + rel)
        elif "/" in pat or anchored:
            hit = fnmatch.fnmatch(rel, pat) or rel.startswith(pat + "/")
        else:
            hit = any(fnmatch.fnmatch(part, pat) for part in rel.split("/"))
        if hit:
            result = not neg
    return result


# ---------------------------------------------------------------- 전체 실행
def run(visits_dir, roster_path, data_dir, institutions=None, sensitive=None, now=None, backend=None):
    roster = load_roster(roster_path)
    memos = load_memos(visits_dir)
    os.makedirs(data_dir, exist_ok=True)
    db_path = os.path.join(data_dir, "pastoral.db")
    map_path = os.path.join(data_dir, "mapping.csv")
    warnings = cloud_warnings(db_path) + cloud_warnings(map_path)
    con = init_db(db_path)
    mapping, saved, shared, ai_results = {}, [], [], {}
    for memo_id, text in memos.items():
        p_text, an = pastor_view(text, roster, institutions, sensitive)
        lines = share_prayers(text, roster, institutions, sensitive)
        s_text = "\n".join(lines)
        save_record(con, memo_id, visit_date(text), p_text, s_text, roster, institutions, sensitive, now)
        mapping[memo_id] = an.mapping_rows
        saved.append(memo_id)
        shared.extend(lines)
        if backend is not None:
            ai_results[memo_id] = ai_summarize(p_text, backend, roster, institutions, sensitive)
    write_mapping(map_path, mapping)
    con.close()
    return {"saved": saved, "share_lines": shared, "warnings": warnings, "ai": ai_results,
            "db": db_path, "mapping": map_path}
