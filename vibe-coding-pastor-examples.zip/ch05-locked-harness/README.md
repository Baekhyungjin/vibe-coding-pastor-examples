# ch05-locked-harness (목회자편 Ch 4~5 예제)

장절 범위 검사기에 다음 장치를 붙인 예제입니다.

1. 함정 샘플 + 걸려야 하는 이유(`samples/trap/expected.json`)
2. 검증 리포트(`output/verify_report.json`, 마지막 줄 `RESULT: PASSED (n/n)`)
3. 테스트 봉인(`scripts/lock.py`, `tests.lock`)과 경비원 훅(`scripts/guard_locked.py`)
4. 연속 실패 5회 멈춤(`output/fail_streak.json`)
5. 기준서 점검기(`scripts/criteria_lint.py`)와 교단 기준서 틀(`doctrine.template.md`, 가상 교단 `doctrine.example.md`)
6. 3-Agent 하네스 정의(`.claude/agents/`)와 신학 리뷰 서식(`theology_review.template.md`, `scripts/review_status.py`)

## 실행 (Windows, Python 3.13, 표준 라이브러리만)
```
python scripts/verify.py
python scripts/criteria_lint.py drafts/criteria_draft_bad.md
python scripts/criteria_lint.py drafts/criteria_draft_good.md
python scripts/lock.py "김 목사"        # 사람만 실행
python scripts/lock.py --check
python scripts/review_status.py
```
성경 본문은 들어 있지 않습니다. 장절의 존재만 검사합니다. 가짜 샘플은 모두 지어낸 것이며 실제 성도 정보가 없습니다.
