"""함정 샘플과 샘플 위생을 확인하는 테스트 (S2, S3, S4, N2, N3)."""
import json
import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from check_refs import check_text  # noqa: E402

GOLDEN = sorted((ROOT / "samples" / "golden").glob("*.txt"))
TRAP = sorted((ROOT / "samples" / "trap").glob("*.txt"))
EXPECTED = json.loads((ROOT / "samples" / "trap" / "expected.json").read_text(encoding="utf-8"))


class TestS_샘플판정(unittest.TestCase):

    def test_S4_골든샘플은_모두_통과(self):
        self.assertEqual(len(GOLDEN), 3, "골든 샘플은 3개여야 합니다.")
        for f in GOLDEN:
            passed, results = check_text(f.read_text(encoding="utf-8"))
            bad = [f"{r['raw']}({r['reason']})" for r in results if not r["ok"]]
            self.assertTrue(passed, f"{f.name}: 통과해야 하는데 틀림: {bad or '장절 없음'}")

    def test_S2_함정샘플은_모두_FAIL(self):
        self.assertGreaterEqual(len(TRAP), 3, "함정 샘플은 3개 이상이어야 합니다.")
        for f in TRAP:
            passed, _ = check_text(f.read_text(encoding="utf-8"))
            self.assertFalse(passed, f"{f.name}: 걸러야 하는데 PASS 로 통과시킴")

    def test_S3_함정은_정해진_이유로_걸린다(self):
        for f in TRAP:
            self.assertIn(f.name, EXPECTED, f"{f.name}: expected.json 에 이유가 없습니다.")
            _, results = check_text(f.read_text(encoding="utf-8"))
            reasons = " / ".join(r["reason"] for r in results if not r["ok"])
            self.assertIn(EXPECTED[f.name], reasons,
                          f"{f.name}: 이유가 다릅니다. 기대 '{EXPECTED[f.name]}', 실제 '{reasons or '이유 없음'}'")

    def test_S3_expected에_없는_함정파일은_없다(self):
        names = {f.name for f in TRAP}
        extra = [k for k in EXPECTED if not k.startswith("_") and k not in names]
        self.assertEqual(extra, [], f"expected.json 에만 있는 파일: {extra}")


class TestN_샘플위생(unittest.TestCase):

    def test_N3_샘플에_전화번호가_없다(self):
        phone = re.compile(r"01[016789][-\s]?\d{3,4}[-\s]?\d{4}|0\d{1,2}[-\s]\d{3,4}[-\s]\d{4}")
        for f in GOLDEN + TRAP:
            hits = phone.findall(f.read_text(encoding="utf-8"))
            self.assertEqual(hits, [], f"{f.name}: 전화번호 형식 발견 {hits}")

    def test_N2_샘플에_성경본문_문장이_없다(self):
        # 본문 인용 문장은 보통 '~하시니라', '~이라' 같은 어미로 길게 이어진다. 샘플은 장절 표기와 짧은 설명뿐이어야 한다.
        for f in GOLDEN + TRAP:
            for line in f.read_text(encoding="utf-8").splitlines():
                self.assertLess(len(line), 60, f"{f.name}: 한 줄이 너무 깁니다(본문 인용 의심): {line[:30]}")


if __name__ == "__main__":
    unittest.main()
