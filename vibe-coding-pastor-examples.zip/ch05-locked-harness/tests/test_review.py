"""신학 리뷰 서식과 서명 확인 도구를 확인하는 테스트 (3-Agent 하네스의 사람 몫)."""
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import review_status  # noqa: E402

TEMPLATE = (ROOT / "theology_review.template.md").read_text(encoding="utf-8")

SIGNED = TEMPLATE.replace("- 검토자:", "- 검토자: 김 목사").replace(
    "- 검토 일자:", "- 검토 일자: 2026-10-27").replace(
    "- 결정: (사용 / 수정 후 사용 / 사용 안 함)", "- 결정: 수정 후 사용")


class TestReview(unittest.TestCase):

    def test_R1_서식에는_세가지_표시와_서명란이_있다(self):
        for word in ("적합", "우려", "판단 필요", "검토자", "검토 일자", "결정"):
            self.assertIn(word, TEMPLATE, f"신학 리뷰 서식에 '{word}' 가 없습니다.")

    def test_R2_서명하지_않은_서식은_미완료로_본다(self):
        _, filled = review_status.status(TEMPLATE)
        self.assertEqual([k for k, v in filled.items() if not v], ["검토자", "검토 일자", "결정"])

    def test_R3_서명한_서식은_완료로_본다(self):
        _, filled = review_status.status(SIGNED)
        self.assertTrue(all(filled.values()), filled)

    def test_R4_교단기준서_틀에는_여섯_절이_있다(self):
        t = (ROOT / "doctrine.template.md").read_text(encoding="utf-8")
        for n in range(1, 7):
            self.assertIn(f"## {n}. ", t, f"doctrine.template.md 에 {n}번 절이 없습니다.")


if __name__ == "__main__":
    unittest.main()
