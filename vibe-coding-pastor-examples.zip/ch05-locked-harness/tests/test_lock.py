"""검사 장치를 검사하는 테스트: 봉인과 경비원이 정말 일하는지 확인한다.
실제 폴더는 건드리지 않고, output/ 아래 임시 폴더에 복사본을 만들어 시험한다.
"""
import json
import shutil
import subprocess
import sys
import unittest
import uuid
from contextlib import contextmanager
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

from lockutil import LOCK_NAME, compare, fingerprint  # noqa: E402

# 임시 폴더는 output/ 안에 직접 만들고 끝나면 지운다.
# tempfile 모듈의 시스템 임시 폴더는 일부 Windows 환경에서 쓰기가 거부된다.
TMP_BASE = ROOT / "output"


@contextmanager
def temp_dir():
    TMP_BASE.mkdir(exist_ok=True)
    path = TMP_BASE / f"_locktest_{uuid.uuid4().hex[:8]}"
    path.mkdir()
    try:
        yield path
    finally:
        shutil.rmtree(path, ignore_errors=True)


def make_copy(tmp):
    dst = Path(tmp) / "copy"
    for name in ["tests", "samples"]:
        shutil.copytree(ROOT / name, dst / name, ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(ROOT / "CRITERIA.md", dst / "CRITERIA.md")
    (dst / LOCK_NAME).write_text(json.dumps({"files": fingerprint(dst)}), encoding="utf-8")
    return dst


class TestLock(unittest.TestCase):

    def test_L2_봉인은_한글자_변경도_잡는다(self):
        with temp_dir() as tmp:
            dst = make_copy(tmp)
            self.assertEqual(compare(dst)[0], "OK", "막 봉인한 복사본은 이상이 없어야 합니다.")
            target = dst / "samples" / "trap" / "trap_01_없는장.txt"
            target.write_text(target.read_text(encoding="utf-8").replace("151", "150"), encoding="utf-8")
            state, problems = compare(dst)
            self.assertEqual(state, "BROKEN")
            self.assertTrue(any("trap_01_없는장.txt" in p for p in problems), problems)

    def test_L3_봉인은_파일삭제와_추가도_잡는다(self):
        with temp_dir() as tmp:
            dst = make_copy(tmp)
            (dst / "samples" / "trap" / "trap_02_없는절.txt").unlink()
            (dst / "tests" / "test_extra.py").write_text("# 몰래 추가한 테스트", encoding="utf-8")
            state, problems = compare(dst)
            self.assertEqual(state, "BROKEN")
            self.assertTrue(any(p.startswith("삭제됨") for p in problems), problems)
            self.assertTrue(any(p.startswith("새로 생김") for p in problems), problems)

    def test_L4_경비원은_봉인파일_수정을_막는다(self):
        guard = ROOT / "scripts" / "guard_locked.py"
        cases = {
            str(ROOT / "tests" / "test_check_refs.py"): 2,
            str(ROOT / "samples" / "trap" / "expected.json"): 2,
            str(ROOT / "CRITERIA.md"): 2,
            str(ROOT / "doctrine.md"): 2,
            str(ROOT / "tests.lock"): 2,
            str(ROOT / "src" / "check_refs.py"): 0,
            str(ROOT / "drafts" / "criteria_draft_bad.md"): 0,
        }
        for path, expected in cases.items():
            event = {"hook_event_name": "PreToolUse", "tool_name": "Edit", "tool_input": {"file_path": path}}
            done = subprocess.run([sys.executable, str(guard)], input=json.dumps(event),
                                  capture_output=True, text=True, encoding="utf-8")
            self.assertEqual(done.returncode, expected,
                             f"{Path(path).name}: 기대 {expected}, 실제 {done.returncode}")


if __name__ == "__main__":
    unittest.main()
