"""하네스 실행 진입점 (Ch 5 판: 봉인 확인 + 연속 실패 카운터)

하는 일
  1. 봉인(tests.lock) 확인: tests/, samples/, CRITERIA.md 가 승인 때와 같은지 본다.
     달라졌으면 L1_봉인확인 항목이 FAIL 이 된다.
  2. tests/ 폴더의 테스트를 모두 돌린다.
  3. 결과를 output/verify_report.json 에 기록한다.
  4. 같은 항목의 연속 실패 횟수를 output/fail_streak.json 에 센다.
  5. 마지막 줄에 RESULT: PASSED (n/n) 또는 RESULT: FAILED (k/n) 을 출력한다.

종료 코드 (Stop 훅이 읽는다)
  0 : 통과. AI는 일을 마쳐도 된다.
  2 : 실패. AI에게 실패 이유를 보여주고 계속 고치게 한다.
  1 : 같은 항목 5회 연속 실패. AI는 더 고치지 말고 멈춰서 사람에게 보고한다.

사용법:
    python scripts/verify.py          # 자세히
    python scripts/verify.py --quiet  # 요약만
"""
import datetime
import hashlib
import json
import os
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True  # 고친 코드가 바로 반영되도록 캐시 파일을 만들지 않는다
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
QUIET = "--quiet" in sys.argv
STOP_AFTER = 5  # 같은 항목이 이 횟수만큼 연속 실패하면 멈춘다

sys.path.insert(0, str(ROOT / "scripts"))
from lockutil import compare  # noqa: E402


def sample_hashes():
    hashes = {}
    for path in sorted((ROOT / "samples").rglob("*.txt")):
        rel = path.relative_to(ROOT).as_posix()
        hashes[rel] = hashlib.sha256(path.read_bytes()).hexdigest()[:12]
    return hashes


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def _name(self, test):
        return test.id().split(".")[-1]

    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({"test": self._name(test), "result": "PASS"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({"test": self._name(test), "result": "FAIL",
                             "reason": str(err[1]).splitlines()[0]})

    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({"test": self._name(test), "result": "ERROR",
                             "reason": f"{err[0].__name__}: {err[1]}"})


def check_lock():
    state, problems = compare(ROOT)
    if state == "OK":
        return {"test": "L1_봉인확인", "result": "PASS"}
    return {"test": "L1_봉인확인", "result": "FAIL",
            "reason": "봉인 위반. " + " / ".join(problems)}


def update_streak(records):
    path = ROOT / "output" / "fail_streak.json"
    streaks = {}
    if path.exists():
        streaks = json.loads(path.read_text(encoding="utf-8")).get("streaks", {})
    for r in records:
        if r["result"] == "PASS":
            streaks.pop(r["test"], None)
        else:
            streaks[r["test"]] = streaks.get(r["test"], 0) + 1
    path.write_text(json.dumps({
        "updated_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "stop_after": STOP_AFTER,
        "streaks": streaks,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return streaks


def main():
    records = [check_lock()]

    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    with open(os.devnull, "w", encoding="utf-8") as sink:
        runner = unittest.TextTestRunner(resultclass=RecordingResult, verbosity=0, stream=sink)
        result = runner.run(suite)
    records += result.records

    total = len(records)
    passed = sum(1 for r in records if r["result"] == "PASS")
    ok = total > 1 and passed == total

    out_dir = ROOT / "output"
    out_dir.mkdir(exist_ok=True)
    streaks = update_streak(records)
    worst = max(streaks.values(), default=0)

    report = {
        "app": ROOT.name,
        "run_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "sample_hashes": sample_hashes(),
        "tests": records,
        "result": "PASSED" if ok else "FAILED",
        "passed": passed,
        "total": total,
        "fail_streak_max": worst,
    }
    (out_dir / "verify_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    if not QUIET:
        print(f"[하네스] {ROOT.name} 검사 시작 ({report['run_at']})")
        for r in records:
            line = f"  {r['result']:<5} {r['test']}"
            if "reason" in r:
                line += f"\n        이유: {r['reason']}"
            if r["test"] in streaks:
                line += f"\n        연속 실패: {streaks[r['test']]}회째"
            print(line)
        print("  리포트: output/verify_report.json")

    if ok:
        print(f"RESULT: PASSED ({passed}/{total})")
        return 0

    print(f"RESULT: FAILED ({total - passed}/{total})")

    if worst >= STOP_AFTER:
        stuck = [name for name, n in streaks.items() if n >= STOP_AFTER]
        msg = (f"멈춤: {', '.join(stuck)} 항목이 {STOP_AFTER}회 연속 실패했습니다. "
               "더 고치지 말고, 원인 추정과 선택지 2~3개를 사람에게 보고하세요.")
        print(msg)
        print(msg, file=sys.stderr)
        return 1

    # Stop 훅이 종료 코드 2를 받으면 stderr 내용을 AI에게 보여준다.
    for r in records:
        if r["result"] != "PASS":
            print(f"{r['result']} {r['test']}: {r.get('reason', '')}", file=sys.stderr)
    print("하네스 실패: 위 항목을 고친 뒤 다시 실행하세요. tests/, samples/, CRITERIA.md, tests.lock 은 고치지 마세요.",
          file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
