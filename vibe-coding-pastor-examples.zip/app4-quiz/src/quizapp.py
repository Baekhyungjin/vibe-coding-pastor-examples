# -*- coding: utf-8 -*-
"""앱 4: 소그룹 나눔 질문 & 성경 퀴즈 (표준 라이브러리만)

흐름
  1. AI(모드 B, 하네스에서는 MockAI)가 문항 JSON 초안과 3단계 나눔 질문 초안을 만든다.
  2. 이 파일의 validate_quiz() 가 기계로 확인할 수 있는 것만 확인한다.
       스키마, 근거 장절이 입력 범위 안인지, 정답 핵심어가 본문 데이터에 있는지,
       대상별 글자 수, 중복 선택지, doctrine.md 의 피해야 할 표현, 본문 장문 인용.
  3. 통과한 문항만 빌드 없는 단일 HTML 퀴즈와 인쇄용 나눔 질문(.md)으로 만든다.

정직한 한계: 질문이 신학적으로 건전한지는 기계가 판정하지 않는다.
  doctrine.md 의 금지 표현 검사와 목회자의 승인이 전부다. 신학 리뷰 에이전트의 의견은 별도 파일이다.
"""
import difflib
import html
import json
import os
import re
import sys

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMMON = os.path.join(APP, "common")
if COMMON not in sys.path:
    sys.path.insert(0, COMMON)

import ai_call  # noqa: E402
import bible_store  # noqa: E402

TYPES = ("객관식", "OX", "순서맞추기")
STAGES = ("관찰", "해석", "적용")
# 대상별 글자 수 상한 (질문, 선택지). 교회 사정에 맞게 고쳐 쓴다.
AUDIENCE = {
    "유치": {"q": 20, "c": 12},
    "초등": {"q": 30, "c": 20},
    "청소년": {"q": 50, "c": 30},
    "장년": {"q": 80, "c": 50},
}
QUOTE_LIMIT = 20          # 본문과 정규화 글자 20자 이상 이어서 같으면 장문 인용으로 본다
AI_SCHEMA = {"required": {"questions": list, "discussion": dict}}
REVIEW_STATUS = ("적합", "우려", "판단 필요")
SITE_HOST = "https://bible.bskorea.or.kr/"


class Issue:
    def __init__(self, code, qid, detail):
        self.code, self.qid, self.detail = code, qid, detail

    def __repr__(self):
        return "%s[%s] %s" % (self.code, self.qid, self.detail)


def load_store(app_dir=None):
    app_dir = app_dir or APP
    return bible_store.BibleStore(os.path.join(app_dir, "config", "bible.json"), base_dir=app_dir)


def load_forbidden(doctrine_text):
    """doctrine.md 의 '피해야 할 해석과 표현' 절에서 '표현:' 뒤의 낱말 목록을 읽는다."""
    terms = []
    for line in doctrine_text.splitlines():
        m = re.search(r"표현:\s*(.+)$", line)
        if m:
            terms += [t.strip() for t in re.split(r"[,，]", m.group(1)) if t.strip()]
    return terms


def _norm(s):
    return bible_store.normalize(s)


def _refs_keys(store, ref_text):
    refs = store.parser.parse(ref_text)
    keys = []
    for r in refs:
        keys += store.keys_for(r)
    return refs, keys


def _longest_common(a, b):
    if not a or not b:
        return 0
    return difflib.SequenceMatcher(None, a, b, autojunk=False).find_longest_match(0, len(a), 0, len(b)).size


def _texts_of(q):
    out = [q.get("question", ""), q.get("explanation", "")]
    out += [c for c in q.get("choices", []) if isinstance(c, str)]
    out += [k for k in q.get("answer_keywords", []) if isinstance(k, str)]
    return [t for t in out if isinstance(t, str)]


def validate_question(q, store, passage_keys, audience, forbidden):
    """문항 하나를 확인해 Issue 목록을 돌려준다. 스키마가 틀리면 다른 확인은 건너뛴다."""
    qid = q.get("id", "?") if isinstance(q, dict) else "?"
    if not isinstance(q, dict):
        return [Issue("SCHEMA", qid, "문항이 객체가 아닙니다")]
    need = ("id", "type", "question", "choices", "answer", "evidence_ref", "explanation", "answer_keywords")
    missing = [k for k in need if k not in q]
    if missing:
        return [Issue("SCHEMA", qid, "빠진 항목: %s" % ", ".join(missing))]
    if q["type"] not in TYPES:
        return [Issue("SCHEMA", qid, "type 은 %s 중 하나" % "/".join(TYPES))]
    ch = q["choices"]
    kw = q["answer_keywords"]
    if not isinstance(ch, list) or len(ch) < 2 or not all(isinstance(c, str) and c.strip() for c in ch):
        return [Issue("SCHEMA", qid, "choices 는 비어 있지 않은 글 2개 이상")]
    if not isinstance(kw, list) or not kw or not all(isinstance(k, str) and k.strip() for k in kw):
        return [Issue("SCHEMA", qid, "answer_keywords 는 글 1개 이상")]
    for f in ("question", "explanation", "evidence_ref", "id"):
        if not isinstance(q[f], str) or not q[f].strip():
            return [Issue("SCHEMA", qid, "%s 는 비어 있지 않은 글" % f)]
    ans = q["answer"]
    issues = []
    if q["type"] == "순서맞추기":
        if not (isinstance(ans, list) and sorted(ans) == list(range(len(ch))) and len(ch) >= 3):
            return [Issue("SCHEMA", qid, "순서맞추기는 선택지 3개 이상, answer 는 선택지 번호를 순서대로 담은 목록")]
        if len(kw) != len(ch):
            return [Issue("SCHEMA", qid, "순서맞추기는 answer_keywords 개수가 선택지 개수와 같아야 합니다")]
    elif q["type"] == "OX":
        if ch != ["맞다", "틀리다"]:
            return [Issue("SCHEMA", qid, "OX 선택지는 [맞다, 틀리다]")]
        if not (isinstance(ans, int) and not isinstance(ans, bool) and ans in (0, 1)):
            issues.append(Issue("ANSWER_RANGE", qid, "OX 정답은 0 또는 1"))
    else:
        if not (isinstance(ans, int) and not isinstance(ans, bool) and 0 <= ans < len(ch)):
            issues.append(Issue("ANSWER_RANGE", qid, "정답 번호 %r 이 선택지 범위(0~%d) 밖" % (ans, len(ch) - 1)))
    if issues:
        return issues
    # 근거 장절
    refs, keys = _refs_keys(store, q["evidence_ref"])
    if not refs or not keys:
        return [Issue("EVIDENCE_UNKNOWN", qid, "근거 장절을 읽을 수 없습니다: %s" % q["evidence_ref"])]
    outside = [k for k in keys if k not in passage_keys]
    if outside:
        issues.append(Issue("EVIDENCE_OUT_OF_RANGE", qid, "입력 본문 범위 밖: %s" % ", ".join(outside[:3])))
        evidence_text = None
    elif any(not store.active.has(k) for k in keys):
        issues.append(Issue("EVIDENCE_UNKNOWN", qid, "본문 데이터에 없는 절이 있습니다"))
        evidence_text = None
    else:
        evidence_text = " ".join(store.active.get(k) for k in keys)
    if evidence_text is not None:
        ev = _norm(evidence_text)
        positions = []
        for k in kw:
            p = ev.find(_norm(k))
            if p < 0:
                issues.append(Issue("KEYWORD_NOT_IN_TEXT", qid, "정답 핵심어 '%s' 가 근거 절 본문에 없습니다" % k))
            positions.append(p)
        if q["type"] == "순서맞추기" and all(p >= 0 for p in positions) and positions != sorted(set(positions)):
            issues.append(Issue("ORDER_MISMATCH", qid, "핵심어가 본문에 나오는 순서와 정답 순서가 다릅니다"))
        if q["type"] == "객관식" and not any(_norm(k) in _norm(ch[ans]) for k in kw):
            issues.append(Issue("ANSWER_NOT_LINKED", qid, "정답 선택지에 핵심어가 하나도 들어 있지 않습니다"))
    # 글자 수, 중복
    lim = AUDIENCE[audience]
    if len(q["question"]) > lim["q"]:
        issues.append(Issue("TOO_LONG", qid, "질문 %d자 > %s 상한 %d자" % (len(q["question"]), audience, lim["q"])))
    longc = [c for c in ch if len(c) > lim["c"]]
    if longc:
        issues.append(Issue("TOO_LONG", qid, "선택지 %d자 > %s 상한 %d자" % (len(longc[0]), audience, lim["c"])))
    normed = [_norm(c) for c in ch]
    if len(set(normed)) != len(normed):
        issues.append(Issue("DUP_CHOICE", qid, "같은 선택지가 있습니다"))
    # 교단 기준서의 피해야 할 표현
    for t in forbidden:
        if any(t in s for s in _texts_of(q)):
            issues.append(Issue("DOCTRINE_TERM", qid, "피해야 할 표현 '%s'" % t))
    # 본문 장문 인용 (공개판은 본문 전문을 싣지 않는다)
    verse_norms = [_norm(store.active.get(k)) for k in passage_keys if store.active.has(k)]
    whole = "".join(verse_norms)
    own = _norm(" ".join([q["question"], q["explanation"]] + ch))
    for part in [_norm(q["question"]), _norm(q["explanation"])] + normed:
        if _longest_common(part, whole) >= QUOTE_LIMIT:
            issues.append(Issue("QUOTE_TOO_LONG", qid, "본문과 %d자 이상 이어서 같습니다. 장절 표기로 바꾸세요" % QUOTE_LIMIT))
            break
    return issues


def validate_discussion(disc, forbidden):
    issues = []
    if not isinstance(disc, dict):
        return [Issue("SCHEMA", "나눔", "discussion 이 객체가 아닙니다")]
    for st in STAGES:
        items = disc.get(st)
        if not (isinstance(items, list) and items and all(isinstance(x, str) and x.strip() for x in items)):
            issues.append(Issue("DISCUSSION_STAGE", "나눔", "'%s' 단계 질문이 없습니다" % st))
            continue
        for t in forbidden:
            if any(t in x for x in items):
                issues.append(Issue("DOCTRINE_TERM", "나눔", "피해야 할 표현 '%s' (%s 단계)" % (t, st)))
    return issues


def validate_quiz(data, store, passage, audience, count, forbidden):
    """AI 초안 전체를 확인한다. 돌려주는 값: Issue 목록 (비어 있으면 기계 검증 통과)."""
    if audience not in AUDIENCE:
        raise ValueError("대상은 %s 중 하나" % "/".join(AUDIENCE))
    refs, keys = _refs_keys(store, passage)
    if not refs or not keys:
        return [Issue("PASSAGE", "-", "입력 본문 범위를 읽을 수 없습니다: %s" % passage)]
    if any(not store.active.has(k) for k in keys):
        return [Issue("PASSAGE", "-", "본문 데이터에 없는 절이 있습니다. data/bible 에 번역본 데이터를 넣으세요")]
    issues = []
    qs = data.get("questions") if isinstance(data, dict) else None
    if not isinstance(qs, list):
        return [Issue("SCHEMA", "-", "questions 가 목록이 아닙니다")]
    if len(qs) != count:
        issues.append(Issue("COUNT", "-", "문항 %d개, 요청은 %d개" % (len(qs), count)))
    ids = [q.get("id") for q in qs if isinstance(q, dict)]
    if len(set(ids)) != len(ids):
        issues.append(Issue("DUP_ID", "-", "문항 번호가 겹칩니다"))
    for q in qs:
        issues += validate_question(q, store, set(keys), audience, forbidden)
    issues += validate_discussion(data.get("discussion"), forbidden)
    return issues


def codes(issues):
    return sorted({i.code for i in issues})


# ------------------------------------------------------------------ AI 호출 (모드 B)
def build_prompt(passage, audience, count, translation_name, forbidden):
    return (
        "다음 본문으로 소그룹 나눔 질문과 성경 퀴즈 초안을 JSON 으로만 답하세요.\n"
        "본문 범위: %s (%s)\n대상: %s\n문항 수: %d\n"
        "문항 형식: {id,type(객관식|OX|순서맞추기),question,choices,answer,evidence_ref,explanation,answer_keywords}\n"
        "나눔 질문 형식: {관찰:[...],해석:[...],적용:[...]}\n"
        "규칙: 근거 장절은 본문 범위 안, 정답 핵심어는 그 절 본문에 있는 낱말, 본문을 길게 베끼지 말 것.\n"
        "피해야 할 표현: %s\n" % (passage, translation_name, audience, count, ", ".join(forbidden) or "없음")
    )


def generate(passage, audience, count, backend, store=None, doctrine_text=None):
    """AI 에 초안을 받아 검증한다. 돌려주는 값: (data, issues)."""
    store = store or load_store()
    if doctrine_text is None:
        doctrine_text = open(os.path.join(APP, "doctrine.md"), encoding="utf-8").read()
    forbidden = load_forbidden(doctrine_text)
    prompt = build_prompt(passage, audience, count, store.active.name, forbidden)
    data = ai_call.call_ai(prompt, backend, schema=AI_SCHEMA, roster=[])
    return data, validate_quiz(data, store, passage, audience, count, forbidden)


# ------------------------------------------------------------------ 퀴즈 화면 (빌드 없는 단일 HTML)
GRADE_JS = """function grade(q, picked) {
  if (picked === null || picked === undefined) return "skip";
  if (q.type === "순서맞추기") {
    if (!Array.isArray(picked) || picked.length !== q.answer.length) return "skip";
    for (var i = 0; i < picked.length; i++) { if (picked[i] !== q.answer[i]) return "wrong"; }
    return "right";
  }
  return picked === q.answer ? "right" : "wrong";
}"""

CSS = """*{box-sizing:border-box}html{-webkit-text-size-adjust:100%}
body{margin:0;font-family:'Malgun Gothic','Apple SD Gothic Neo',sans-serif;background:#f6f3ec;color:#1f2430;font-size:18px;line-height:1.6;overflow-wrap:anywhere}
main{max-width:560px;margin:0 auto;padding:16px 16px 40px}
h1{font-size:22px;line-height:1.35;margin:8px 0 4px}.sub{color:#5a6070;font-size:15px;margin:0 0 14px}
.card{background:#fff;border:1px solid #d9d4c7;border-radius:12px;padding:16px;margin:12px 0}
.q{font-size:20px;font-weight:700;margin:0 0 12px}
.choice,.btn{display:block;width:100%;min-height:52px;margin:8px 0;padding:10px 14px;font:inherit;text-align:left;background:#fff;color:#1f2430;border:2px solid #aab1c2;border-radius:10px;cursor:pointer}
.btn{text-align:center;background:#24406b;color:#fff;border-color:#24406b;font-weight:700}.btn.ghost{background:#fff;color:#24406b}
.choice.picked{border-color:#24406b;background:#e8eef9}.choice.right{border-color:#1b7f4b;background:#e3f4ea}.choice.wrong{border-color:#b3261b;background:#fbe9e7}
.choice:disabled{cursor:default}.order{display:inline-block;min-width:1.6em;margin-right:6px;font-weight:700;color:#24406b}
.fb{margin-top:10px;padding:10px 12px;border-radius:8px;background:#f1f3f8}.fb[data-result=right]{background:#e3f4ea}.fb[data-result=wrong]{background:#fbe9e7}
.meta{font-size:14px;color:#5a6070;margin-top:6px}a{color:#24406b}.notice{font-size:14px;color:#5a6070;margin-top:20px}
ul.sum{padding-left:20px}.score{font-size:26px;font-weight:800;margin:4px 0}"""

JS = r"""
%(GRADE)s
var state = {i: 0, results: [], picks: [], done: false};
var root = document.getElementById("app");
function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text !== undefined) e.textContent = text; return e; }
function clear() { while (root.firstChild) root.removeChild(root.firstChild); }
function refLink(q) {
  var span = el("div", "meta", "근거: " + q.evidence_ref + " (" + DATA.translation + ") ");
  var a = el("a", "", "성경 사이트에서 읽기"); a.href = DATA.chapter_url; a.target = "_blank"; a.rel = "noopener noreferrer"; span.appendChild(a);
  return span;
}
function feedback(q, result) {
  var fb = el("div", "fb"); fb.id = "feedback"; fb.setAttribute("data-result", result);
  var head = result === "right" ? "정답입니다" : (result === "wrong" ? "아쉬워요. 다시 생각해 봐요" : "건너뛰었어요");
  fb.appendChild(el("strong", "", head));
  fb.appendChild(el("div", "", q.explanation));
  fb.appendChild(refLink(q));
  return fb;
}
function render() {
  clear();
  if (state.i >= DATA.questions.length) { return renderEnd(); }
  var q = DATA.questions[state.i];
  var card = el("section", "card");
  card.appendChild(el("div", "meta", (state.i + 1) + " / " + DATA.questions.length));
  card.appendChild(el("p", "q", q.question));
  var list = el("div", "choices"); list.id = "choices";
  q.choices.forEach(function (c, idx) {
    var b = el("button", "choice"); b.type = "button"; b.setAttribute("data-idx", idx);
    var mark = state.picks.indexOf(idx);
    if (q.type === "순서맞추기" && mark >= 0) { b.className += " picked"; b.appendChild(el("span", "order", String(mark + 1))); }
    b.appendChild(document.createTextNode(c));
    if (state.done) { b.disabled = true; }
    b.addEventListener("click", function () { onPick(q, idx); });
    list.appendChild(b);
  });
  card.appendChild(list);
  root.appendChild(card);
  if (state.done) {
    var r = state.results[state.i];
    if (q.type !== "순서맞추기") {
      var kids = list.children;
      if (r !== "skip") { kids[q.answer].className += " right"; }
      if (r === "wrong" && state.picks.length) { kids[state.picks[0]].className += " wrong"; }
    }
    card.appendChild(feedback(q, r));
    var nxt = el("button", "btn", state.i + 1 >= DATA.questions.length ? "결과 보기" : "다음 문제"); nxt.type = "button"; nxt.id = "next";
    nxt.addEventListener("click", function () { state.i++; state.picks = []; state.done = false; render(); });
    card.appendChild(nxt);
  } else {
    if (q.type === "순서맞추기") {
      var ok = el("button", "btn", "순서 확인"); ok.type = "button"; ok.id = "confirm"; ok.disabled = state.picks.length !== q.choices.length;
      ok.addEventListener("click", function () { finish(q, state.picks.slice()); });
      var rs = el("button", "btn ghost", "다시 고르기"); rs.type = "button"; rs.id = "reset";
      rs.addEventListener("click", function () { state.picks = []; render(); });
      card.appendChild(ok); card.appendChild(rs);
    }
    var sk = el("button", "btn ghost", "건너뛰기"); sk.type = "button"; sk.id = "skip";
    sk.addEventListener("click", function () { finish(q, null); });
    card.appendChild(sk);
  }
}
function onPick(q, idx) {
  if (state.done) return;
  if (q.type === "순서맞추기") {
    var p = state.picks.indexOf(idx);
    if (p >= 0) { state.picks.splice(p, 1); } else { state.picks.push(idx); }
    render(); return;
  }
  state.picks = [idx];
  finish(q, idx);
}
function finish(q, picked) {
  var r = grade(q, picked);
  state.results[state.i] = r; state.done = true;
  if (picked !== null && q.type !== "순서맞추기") { state.picks = [picked]; }
  render();
}
function renderEnd() {
  var right = 0, wrong = 0, skip = 0;
  DATA.questions.forEach(function (q, k) { var r = state.results[k] || "skip"; if (r === "right") right++; else if (r === "wrong") wrong++; else skip++; });
  var card = el("section", "card"); card.id = "end";
  card.appendChild(el("div", "meta", "끝났어요"));
  var sc = el("div", "score", "정답 " + right + " / " + DATA.questions.length); sc.id = "score"; card.appendChild(sc);
  card.appendChild(el("div", "", "오답 " + wrong + "개, 건너뜀 " + skip + "개"));
  card.appendChild(el("p", "meta", "점수는 이 화면에만 보이고 어디에도 저장하거나 보내지 않아요. 새로고침하면 사라져요."));
  var ul = el("ul", "sum");
  DATA.questions.forEach(function (q, k) { ul.appendChild(el("li", "", (k + 1) + "번 근거: " + q.evidence_ref)); });
  card.appendChild(ul);
  var again = el("button", "btn", "처음부터 다시"); again.type = "button"; again.id = "again";
  again.addEventListener("click", function () { state = {i: 0, results: [], picks: [], done: false}; render(); });
  card.appendChild(again);
  root.appendChild(card);
}
render();
"""


def render_quiz_html(data, passage, audience, translation_name, chapter_url, title=None):
    """통과한 문항으로 단일 HTML 을 만든다. 본문 전문은 싣지 않고 장절 표기와 링크만 싣는다."""
    payload = {
        "translation": translation_name,
        "chapter_url": chapter_url,
        "questions": [{k: q[k] for k in ("id", "type", "question", "choices", "answer", "evidence_ref", "explanation")}
                      for q in data["questions"]],
    }
    blob = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    title = title or "성경 퀴즈 %s" % passage
    return (
        "<!doctype html>\n<html lang=\"ko\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        "<meta name=\"robots\" content=\"noindex\"><title>%s</title><style>%s</style></head><body><main>"
        "<h1>%s</h1><p class=\"sub\">%s, 대상 %s. 본문: %s</p>"
        "<div id=\"app\"></div>"
        "<p class=\"notice\">성경 본문은 이 화면에 싣지 않았어요. 본문은 <a href=\"%s\" target=\"_blank\" rel=\"noopener noreferrer\">대한성서공회 성경플랫폼(%s)</a>에서 읽어 주세요. "
        "문항은 AI 초안을 목회자가 검토한 것입니다. 이 화면은 어떤 정보도 모으거나 보내지 않아요.</p>"
        "</main><script>var DATA = %s;%s</script></body></html>\n"
    ) % (html.escape(title), CSS, html.escape(title), html.escape(translation_name), html.escape(audience),
         html.escape(passage), html.escape(chapter_url), html.escape(translation_name), blob, JS % {"GRADE": GRADE_JS})


def chapter_url_for(store, passage, app_dir=None):
    """장 단위 성경 사이트 주소. 책 코드 표(app2-bulletin/data/bible_codes.json 형식)를 config 에서 읽는다."""
    app_dir = app_dir or APP
    cfg = store.config.get("bible_site", {})
    codes_path = os.path.join(app_dir, "data", "bible_codes.json")
    refs = store.parser.parse(passage)
    if not refs or not os.path.exists(codes_path):
        return SITE_HOST
    book = refs[0].book
    table = json.load(open(codes_path, encoding="utf-8"))["by_id"]
    item = table.get(str(book.id))
    if item:
        return cfg.get("chapter_url", SITE_HOST).format(code=item["code"], chapter=refs[0].c1)
    return SITE_HOST


# ------------------------------------------------------------------ 나눔 질문 (인쇄용 .md)
def render_discussion_md(data, passage, audience, translation_name, chapter_url):
    d = data["discussion"]
    lines = ["# 소그룹 나눔 질문: %s" % passage, "",
             "- 번역본: %s (본문은 이 문서에 싣지 않았습니다. %s 에서 읽으세요)" % (translation_name, chapter_url),
             "- 대상: %s" % audience,
             "- **AI 초안, 목회자 검토 필요.** 교단 기준서(doctrine.md)의 피해야 할 표현 검사는 통과했지만 신학적 건전성은 목회자가 판단합니다.", ""]
    for st, hint in (("관찰", "본문에 무엇이 쓰여 있나요?"), ("해석", "그 말씀은 무슨 뜻일까요?"), ("적용", "나는 어떻게 살아 볼까요? 나누고 싶은 만큼만 나눕니다.")):
        lines += ["## %s 질문: %s" % (st, hint), ""]
        lines += ["%d. %s" % (i + 1, x) for i, x in enumerate(d[st])] + [""]
    return "\n".join(lines)


# ------------------------------------------------------------------ 신학 리뷰 (AI 의견, PASSED 와 별개)
REVIEW_SCHEMA = {"required": {"items": list}}


def theology_review_md(review, passage, translation_name):
    items = review["items"]
    for it in items:
        if it.get("status") not in REVIEW_STATUS:
            raise ValueError("신학 리뷰 상태는 %s 중 하나: %r" % ("/".join(REVIEW_STATUS), it.get("status")))
    lines = ["# 신학 리뷰 (AI 의견): %s" % passage, "",
             "> **이 문서는 AI 의견입니다.** 기계 검증 결과(PASSED)에 포함되지 않으며, 최종 판단은 목회자가 합니다.",
             "> 번역본: %s" % translation_name, "",
             "| 항목 | 의견 | 근거 |", "| --- | --- | --- |"]
    lines += ["| %s | %s | %s |" % (it["item"], it["status"], it.get("note", "")) for it in items]
    lines += ["", "## 서명란", "", "- 검토자:", "- 검토 일자:", "- 결정 (사용 / 수정 후 사용 / 사용 안 함):", ""]
    return "\n".join(lines)


# ------------------------------------------------------------------ 한 번에
def build_all(passage="막 4:35-41", audience="초등", count=5, backend=None, review_backend=None, out_dir=None, app_dir=None):
    app_dir = app_dir or APP
    store = load_store(app_dir)
    out_dir = out_dir or os.path.join(app_dir, "output")
    os.makedirs(out_dir, exist_ok=True)
    doctrine = open(os.path.join(app_dir, "doctrine.md"), encoding="utf-8").read()
    data, issues = generate(passage, audience, count, backend, store, doctrine)
    result = {"issues": issues, "files": []}
    if issues:
        return result            # 하나라도 걸리면 화면과 문서를 만들지 않는다
    tag = re.sub(r"[^0-9A-Za-z가-힣]+", "_", passage).strip("_")
    url = chapter_url_for(store, passage, app_dir)
    name = store.active.name
    files = {
        "quiz_%s.html" % tag: render_quiz_html(data, passage, audience, name, url),
        "나눔질문_%s.md" % tag: render_discussion_md(data, passage, audience, name, url),
    }
    if review_backend is not None:
        review = ai_call.call_ai("신학 리뷰 요청: %s 의 문항과 나눔 질문을 doctrine.md 기준으로 검토" % passage, review_backend, schema=REVIEW_SCHEMA, roster=[])
        files["theology_review.md"] = theology_review_md(review, passage, name)
    for fn, text in files.items():
        with open(os.path.join(out_dir, fn), "w", encoding="utf-8", newline="\n") as f:
            f.write(text)
        result["files"].append(fn)
    return result
