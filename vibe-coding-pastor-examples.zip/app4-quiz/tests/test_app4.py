# -*- coding: utf-8 -*-
"""앱 4 하네스 (unittest). 항목 번호는 CRITERIA.md 의 S, N, H 번호와 같다.
T1 스키마 / T2 함정이 각자의 이유로 걸림 / T3 채점(정답, 오답, 미응답) / T4 네트워크 0 / T5 교단 금지 표현 / T6 모바일 규칙"""
import json
import os
import re
import shutil
import subprocess
import sys
import unittest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(APP, "src"))
sys.dont_write_bytecode = True

import quizapp  # noqa: E402
import ai_call  # noqa: E402
import verify_core  # noqa: E402

G = os.path.join(APP, "samples", "golden")
T = os.path.join(APP, "samples", "trap")
TMP = os.path.join(APP, "output", "_test_tmp")
EXPECTED = json.load(open(os.path.join(T, "expected.json"), encoding="utf-8"))
PASSAGE, AUD, N = "막 4:35-41", "초등", 5


def jread(d, fn):
    with open(os.path.join(d, fn), encoding="utf-8") as f:
        return json.load(f)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = quizapp.load_store(APP)
        cls.doctrine = open(os.path.join(APP, "doctrine.md"), encoding="utf-8").read()
        cls.forbidden = quizapp.load_forbidden(cls.doctrine)
        cls.golden = jread(G, "ai_ok.json")
        shutil.rmtree(TMP, ignore_errors=True)
        os.makedirs(TMP, exist_ok=True)
        mock = ai_call.MockAI(json.dumps(cls.golden, ensure_ascii=False))
        review = ai_call.MockAI(json.dumps(jread(G, "review_ok.json"), ensure_ascii=False))
        cls.result = quizapp.build_all(PASSAGE, AUD, N, mock, review, out_dir=TMP, app_dir=APP)
        cls.html = open(os.path.join(TMP, "quiz_막_4_35_41.html"), encoding="utf-8").read()

    def check(self, data, aud=AUD):
        return quizapp.validate_quiz(data, self.store, PASSAGE, aud, N, self.forbidden)


class TestSchema(Base):
    def test_T1_골든_문항은_모든_검사를_통과한다(self):
        self.assertEqual([], [str(i) for i in self.check(self.golden)])
        self.assertEqual(N, len(self.golden["questions"]))
        self.assertEqual({"관찰", "해석", "적용"}, set(self.golden["discussion"]))

    def test_T1_문항_유형_세_가지가_모두_있다(self):
        self.assertEqual({"객관식", "OX", "순서맞추기"}, {q["type"] for q in self.golden["questions"]})

    def test_T1_AI_응답이_JSON_형식이_아니면_거부한다(self):
        with self.assertRaises(ai_call.BadAIResponse):
            quizapp.generate(PASSAGE, AUD, N, ai_call.MockAI("문제는 이렇습니다: 첫째 ..."), self.store, self.doctrine)


class TestTraps(Base):
    def test_T2_함정은_모두_기대한_이유로_걸린다(self):
        self.assertGreaterEqual(len(EXPECTED), 12)
        for fn, e in EXPECTED.items():
            got = quizapp.codes(self.check(jread(T, fn), e["audience"]))
            self.assertEqual(sorted(e["codes"]), got, "%s: 기대 %s, 실제 %s" % (fn, e["codes"], got))

    def test_T2_걸린_함정으로는_화면과_문서를_만들지_않는다(self):
        out = os.path.join(TMP, "trap_out")
        bad = jread(T, "trap_01_범위밖근거.json")
        r = quizapp.build_all(PASSAGE, AUD, N, ai_call.MockAI(json.dumps(bad, ensure_ascii=False)), None, out_dir=out, app_dir=APP)
        self.assertTrue(r["issues"])
        self.assertEqual([], r["files"])
        self.assertEqual([], os.listdir(out))


def run_node(script):
    node = shutil.which("node")
    if not node:
        return None
    try:
        done = subprocess.run([node, "-"], input=script, capture_output=True, text=True, encoding="utf-8", timeout=60)
    except OSError:
        return None          # 이 PC처럼 node 실행이 막힌 곳
    if done.returncode != 0:
        return None
    return done.stdout.strip()


class TestGrade(Base):
    def test_T3_채점_정답_오답_미응답_순서맞추기(self):
        qs = {q["id"]: q for q in self.golden["questions"]}
        script = quizapp.GRADE_JS + "\nvar Q=" + json.dumps(qs, ensure_ascii=False) + ";\n" + """
var out = [
  grade(Q.Q1, 0), grade(Q.Q1, 2), grade(Q.Q1, null),
  grade(Q.Q3, 0), grade(Q.Q3, 1),
  grade(Q.Q5, [1,2,0]), grade(Q.Q5, [0,1,2]), grade(Q.Q5, [1,2]), grade(Q.Q5, null)
];
console.log(JSON.stringify(out));"""
        out = run_node(script)
        if out is None:
            self.skipTest("node 가 없어 채점 함수를 직접 실행하지 못했습니다. 브라우저 검사(output/browser_report.json)로 대신 확인하세요")
        self.assertEqual(["right", "wrong", "skip", "right", "wrong", "right", "wrong", "skip", "skip"], json.loads(out))

    def test_T3_화면에_채점_함수가_그대로_들어_있다(self):
        self.assertIn(quizapp.GRADE_JS, self.html)

    def test_T3_브라우저_검사_결과가_지금_화면과_맞다(self):
        """node 가 막힌 PC 에서도 채점을 믿으려면, 브라우저에서 실제로 눌러 본 결과(output/browser_report.json)가
        지금 만든 화면(해시)에 대한 것이어야 한다. 화면을 고쳤다면 브라우저 검사를 다시 해야 한다."""
        import hashlib
        path = os.path.join(APP, "output", "browser_report.json")
        self.assertTrue(os.path.exists(path), "output/browser_report.json 이 없습니다. 브라우저 검사를 먼저 하세요")
        rep = json.load(open(path, encoding="utf-8"))
        now = hashlib.sha256(self.html.encode("utf-8")).hexdigest()[:16]
        self.assertEqual(now, rep["html_sha256"], "화면이 바뀌었습니다. 브라우저 검사를 다시 하세요")
        bad = [c["name"] for c in rep["cases"] if not c["ok"]]
        self.assertEqual([], bad, "브라우저 검사에서 실패한 항목: %s" % bad)
        names = {c["name"] for c in rep["cases"]}
        for need in ("정답", "오답", "건너뛰기", "순서맞추기 정답", "순서맞추기 오답", "결과 점수", "다시 하기", "네트워크 요청 0", "360px 가로 스크롤 0", "버튼 44px 이상"):
            self.assertIn(need, names, "브라우저 검사 항목 빠짐: " + need)


class TestNetworkAndMobile(Base):
    BANNED = ["fetch(", "XMLHttpRequest", "WebSocket", "sendBeacon", "localStorage", "sessionStorage",
              "document.cookie", "indexedDB", "<script src", "<link", "@import", "<img", "<iframe", "import(", "eval(", "new Function"]

    def test_T4_화면에_네트워크_저장_코드가_없다(self):
        for pat in self.BANNED:
            self.assertNotIn(pat, self.html, "금지 패턴: " + pat)

    def test_T4_바깥_주소는_성경_사이트_링크_하나뿐이다(self):
        urls = re.findall(r"https?://[^\s\"'<>\\]+", self.html)
        self.assertTrue(urls)
        for u in urls:
            self.assertTrue(u.startswith(quizapp.SITE_HOST), "허용 밖 주소: " + u)
        hrefs = re.findall(r"""href=\\?["']([^"'\\]+)""", self.html)
        self.assertTrue(all(h.startswith(quizapp.SITE_HOST) for h in hrefs))

    def test_T6_모바일_규칙_버튼_44px_이상_뷰포트_가로넘침_방지(self):
        self.assertIn('name="viewport"', self.html)
        heights = [int(x) for x in re.findall(r"min-height:(\d+)px", self.html)]
        self.assertTrue(heights and min(heights) >= 44, heights)
        self.assertIn("overflow-wrap:anywhere", self.html)
        self.assertIn("box-sizing:border-box", self.html)
        m = re.search(r"main\{max-width:(\d+)px", self.html)
        self.assertTrue(m and int(m.group(1)) <= 600)
        self.assertTrue(int(re.search(r"font-size:(\d+)px", self.html).group(1)) >= 16)

    def test_T6_검색_노출_막기_noindex(self):
        self.assertIn('name="robots" content="noindex"', self.html)


class TestDoctrine(Base):
    def test_T5_금지_표현은_기준서에서_읽는다(self):
        self.assertIn("완전수", self.forbidden)
        self.assertGreaterEqual(len(self.forbidden), 3)

    def test_T5_결과물에_금지_표현이_없다(self):
        for fn in self.result["files"]:
            if fn == "theology_review.md":
                continue
            text = open(os.path.join(TMP, fn), encoding="utf-8").read()
            for t in self.forbidden:
                self.assertNotIn(t, text, "%s 에 '%s'" % (fn, t))

    def test_T5_기준서를_느슨하게_고치면_함정이_통과해_버린다는_것을_보여_준다(self):
        loose = [t for t in self.forbidden if t != "완전수"]
        bad = jread(T, "trap_03_금지표현.json")
        self.assertEqual([], quizapp.codes(quizapp.validate_quiz(bad, self.store, PASSAGE, AUD, N, loose)))
        self.assertEqual(["DOCTRINE_TERM"], quizapp.codes(self.check(bad)))


class TestNever(Base):
    def test_N1_결과물에_번역본_이름을_적는다(self):
        self.assertIn("개역한글", self.html)
        md = open(os.path.join(TMP, "나눔질문_막_4_35_41.md"), encoding="utf-8").read()
        self.assertIn("개역한글", md)

    def test_N2_본문_전문을_싣지_않는다(self):
        verses = [self.store.active.get(k) for k in self.store.active.verses]
        for v in verses:
            self.assertNotIn(v, self.html)
        md = open(os.path.join(TMP, "나눔질문_막_4_35_41.md"), encoding="utf-8").read()
        for v in verses:
            self.assertNotIn(v, md)

    def test_N3_개역개정_본문_데이터를_넣지_않는다(self):
        cfg = json.load(open(os.path.join(APP, "config", "bible.json"), encoding="utf-8"))
        for t in cfg["translations"].values():
            self.assertNotIn("개정", t["name"])
        for fn in os.listdir(os.path.join(APP, "data", "bible")):
            d = jread(os.path.join(APP, "data", "bible"), fn)
            self.assertNotIn("개정", d.get("translation_name", ""))

    def test_N4_AI에_보내는_글에_교인_정보가_섞이면_호출을_막는다(self):
        with self.assertRaises(ai_call.MaskingNotPassed):
            ai_call.call_ai("이 본문으로 문항을 만들어 줘. 문의 010-1234-5678", ai_call.MockAI("{}"), roster=[])

    def test_N5_claude_bare_옵션을_쓰지_않는다(self):
        with self.assertRaises(ValueError):
            ai_call.build_command("gemini", "x")
        self.assertNotIn("--bare", " ".join(ai_call.build_command("claude", "x")))

    def test_N6_점수는_저장하거나_보내지_않는다고_화면에_알린다(self):
        self.assertIn("어디에도 저장하거나 보내지 않아요", self.html)


class TestReview(Base):
    def test_H1_신학_리뷰는_AI_의견이며_서명란이_있다(self):
        md = open(os.path.join(TMP, "theology_review.md"), encoding="utf-8").read()
        self.assertIn("AI 의견", md)
        self.assertIn("서명란", md)
        self.assertIn("판단 필요", md)

    def test_H1_신학_리뷰_상태_값이_틀리면_거부한다(self):
        with self.assertRaises(ValueError):
            quizapp.theology_review_md({"items": [{"item": "x", "status": "문제없음"}]}, PASSAGE, "개역한글")


if __name__ == "__main__":
    unittest.main()
