# 앱 4: 소그룹 나눔 질문 & 성경 퀴즈

로컬에서 문항을 만들고 검증한 뒤, 빌드 없는 단일 HTML 퀴즈와 인쇄용 나눔 질문을 만듭니다. 설치할 것이 없습니다(Python 표준 라이브러리).

## 실행
```
python scripts/make_samples.py       # 가짜 AI 응답(골든, 함정) 만들기. 승인 전에만
python scripts/run.py                # 가짜 AI(MockAI)로 output/ 에 결과물 만들기
python scripts/run.py --ai claude    # 내 구독으로 실제 AI 호출 (이 책의 PC 에서는 검증하지 못함)
python scripts/verify.py             # 하네스. 마지막 줄 RESULT: PASSED (n/n)
```
결과물: `output/quiz_막_4_35_41.html`(퀴즈), `output/나눔질문_막_4_35_41.md`, `output/theology_review.md`(AI 의견, 서명란)

## 폴더
- `data/bible/gaehan_mark.json` 막 4:35-41 개역한글(공식 사이트에서 옮김, 확인 2026-10-27). 교회가 실제로 쓸 번역본은 허가 범위를 확인한 뒤 같은 형식으로 넣고 `config/bible.json` 에 등록
- `doctrine.md` 교단 기준서(가상 교단 예시). 4번의 `표현:` 낱말이 금지 표현
- `samples/golden`, `samples/trap` 통과해야 하는 샘플, 걸려야 하는 샘플(`expected.json` 에 이유)
- `output/browser_report.json` 브라우저에서 눌러 본 결과(화면 해시 포함), `output/screens/` 390px 화면

## 한계
- 질문이 신학적으로 건전한지는 판정하지 않습니다. 금지 표현 검사와 목회자 승인이 전부입니다.
- 정답 핵심어가 본문에 있는지만 봅니다. 질문이 본문의 뜻을 바르게 묻는지는 사람이 읽습니다.
- 브라우저 검사는 이 책을 쓴 PC 한 곳에서만 했습니다. 실제 폰과 다른 브라우저는 확인하지 못했습니다.
- 실제 `claude -p` / `codex exec` 호출은 검증하지 못했습니다. 하네스는 가짜 AI 로만 돌렸습니다.