# -*- coding: utf-8 -*-
"""골든(통과해야 함)과 함정(반드시 걸려야 함) 샘플을 만든다. 모두 AI 가 쓴 것처럼 꾸민 가짜 응답이다.
실행: python scripts/make_samples.py   (samples/ 는 승인 뒤 봉인되므로 승인 전에만 다시 만든다)"""
import copy
import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(ROOT, "samples", "golden")
T = os.path.join(ROOT, "samples", "trap")
os.makedirs(G, exist_ok=True)
os.makedirs(T, exist_ok=True)

GOOD = {
    "questions": [
        {"id": "Q1", "type": "객관식", "question": "예수님은 배의 어디에서 주무셨나요?",
         "choices": ["고물(배의 뒤쪽)", "뱃머리", "돛대 위", "물가"], "answer": 0,
         "evidence_ref": "막 4:38", "answer_keywords": ["고물"],
         "explanation": "예수님은 배의 뒤쪽에서 베개를 베고 주무셨어요."},
        {"id": "Q2", "type": "객관식", "question": "예수님이 바람에게 하신 말씀은?",
         "choices": ["잠잠하라 고요하라", "빨리 지나가라", "더 세게 불어라", "배를 돌려라"], "answer": 0,
         "evidence_ref": "막 4:39", "answer_keywords": ["잠잠하라"],
         "explanation": "예수님이 말씀하시자 바람이 그치고 바다가 잔잔해졌어요."},
        {"id": "Q3", "type": "OX", "question": "바람과 바다가 예수님께 순종했다.",
         "choices": ["맞다", "틀리다"], "answer": 0,
         "evidence_ref": "막 4:41", "answer_keywords": ["순종"],
         "explanation": "제자들은 바람과 바다도 순종하는 예수님을 보고 놀랐어요."},
        {"id": "Q4", "type": "객관식", "question": "배에 가득 들어온 것은 무엇인가요?",
         "choices": ["물결", "모래", "양떼", "고기"], "answer": 0,
         "evidence_ref": "막 4:37", "answer_keywords": ["물결"],
         "explanation": "큰 광풍 때문에 물결이 배 안으로 들어왔어요."},
        {"id": "Q5", "type": "순서맞추기", "question": "일어난 순서대로 눌러 보세요.",
         "choices": ["바람이 그치고 잔잔해졌다", "큰 광풍이 일어났다", "예수님이 바람을 꾸짖으셨다"],
         "answer": [1, 2, 0], "evidence_ref": "막 4:37-39", "answer_keywords": ["광풍", "꾸짖으시며", "그치고"],
         "explanation": "광풍이 일어나고, 예수님이 꾸짖으시고, 바람이 그쳤어요."},
    ],
    "discussion": {
        "관찰": ["제자들은 어떤 상황에 있었나요?", "그때 예수님은 무엇을 하고 계셨나요?"],
        "해석": ["예수님은 왜 제자들에게 믿음을 물으셨을까요?", "제자들의 두려움은 어떻게 바뀌었나요?"],
        "적용": ["요즘 나를 두렵게 하는 일이 있다면 나누고 싶은 만큼만 말해 봅시다.", "이번 주에 예수님께 맡겨 보고 싶은 일 하나를 정해 봅시다."],
    },
}

REVIEW = {"items": [
    {"item": "해석 원칙: 본문의 문맥을 먼저 밝힌다", "status": "적합", "note": "문항이 본문 안의 사건과 말씀만 묻습니다"},
    {"item": "피해야 할 표현 목록", "status": "적합", "note": "doctrine.md 4번 표현이 없습니다"},
    {"item": "적용 질문의 방향", "status": "판단 필요", "note": "폭풍을 삶의 문제에 견주는 적용이 교단 기준에 맞는지는 목회자가 판단"},
]}


def dump(path, obj):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)


def variant(fn):
    d = copy.deepcopy(GOOD)
    fn(d)
    return d


def q(d, qid):
    return next(x for x in d["questions"] if x["id"] == qid)


TRAPS = {
    "trap_01_범위밖근거": (lambda d: q(d, "Q1").update(evidence_ref="막 4:20"), ["EVIDENCE_OUT_OF_RANGE"], "초등"),
    "trap_02_본문에없는정답": (lambda d: q(d, "Q4").update(choices=["호수", "모래", "양떼", "고기"], answer_keywords=["호수"]), ["KEYWORD_NOT_IN_TEXT"], "초등"),
    "trap_03_금지표현": (lambda d: q(d, "Q2").update(explanation="바람이 그친 것은 3과 7 같은 완전수의 비밀을 보여 줘요."), ["DOCTRINE_TERM"], "초등"),
    "trap_04_중복선택지": (lambda d: q(d, "Q4").update(choices=["물결", "모래", "모래", "고기"]), ["DUP_CHOICE"], "초등"),
    "trap_05_초등길이초과": (lambda d: q(d, "Q1").update(question="예수님은 제자들과 함께 건너가시던 그 배 안에서 정확히 어디쯤에 누워 주무셨나요?"), ["TOO_LONG"], "초등"),
    "trap_06_장문인용": (lambda d: q(d, "Q2").update(explanation="예수께서 깨어 바람을 꾸짖으시며 바다더러 이르시되 잠잠하라 고요하라 하시니 바람이 그치고 아주 잔잔하여지더라"), ["QUOTE_TOO_LONG"], "초등"),
    "trap_07_스키마위반": (lambda d: q(d, "Q3").pop("answer"), ["SCHEMA"], "초등"),
    "trap_08_문항수부족": (lambda d: d["questions"].pop(), ["COUNT"], "초등"),
    "trap_09_순서어긋남": (lambda d: q(d, "Q5").update(answer_keywords=["꾸짖으시며", "광풍", "그치고"]), ["ORDER_MISMATCH"], "초등"),
    "trap_10_나눔질문단계빠짐": (lambda d: d["discussion"].pop("적용"), ["DISCUSSION_STAGE"], "초등"),
    "trap_11_정답번호범위밖": (lambda d: q(d, "Q1").update(answer=9), ["ANSWER_RANGE"], "초등"),
    "trap_12_정답에핵심어없음": (lambda d: q(d, "Q1").update(answer=1), ["ANSWER_NOT_LINKED"], "초등"),
    "trap_13_유치길이초과": (lambda d: None, ["TOO_LONG"], "유치"),
}


def main():
    dump(os.path.join(G, "ai_ok.json"), GOOD)
    dump(os.path.join(G, "review_ok.json"), REVIEW)
    expected = {}
    for name, (fn, expect, aud) in TRAPS.items():
        dump(os.path.join(T, name + ".json"), variant(fn))
        expected[name + ".json"] = {"codes": expect, "audience": aud}
    dump(os.path.join(T, "expected.json"), expected)
    print("골든 2개, 함정 %d개" % len(TRAPS))


if __name__ == "__main__":
    main()
