# -*- coding: utf-8 -*-
"""python scripts/run.py [--passage "막 4:35-41"] [--audience 초등] [--count 5] [--ai claude|codex]
기본은 가짜 AI(MockAI)로 samples/golden 의 응답을 쓴다."""
import argparse, json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
import quizapp, ai_call

ap = argparse.ArgumentParser()
ap.add_argument("--passage", default="막 4:35-41")
ap.add_argument("--audience", default="초등", choices=list(quizapp.AUDIENCE))
ap.add_argument("--count", type=int, default=5)
ap.add_argument("--ai", choices=["claude", "codex"])
a = ap.parse_args()
if a.ai:
    backend = review = ai_call.cli_backend(a.ai)
else:
    g = os.path.join(ROOT, "samples", "golden")
    backend = ai_call.MockAI(open(os.path.join(g, "ai_ok.json"), encoding="utf-8").read())
    review = ai_call.MockAI(open(os.path.join(g, "review_ok.json"), encoding="utf-8").read())
res = quizapp.build_all(a.passage, a.audience, a.count, backend, review, app_dir=ROOT)
if res["issues"]:
    print("검증 실패: 화면과 문서를 만들지 않았습니다")
    for i in res["issues"]:
        print("  -", i)
    sys.exit(2)
print("만들었습니다:", ", ".join(res["files"]), "(output/)")
print("신학 리뷰(theology_review.md)는 AI 의견입니다. 목회자가 읽고 서명하세요.")