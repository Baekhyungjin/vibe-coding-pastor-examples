# -*- coding: utf-8 -*-
"""앱 1 하네스 (unittest). 항목 번호는 CRITERIA.md 의 S, N 번호와 같다.
T1 장절 변형 파싱 / T2 없는 장절 / T3 한 글자, 띄어쓰기 / T4 번역본 혼용 /
T5 원어 데이터에 없는 단어 / T6 배경 출처 태그, AI 라벨 / T7 번역본명 표기 / N 금지사항 / H 신학 리뷰는 별도."""
import json
import os
import shutil
import sys
import unittest

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(APP, "src"))
sys.dont_write_bytecode = True

import checker  # noqa: E402
import verify_core  # noqa: E402  (common 에서 checker 가 경로를 넣어 둔다)
import ai_call  # noqa: E402

G = os.path.join(APP, "samples", "golden")
T = os.path.join(APP, "samples", "trap")
TMP = os.path.join(APP, "output", "_test_tmp")
EXPECTED = json.load(open(os.path.join(T, "expected.json"), encoding="utf-8"))


def read(d, fn):
    return checker.read_manuscript(os.path.join(d, fn))


def mock(reply_text):
    return ai_call.MockAI(lambda _p: reply_text)


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.store = checker.load_store()
        cls.orig = checker.load_originals()
        cls.doctrine = open(os.path.join(APP, "doctrine.md"), encoding="utf-8").read()
        shutil.rmtree(TMP, ignore_errors=True)
        os.makedirs(TMP, exist_ok=True)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(TMP, ignore_errors=True)


PARSE_CASES = [
    ("요 3:16", ("요", 3, 16, 3, 16)), ("요한복음 3장 16절", ("요", 3, 16, 3, 16)), ("요3:16-18", ("요", 3, 16, 3, 18)),
    ("창 1:1-2:3", ("창", 1, 1, 2, 3)), ("시 23편", ("시", 23, None, 23, None)), ("빌 4:4~7", ("빌", 4, 4, 4, 7)),
    ("요일 1:9", ("요일", 1, 9, 1, 9)), ("삼상 3:10", ("삼상", 3, 10, 3, 10)), ("열왕기하 2:11", ("왕하", 2, 11, 2, 11)),
    ("고린도전서 13장 4절", ("고전", 13, 4, 13, 4)), ("마 5:3-12", ("마", 5, 3, 5, 12)), ("행 17:11", ("행", 17, 11, 17, 11)),
    ("사 40:31", ("사", 40, 31, 40, 31)), ("눅 14:28", ("눅", 14, 28, 14, 28)), ("갈 2:20", ("갈", 2, 20, 2, 20)),
    ("엡 2:8-9", ("엡", 2, 8, 2, 9)), ("히 11:1", ("히", 11, 1, 11, 1)), ("계 3:20", ("계", 3, 20, 3, 20)),
    ("잠언 3:5-6", ("잠", 3, 5, 3, 6)), ("시편 119편 105절", ("시", 119, 105, 119, 105)), ("유 1:3", ("유", 1, 3, 1, 3)),
    ("빌4:13", ("빌", 4, 13, 4, 13)), ("창세기 1장 1절", ("창", 1, 1, 1, 1)), ("출 3:14", ("출", 3, 14, 3, 14)),
    ("렘 29:11", ("렘", 29, 11, 29, 11)), ("합 2:4", ("합", 2, 4, 2, 4)), ("고후 5:17", ("고후", 5, 17, 5, 17)),
    ("살전 5:16-18", ("살전", 5, 16, 5, 18)), ("딤후 3:16", ("딤후", 3, 16, 3, 16)), ("벧전 2:9", ("벧전", 2, 9, 2, 9)),
    ("요삼 1:2", ("요삼", 1, 2, 1, 2)), ("요 3장", ("요", 3, None, 3, None)), ("마태복음 28장 19-20절", ("마", 28, 19, 28, 20)),
    ("요 3:16-4:3", ("요", 3, 16, 4, 3)), ("(요 3:16 개역한글)", ("요", 3, 16, 3, 16)),
]


class TestParse(Base):
    def test_T1_장절변형_파싱_100퍼센트(self):
        wrong = []
        for text, key in PARSE_CASES:
            got = [r.key() for r in self.store.parser.parse(text)]
            if got != [key]:
                wrong.append((text, got))
        self.assertEqual(wrong, [], "파싱이 기대와 다른 표기: %s" % wrong)
        verify_core.record_metric(APP, "T1 장절 변형 파싱", "%d/%d" % (len(PARSE_CASES) - len(wrong), len(PARSE_CASES)))
        self.assertGreaterEqual(len(PARSE_CASES), 30)

    def test_T1_시간과_날짜는_장절로_읽지_않는다(self):
        rep = checker.check_manuscript("오전 11:00 예배, 2026.10.18 주일, 10:30:15 시작.", self.store)
        self.assertEqual(rep["refs"], [])


class TestGolden(Base):
    def test_S1_골든_txt_docx_모두_통과(self):
        for fn in ("sermon_ok.txt", "sermon_ok.docx"):
            rep = checker.check_manuscript(read(G, fn), self.store)
            self.assertEqual(rep["status"], "PASS", "%s: %s" % (fn, rep["fail_codes"]))
            self.assertEqual(len(rep["quotes"]), 3)
            self.assertTrue(all(q["status"] == "PASS" for q in rep["quotes"]))

    def test_S1_출력_파일_세_종류_생성(self):
        rep = checker.run_manuscript(os.path.join(G, "sermon_ok.txt"), out_dir=TMP, store=self.store)
        self.assertEqual(rep["status"], "PASS")
        for fn in ("인용검사_sermon_ok.md", "인용검사_sermon_ok.html", "theology_review.md"):
            self.assertTrue(os.path.exists(os.path.join(TMP, fn)), fn)


class TestTraps(Base):
    def _codes(self, fn):
        rep = checker.check_manuscript(read(T, fn), self.store)
        return rep, sorted(set(rep["fail_codes"]))

    def test_T2_없는_장절과_걸린_이유(self):
        for fn in ("trap_01_없는절.txt", "trap_02_없는편.txt", "trap_06_역순.txt", "trap_07_모호약어.txt"):
            rep, codes = self._codes(fn)
            self.assertEqual(rep["status"], "FAIL", fn)
            self.assertEqual(codes, sorted(EXPECTED[fn]), "%s 이(가) 엉뚱한 이유로 걸렸습니다: %s" % (fn, codes))

    def test_T3_한글자와_띄어쓰기_인용_차이_표시(self):
        rep, codes = self._codes("trap_03_한글자.txt")
        self.assertEqual(codes, ["MISMATCH"])
        q = rep["quotes"][0]
        self.assertTrue(q["diffs"], "차이 위치가 표시돼야 합니다")
        self.assertIn("멸망", q["expected"])
        rep2, codes2 = self._codes("trap_04_띄어쓰기.txt")
        self.assertEqual(codes2, ["SPACING_DIFF"])
        md = checker.render_check_md(rep2, "t")
        self.assertIn("띄어쓰기", md)

    def test_T4_번역본_혼용_경고(self):
        rep, codes = self._codes("trap_05_번역본혼용.txt")
        self.assertEqual(codes, ["MIXED_TRANSLATION"])
        self.assertIn("번역본 B(가상)", rep["quotes"][0]["message"])

    def test_T4_expected_json_이_모든_함정을_덮는다(self):
        files = {f for f in os.listdir(T) if f != "expected.json"}
        self.assertEqual(files, set(EXPECTED), "expected.json 과 함정 파일 목록이 다릅니다")


class TestResearch(Base):
    def _run(self, fn, ref="요 3:16"):
        text = open(os.path.join(G if fn == "ai_ok.json" else T, fn), encoding="utf-8").read()
        return checker.research(ref, self.store, self.orig, self.doctrine, mock(text))

    def test_T6_골든_AI초안은_라벨과_출처가_모두_있다(self):
        res = self._run("ai_ok.json")
        self.assertEqual(res["issues"], [])
        md = checker.render_research_md(res)
        self.assertEqual(checker.lint_research_md(md, self.store.active.name), [])
        self.assertIn(checker.AI_LABEL, md)
        self.assertIn("[출처: 예시 주석 1]", md)

    def test_T5_원어_데이터에_없는_단어는_걸러진다(self):
        res = self._run("ai_01_원어없음.json")
        self.assertEqual([i["code"] for i in res["issues"]], EXPECTED["ai_01_원어없음.json"])
        md = checker.render_research_md(res)
        self.assertIn("원어 데이터에 없는 단어라 설명을 뺐습니다", md)
        self.assertNotIn("사랑이라는 명사", md)

    def test_T6_출처_없는_배경은_출처확인필요_표시(self):
        res = self._run("ai_02_출처없음.json")
        self.assertEqual([i["code"] for i in res["issues"]], EXPECTED["ai_02_출처없음.json"])
        md = checker.render_research_md(res)
        self.assertIn("[%s]" % checker.NO_SOURCE, md)
        self.assertEqual(checker.lint_research_md(md, self.store.active.name), [])

    def test_T6_허용_밖_출처도_출처확인필요(self):
        res = self._run("ai_03_출처허용밖.json")
        self.assertEqual([i["code"] for i in res["issues"]], EXPECTED["ai_03_출처허용밖.json"])
        self.assertIn("[%s]" % checker.NO_SOURCE, checker.render_research_md(res))

    def test_T6_자유문장_응답은_거부된다(self):
        text = open(os.path.join(T, "ai_04_자유문장.txt"), encoding="utf-8").read()
        with self.assertRaises(ai_call.BadAIResponse):
            checker.research("요 3:16", self.store, self.orig, self.doctrine, mock(text))

    def test_T6_린터는_라벨을_지우면_잡아낸다(self):
        md = checker.render_research_md(self._run("ai_ok.json"))
        broken = md.replace(checker.AI_LABEL, "")
        self.assertTrue(any(i.startswith("NO_AI_LABEL") for i in checker.lint_research_md(broken, self.store.active.name)))
        no_tag = md.replace("[출처: 예시 주석 1]", "")
        self.assertTrue(any(i.startswith("NO_SOURCE_TAG") for i in checker.lint_research_md(no_tag, self.store.active.name)))

    def test_N_AI에는_장절과_원어_단어만_보낸다(self):
        ai = mock(open(os.path.join(G, "ai_ok.json"), encoding="utf-8").read())
        checker.research("요 3:16", self.store, self.orig, self.doctrine, ai)
        self.assertEqual(len(ai.received), 1)
        sent = ai.received[0]
        self.assertIn("요 3:16", sent)
        self.assertNotIn("연습용 가짜 설교", sent)
        self.assertNotIn(self.store.active.get("요 3:16"), sent, "성경 본문 전체나 원고를 AI 로 보내지 않습니다")

    def test_원어_정리는_데이터에서_그대로_표시한다(self):
        res = checker.research("시 23:1", self.store, self.orig, self.doctrine, None)
        md = checker.render_research_md(res)
        self.assertIn("CC BY 4.0", md)
        self.assertIn("개역한글", md)
        self.assertFalse(res["ai"])


class TestNames(Base):
    def test_T7_번역본명은_설정값을_따른다(self):
        for fn in ("sermon_ok.txt",):
            rep = checker.run_manuscript(os.path.join(G, fn), out_dir=TMP, store=self.store)
            for out in ("인용검사_sermon_ok.md", "인용검사_sermon_ok.html", "theology_review.md"):
                body = open(os.path.join(TMP, out), encoding="utf-8").read()
                self.assertIn(self.store.active.name, body, out)
        # 설정을 바꾸면 이름도 바뀐다(코드에 하드코딩하지 않았다는 증거)
        cfg = json.load(open(os.path.join(APP, "config", "bible.json"), encoding="utf-8"))
        cfg["translations"]["gaehan"]["name"] = "시험용 이름"
        alt = os.path.join(TMP, "cfg")
        os.makedirs(alt, exist_ok=True)
        shutil.copytree(os.path.join(APP, "data"), os.path.join(alt, "data"), dirs_exist_ok=True)
        os.makedirs(os.path.join(alt, "config"), exist_ok=True)
        json.dump(cfg, open(os.path.join(alt, "config", "bible.json"), "w", encoding="utf-8"), ensure_ascii=False)
        store2 = checker.load_store(alt)
        rep2 = checker.check_manuscript(read(G, "sermon_ok.txt"), store2)
        self.assertEqual(rep2["translation"], "시험용 이름")
        self.assertTrue(any(w["code"] == "NO_TRANSLATION_LABEL" for w in rep2["warnings"]))

    def test_T7_번역본명_표기가_빠진_원고는_경고(self):
        text = "연습용\n\u201c%s\u201d(요 3:16)\n" % self.store.active.get("요 3:16")
        rep = checker.check_manuscript(text, self.store)
        self.assertEqual(rep["status"], "PASS")
        self.assertEqual([w["code"] for w in rep["warnings"]], ["NO_TRANSLATION_LABEL"])


class TestNever(Base):
    def test_N1_개역개정_본문_데이터가_없다(self):
        for root, _, files in os.walk(os.path.join(APP, "data")):
            for fn in files:
                if fn.endswith(".json"):
                    raw = open(os.path.join(root, fn), encoding="utf-8").read()
                    try:
                        meta = json.loads(raw)
                    except ValueError:
                        continue
                    label = "%s %s" % (meta.get("translation_name", ""), meta.get("translation_id", "")) if isinstance(meta, dict) else ""
                    self.assertNotIn("개역개정", label, fn)

    def test_N2_번역본_이름은_코드에_적지_않는다(self):
        src = open(os.path.join(APP, "src", "checker.py"), encoding="utf-8").read()
        self.assertNotIn("개역한글", src)
        self.assertNotIn("개역개정", src)

    def test_N3_bare_옵션을_쓰지_않는다(self):
        for d in ("src", "common"):
            for fn in os.listdir(os.path.join(APP, d)):
                if fn.endswith(".py"):
                    body = open(os.path.join(APP, d, fn), encoding="utf-8").read()
                    if fn == "ai_call.py":
                        continue  # 이 파일은 --bare 를 막는 코드를 포함한다
                    self.assertNotIn('"--bare"', body, fn)

    def test_N4_원본_원고는_바뀌지_않는다(self):
        import hashlib
        p = os.path.join(G, "sermon_ok.txt")
        before = hashlib.sha256(open(p, "rb").read()).hexdigest()
        checker.run_manuscript(p, out_dir=TMP, store=self.store)
        self.assertEqual(before, hashlib.sha256(open(p, "rb").read()).hexdigest())

    def test_N5_공식_개역한글_대조_기록이_24절_모두_일치(self):
        rows = json.load(open(os.path.join(APP, "data", "official_check_krv.json"), encoding="utf-8"))
        self.assertEqual(len(rows), 24)
        self.assertTrue(all(r["ok"] for r in rows))
        meta = json.load(open(os.path.join(APP, "data", "bible", "gaehan_sample.json"), encoding="utf-8"))
        self.assertTrue(meta["verified_against_official"])
        for r in rows:
            self.assertEqual(meta["verses"][r["k"]].split(), r["official"].split(), r["k"])

    def test_N6_원어_데이터에는_출처와_라이선스가_있다(self):
        d = os.path.join(APP, "data", "original")
        for fn in os.listdir(d):
            if fn.endswith(".json"):
                meta = json.load(open(os.path.join(d, fn), encoding="utf-8"))
                self.assertTrue(meta.get("source") and meta.get("license") and meta.get("fetched"), fn)


class TestTheology(Base):
    def test_H_신학리뷰는_의견이며_서명란이_있고_PASSED와_분리(self):
        text = read(T, "theology_01_숫자상징.txt")
        md = checker.render_theology_review("t", text, self.doctrine, [{"rating": "정통", "quote": "x", "reason": "y"}], "개역한글")
        self.assertIn("의견이며 결론이 아닙니다", md)
        self.assertIn("PASSED 에 포함되지 않습니다", md)
        self.assertIn("- 검토자:", md)
        self.assertRegex(md, r"\|\s*우려\s*\|")
        self.assertIn("판단 필요", md)   # 알 수 없는 표시('정통')는 판단 필요로 낮춘다
        self.assertNotIn("| 정통 |", md)

    def test_H_표현이_없는_원고는_자동_표시가_없다(self):
        md = checker.render_theology_review("t", read(G, "sermon_ok.txt"), self.doctrine, None, "개역한글")
        self.assertNotRegex(md, r"\|\s*우려\s*\|")


if __name__ == "__main__":
    unittest.main()
