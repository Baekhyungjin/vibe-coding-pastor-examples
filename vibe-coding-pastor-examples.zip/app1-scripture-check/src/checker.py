# -*- coding: utf-8 -*-
"""앱 1: 성경 장절 정밀 검증 & 원어 리서치 정리 (표준 라이브러리 + python-docx)

이 앱은 설교를 대신 쓰지 않는다. 설교 준비를 돕는 검증과 리서치 정리 도구다.
  - 설교 원고에서 장절 표기를 찾아 존재 여부를 검사한다(common/validate).
  - 따옴표 인용을 config/bible.json 이 지정한 번역본과 글자 단위로 대조한다(띄어쓰기 포함).
  - 번역본 혼용, 원어 데이터에 없는 단어, 출처 없는 배경 문장을 걸러 낸다.
  - 신학 리뷰는 AI 의견일 뿐이며 PASSED 에 포함하지 않는다.
번역본 이름은 코드에 적지 않는다. config/bible.json 의 name 값만 쓴다(성명표시권).
"""
import datetime
import html
import json
import os
import re
import sys
import unicodedata

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COMMON = os.path.join(APP, "common")
if COMMON not in sys.path:
    sys.path.insert(0, COMMON)

import ai_call  # noqa: E402
import bible_store  # noqa: E402
import refparse  # noqa: E402
import validate as validate_mod  # noqa: E402

AI_LABEL = "AI 정리, 목회자 검토 필요"
NO_SOURCE = "출처 확인 필요"
RATINGS = ("적합", "우려", "판단 필요")
QUOTE_PAIRS = [("\u201c", "\u201d"), ('"', '"'), ("\u300c", "\u300d"), ("\u300e", "\u300f")]
_PUNCT_KEEP_SPACE = re.compile(r"[.,;:!?'\"`\u2018\u2019\u201c\u201d\u00b7\u2026\u300c\u300d\u300e\u300f()\[\]{}<>\uff0c\uff0e\u3001\u3002~]")


# ------------------------------------------------------------------ 입력 읽기
def read_manuscript(path):
    """.txt .md .docx 를 읽어 문자열로 돌려준다. 원본 파일은 수정하지 않는다."""
    ext = os.path.splitext(path)[1].lower()
    if ext == ".docx":
        from docx import Document
        d = Document(path)
        parts = [p.text for p in d.paragraphs]
        for t in d.tables:
            for row in t.rows:
                parts.append(" ".join(c.text for c in row.cells))
        return "\n".join(parts)
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "utf-8", "cp949"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace")


def load_store(app_dir=None):
    app_dir = app_dir or APP
    return bible_store.BibleStore(os.path.join(app_dir, "config", "bible.json"), base_dir=app_dir)


# ------------------------------------------------------------------ 인용 추출
def spaced_norm(text):
    """띄어쓰기는 지키고 문장부호만 지운다. 글자 단위(띄어쓰기 포함) 비교용."""
    t = unicodedata.normalize("NFC", text or "")
    t = _PUNCT_KEEP_SPACE.sub("", t)
    return re.sub(r"\s+", " ", t).strip()


def extract_quotes(text, parser=None, min_len=8):
    """따옴표 안의 글과, 그 글 바로 뒤(또는 앞) 40자 안에 적힌 장절 표기를 짝지어 돌려준다."""
    parser = parser or refparse.Parser()
    out, seen = [], set()
    for lq, rq in QUOTE_PAIRS:
        pat = re.escape(lq) + r"([^" + re.escape(rq) + r"\n]{%d,})" % min_len + re.escape(rq)
        for m in re.finditer(pat, text):
            if m.start() in seen:
                continue
            seen.add(m.start())
            after = text[m.end(): m.end() + 40]
            before = text[max(0, m.start() - 40): m.start()]
            ref = None
            ma = re.match(r"\s*[\(\[\uff08]([^\)\]\uff09\n]+)[\)\]\uff09]", after)
            cand = parser.parse(ma.group(1)) if ma else []
            if cand:
                ref = cand[0].raw
            if ref is None:
                bs = parser.parse(before)
                if bs:
                    ref = bs[-1].raw
            if ref is not None:
                out.append({"quote": m.group(1).strip(), "ref": ref, "pos": m.start()})
    out.sort(key=lambda x: x["pos"])
    return out


# ------------------------------------------------------------------ 인용 검사
def _check_one(store, quote, ref_text):
    checks = validate_mod.validate_text(ref_text, store.parser)
    if not checks:
        return {"status": "FAIL", "code": "NO_REF", "ref": ref_text, "message": "장절을 읽지 못했습니다"}
    bad = [c for c in checks if not c.ok]
    if bad:
        return {"status": "FAIL", "code": "REF_NOT_EXIST:" + bad[0].code, "ref": ref_text, "message": bad[0].message}
    cmp = store.compare(quote, ref_text)
    if cmp is None:
        return {"status": "FAIL", "code": "NOT_IN_STORE", "ref": ref_text,
                "message": "이 번역본 데이터에 해당 절이 없어 대조할 수 없습니다. data/bible/ 에 번역본 파일을 넣으세요"}
    if cmp.normalized:
        if spaced_norm(quote) == spaced_norm(cmp.expected):
            return {"status": "PASS", "code": "OK", "ref": ref_text, "translation": cmp.translation.name}
        return {"status": "FAIL", "code": "SPACING_DIFF", "ref": ref_text,
                "message": "글자는 같으나 띄어쓰기가 다릅니다(번역본 본문은 띄어쓰기까지 그대로 인용해야 합니다)",
                "expected": cmp.expected, "quote": quote}
    mixed = store.detect_mix(quote, ref_text)
    if mixed:
        return {"status": "FAIL", "code": "MIXED_TRANSLATION", "ref": ref_text,
                "message": "지정한 번역본(%s)이 아니라 %s 의 문장입니다" % (store.active.name, store.translations[mixed].name),
                "expected": cmp.expected, "quote": quote}
    return {"status": "FAIL", "code": "MISMATCH", "ref": ref_text, "diffs": cmp.diffs[:6],
            "message": "지정한 번역본(%s)과 글자가 다릅니다" % store.active.name,
            "expected": cmp.expected, "quote": quote}


def check_manuscript(text, store):
    """설교 원고 하나를 검사해 보고 dict 를 돌려준다. 신학 판단은 하지 않는다."""
    parser = store.parser
    refs = parser.parse(text)
    ref_results = []
    for r in refs:
        c = validate_mod.validate_ref(r, parser.canon)
        ref_results.append({"ref": r.raw, "ok": c.ok, "code": c.code, "message": c.message, "warnings": list(c.warnings)})
    quotes = extract_quotes(text, parser)
    quote_results = []
    for q in quotes:
        res = _check_one(store, q["quote"], q["ref"])
        res["quote"] = q["quote"]
        quote_results.append(res)
    warnings = []
    if quote_results and store.active.name not in text:
        warnings.append({"code": "NO_TRANSLATION_LABEL",
                         "message": "원고에 번역본 이름(%s) 표기가 없습니다. 인용에는 번역본 이름을 적으세요" % store.active.name})
    fails = [x["code"] for x in ref_results if not x["ok"]] + [x["code"] for x in quote_results if x["status"] == "FAIL"]
    return {
        "translation": store.active.name,
        "refs": ref_results,
        "quotes": quote_results,
        "warnings": warnings,
        "fail_codes": fails,
        "status": "FAIL" if fails else "PASS",
        "checked_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
    }


# ------------------------------------------------------------------ 보고서 출력
def _diff_text(diffs):
    return "; ".join("%s: 기대 '%s' / 원고 '%s'" % (op, a, b) for op, a, b, _ in diffs)


def render_check_md(report, name):
    t = report["translation"]
    L = ["# 인용 검사: %s" % name, "", "- 지정 번역본: **%s**" % t,
         "- 검사 시각: %s" % report["checked_at"],
         "- 결과: **%s**" % report["status"],
         "- 이 검사는 장절 존재, 본문 글자, 번역본 일치만 기계로 확인합니다. 해석과 적용은 목회자가 판단합니다.", ""]
    L += ["## 장절 존재 검사", "", "| 표기 | 결과 | 설명 |", "| --- | --- | --- |"]
    for r in report["refs"]:
        extra = (" (경고: %s)" % ", ".join(r["warnings"])) if r["warnings"] else ""
        L.append("| %s | %s | %s%s |" % (r["ref"], "있음" if r["ok"] else "없음: " + r["code"], r["message"], extra))
    if not report["refs"]:
        L.append("| (장절 표기를 찾지 못함) | - | - |")
    L += ["", "## 인용 본문 대조 (%s)" % t, ""]
    for q in report["quotes"]:
        L.append("- %s %s: %s" % (q["ref"], "통과" if q["status"] == "PASS" else "불합격(%s)" % q["code"], q.get("message", "일치")))
        if q["status"] == "FAIL" and q.get("diffs"):
            L.append("  - 차이: " + _diff_text(q["diffs"]))
        if q["status"] == "FAIL" and q.get("expected"):
            L.append("  - %s 본문: %s" % (t, q["expected"]))
            L.append("  - 원고 인용: %s" % q["quote"])
    if not report["quotes"]:
        L.append("- (따옴표 인용을 찾지 못함)")
    for w in report["warnings"]:
        L += ["", "> 경고(%s): %s" % (w["code"], w["message"])]
    return "\n".join(L) + "\n"


def render_check_html(report, name):
    e = html.escape
    t = report["translation"]
    rows = "".join("<tr><td>%s</td><td class='%s'>%s</td><td>%s</td></tr>" % (
        e(r["ref"]), "ok" if r["ok"] else "bad", "있음" if r["ok"] else "없음 " + e(r["code"]), e(r["message"])) for r in report["refs"])
    qs = ""
    for q in report["quotes"]:
        cls = "ok" if q["status"] == "PASS" else "bad"
        body = e(q.get("message", "일치"))
        if q["status"] == "FAIL" and q.get("expected"):
            body += "<div class='cmp'><b>%s 본문</b> %s<br><b>원고 인용</b> %s</div>" % (e(t), e(q["expected"]), e(q["quote"]))
        qs += "<li class='%s'><b>%s</b> %s %s</li>" % (cls, e(q["ref"]), "통과" if q["status"] == "PASS" else "불합격 " + e(q["code"]), body)
    return ("<!doctype html><html lang='ko'><head><meta charset='utf-8'><title>인용 검사 %s</title><style>"
            "body{font-family:'Malgun Gothic',sans-serif;max-width:46em;margin:1.5em auto;padding:0 1em;line-height:1.6}"
            "table{border-collapse:collapse;width:100%%}td,th{border:1px solid #bbb;padding:.3em .5em}"
            ".ok{color:#1b6b2f}.bad{color:#b3261b;font-weight:700}.cmp{background:#f4f4f4;padding:.4em .6em;margin:.3em 0}"
            ".note{background:#fff7d6;padding:.5em .8em}</style></head><body>"
            "<h1>인용 검사: %s</h1><p>지정 번역본: <b>%s</b> / 결과: <b>%s</b></p>"
            "<p class='note'>이 화면은 장절 존재, 본문 글자, 번역본 일치만 기계로 확인합니다. 해석과 적용은 목회자가 판단합니다. "
            "이 파일은 내 PC에서만 보세요. 성경 본문이 들어 있으므로 인터넷에 올리지 마세요.</p>"
            "<h2>장절 존재 검사</h2><table><tr><th>표기</th><th>결과</th><th>설명</th></tr>%s</table>"
            "<h2>인용 본문 대조</h2><ul>%s</ul></body></html>") % (e(name), e(name), e(t), e(report["status"]), rows, qs)


# ------------------------------------------------------------------ 원어 데이터와 리서치
def load_originals(app_dir=None):
    """data/original/*.json 중 'verses' 를 가진 파일을 모은다. 키는 '요 3:16' 꼴."""
    app_dir = app_dir or APP
    d = os.path.join(app_dir, "data", "original")
    out = {}
    if not os.path.isdir(d):
        return out
    for fn in sorted(os.listdir(d)):
        if not fn.endswith(".json"):
            continue
        with open(os.path.join(d, fn), encoding="utf-8") as f:
            data = json.load(f)
        for k, words in data.get("verses", {}).items():
            out[k] = {"words": words, "source": data.get("source", ""), "license": data.get("license", ""), "language": data.get("language", "")}
    return out


def _fold(s):
    s = unicodedata.normalize("NFD", s or "")
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    return unicodedata.normalize("NFC", s).lower().replace("ς", "σ")


def original_forms(entry):
    forms = set()
    for w in entry["words"]:
        for k in ("word", "lemma", "translit"):
            if w.get(k):
                forms.add(_fold(re.sub(r"\(.*?\)", "", w[k])))
    return forms


def allowed_sources(doctrine_text):
    """doctrine.md 의 '5.' 절 목록에서 허용 자료 이름을 읽는다. 괄호 설명은 뗀다."""
    m = re.search(r"^##\s*5\..*?$([\s\S]*?)(?=^##\s|\Z)", doctrine_text or "", re.M)
    names = []
    if m:
        for line in m.group(1).splitlines():
            line = line.strip()
            if line.startswith("- "):
                names.append(re.sub(r"\s*\(.*?\)\s*", "", line[2:]).strip())
    return [n for n in names if n]


AI_SCHEMA = {"required": {"original_notes": list, "background": list}}


def check_ai_response(resp, ref_key, originals, allowed):
    """AI 초안(dict)을 검사해 이슈 목록을 돌려준다. 이슈 코드:
    WORD_NOT_IN_DATA(원어 데이터에 없는 단어 설명), NO_SOURCE(출처 없음), SOURCE_NOT_ALLOWED(허용 자료 밖), BAD_ITEM"""
    issues = []
    entry = originals.get(ref_key)
    forms = original_forms(entry) if entry else set()
    for n in resp.get("original_notes", []):
        if not isinstance(n, dict) or not n.get("word") or not n.get("note"):
            issues.append({"code": "BAD_ITEM", "where": "original_notes", "item": n})
            continue
        if not entry or _fold(re.sub(r"\(.*?\)", "", n["word"])) not in forms:
            issues.append({"code": "WORD_NOT_IN_DATA", "word": n["word"], "ref": ref_key})
    for b in resp.get("background", []):
        if not isinstance(b, dict) or not b.get("text"):
            issues.append({"code": "BAD_ITEM", "where": "background", "item": b})
            continue
        src = (b.get("source") or "").strip()
        if not src:
            issues.append({"code": "NO_SOURCE", "text": b["text"]})
        elif allowed and not any(a in src for a in allowed):
            issues.append({"code": "SOURCE_NOT_ALLOWED", "text": b["text"], "source": src})
    return issues


def build_prompt(ref_key, entry):
    words = ", ".join(w.get("word", "") for w in (entry["words"] if entry else []))
    return ("다음 장절의 원어 단어 설명과 역사 배경을 JSON 으로만 답하라. 설교문을 쓰지 말고 리서치만 하라.\n"
            "장절: %s\n원어 데이터에 있는 단어: %s\n"
            "형식: {\"original_notes\":[{\"word\":\"원어 단어\",\"note\":\"설명\"}],"
            "\"background\":[{\"text\":\"문장\",\"source\":\"자료명\"}]}\n"
            "원어 설명은 위 단어에 대해서만, 배경 문장은 반드시 자료명을 붙여라.") % (ref_key, words)


def research(ref_text, store, originals, doctrine_text="", backend=None):
    """장절 하나의 리서치 정리를 만든다. backend 가 없으면 AI 를 부르지 않는다.
    AI 호출에는 장절 표기와 원어 단어만 들어가며 원고나 교인 정보는 들어가지 않는다."""
    refs = store.parser.parse(ref_text)
    if not refs:
        return {"ok": False, "code": "NO_REF", "message": "장절을 읽지 못했습니다", "ref": ref_text}
    r = refs[0]
    chk = validate_mod.validate_ref(r, store.parser.canon)
    if not chk.ok:
        return {"ok": False, "code": "REF_NOT_EXIST:" + chk.code, "message": chk.message, "ref": ref_text}
    key = "%s %d:%d" % (r.book.abbr, r.c1, r.v1) if r.v1 is not None and r.c1 == r.c2 and r.v1 == r.v2 else None
    verse_text = store.text_of(ref_text)
    entry = originals.get(key) if key else None
    out = {"ok": True, "ref": ref_text, "key": key, "translation": store.active.name, "verse_text": verse_text,
           "original": entry, "ai": None, "issues": [], "background": [], "notes": []}
    if backend is not None:
        if not key:
            out["issues"].append({"code": "RANGE_NOT_SUPPORTED", "message": "원어 정리는 한 절씩 합니다"})
            return out
        resp = ai_call.call_ai(build_prompt(key, entry), backend, schema=AI_SCHEMA, roster=[])
        allowed = allowed_sources(doctrine_text)
        issues = check_ai_response(resp, key, originals, allowed)
        out["issues"] = issues
        bad_words = {i.get("word") for i in issues if i["code"] == "WORD_NOT_IN_DATA"}
        for n in resp.get("original_notes", []):
            if isinstance(n, dict) and n.get("word") and n["word"] not in bad_words and n.get("note"):
                out["notes"].append(n)
        for b in resp.get("background", []):
            if isinstance(b, dict) and b.get("text"):
                src = (b.get("source") or "").strip()
                good = bool(src) and (not allowed or any(a in src for a in allowed))
                out["background"].append({"text": b["text"], "source": src if good else "", "raw_source": src})
        out["ai"] = True
    return out


def render_research_md(res):
    t = res["translation"]
    L = ["# 리서치 정리: %s" % res["ref"], "", "- 번역본: **%s**" % t,
         "- 이 문서의 AI 문단은 모두 \"%s\" 상태입니다. 설교문이 아니며 설교 작성은 목회자의 몫입니다." % AI_LABEL, ""]
    L += ["## 본문 (%s)" % t, ""]
    L.append(res["verse_text"] if res["verse_text"] else "이 번역본 데이터에 해당 절이 없습니다. data/bible/ 에 번역본 파일을 넣으세요.")
    L += ["", "## 원어 (공개 데이터, 데이터 그대로)", ""]
    ent = res.get("original")
    if ent:
        L += ["출처: %s / 라이선스: %s" % (ent["source"], ent["license"]), "", "| 원어 | 기본형 | 형태 정보 |", "| --- | --- | --- |"]
        for w in ent["words"]:
            L.append("| %s | %s | %s |" % (w.get("word", ""), w.get("lemma", ""), w.get("morph", w.get("parse", ""))))
    else:
        L.append("이 절의 원어 데이터가 없습니다. data/original/ 에 라이선스를 확인한 데이터를 넣으세요.")
    if res.get("ai"):
        L += ["", "## 원어 단어 설명 (%s)" % AI_LABEL, ""]
        for n in res["notes"]:
            L.append("- %s: %s" % (n["word"], n["note"]))
        if not res["notes"]:
            L.append("- (원어 데이터에 있는 단어에 대한 설명이 없습니다)")
        L += ["", "## 역사 배경 (%s)" % AI_LABEL, ""]
        for b in res["background"]:
            L.append("- %s [출처: %s]" % (b["text"], b["source"]) if b["source"] else "- %s [%s]" % (b["text"], NO_SOURCE))
        if not res["background"]:
            L.append("- (배경 설명 없음)")
        flagged = [i for i in res["issues"] if i["code"] == "WORD_NOT_IN_DATA"]
        if flagged:
            L += ["", "## 걸러 낸 항목", ""]
            for i in flagged:
                L.append("- 원어 데이터에 없는 단어라 설명을 뺐습니다: %s" % i["word"])
    return "\n".join(L) + "\n"


def lint_research_md(md, translation_name):
    """리서치 문서 점검: 번역본명, AI 문단 라벨, 배경 문장의 출처 태그. 이슈 코드 목록을 돌려준다."""
    issues = []
    if translation_name not in md:
        issues.append("NO_TRANSLATION_NAME")
    for m in re.finditer(r"^## .*?\((.*?)\)\s*$", md, re.M):
        pass
    sections = re.split(r"^## ", md, flags=re.M)[1:]
    for s in sections:
        head = s.splitlines()[0]
        if "원어 단어 설명" in head or "역사 배경" in head:
            if AI_LABEL not in head:
                issues.append("NO_AI_LABEL:" + head)
        if "역사 배경" in head:
            for line in s.splitlines()[1:]:
                if line.startswith("- ") and "(배경 설명 없음)" not in line and "[출처:" not in line and ("[%s]" % NO_SOURCE) not in line:
                    issues.append("NO_SOURCE_TAG:" + line[:30])
    return issues


# ------------------------------------------------------------------ 신학 리뷰 (AI 의견, PASSED 에 포함하지 않음)
def avoid_terms(doctrine_text):
    """doctrine.md 4번 절의 목록을 읽는다. 기계가 찾는 것은 '| 표현: a, b' 로 적힌 글자뿐이다.
    표현이 없는 항목은 기계가 판단하지 않고 목회자 판단에 남긴다. 반환: [(설명, [표현...])]"""
    m = re.search(r"^##\s*4\..*?$([\s\S]*?)(?=^##\s|\Z)", doctrine_text or "", re.M)
    out = []
    for line in (m.group(1).splitlines() if m else []):
        line = line.strip()
        if not line.startswith("- "):
            continue
        body = line[2:]
        desc, _, words = body.partition("| 표현:")
        out.append((desc.strip(), [w.strip() for w in words.split(",") if w.strip()]))
    return out

def render_theology_review(subject, text, doctrine_text, ai_items=None, translation=""):
    """doctrine.md 체크리스트로 리뷰 문서를 만든다. 표시는 적합/우려/판단 필요 셋뿐이며 AI 의견이다.
    기계가 확인하는 것은 '피해야 할 표현' 목록의 글자가 원고에 있는지뿐이다."""
    rows = []
    n = 0
    for desc, words in avoid_terms(doctrine_text):
        for w in words:
            if w in (text or ""):
                n += 1
                rows.append((n, "우려", w, "doctrine.md 4번 '피해야 할 해석과 표현'(%s)에 적힌 표현이 원고에 있습니다" % desc))
                break
    for it in ai_items or []:
        n += 1
        rating = it.get("rating") if it.get("rating") in RATINGS else "판단 필요"
        rows.append((n, rating, str(it.get("quote", ""))[:80], str(it.get("reason", ""))[:120]))
    if not rows:
        rows.append((1, "판단 필요", "(없음)", "자동으로 표시할 항목이 없습니다. 해석과 적용은 목회자가 직접 판단합니다"))
    L = ["# 신학 리뷰 (theology_review.md)", "", "- 대상 결과물: %s" % subject,
         "- 기준 문서: doctrine.md", "- 지정 번역본: %s" % translation,
         "- 리뷰 담당: AI (**의견이며 결론이 아닙니다.** 이 문서는 verify_report.json 의 PASSED 에 포함되지 않습니다)", "",
         "## 항목별 표시", "표시는 \"적합\", \"우려\", \"판단 필요\" 셋 중 하나입니다.", "",
         "| 번호 | 표시 | 근거 문장(그대로 인용) | 이유 한 줄 |", "| --- | --- | --- | --- |"]
    for r in rows:
        L.append("| %d | %s | %s | %s |" % (r[0], r[1], r[2].replace("|", "/"), r[3].replace("|", "/")))
    L += ["", "## 목회자 서명란", "- 검토자:", "- 검토 일자:", "- 결정: (사용 / 수정 후 사용 / 사용 안 함)", "- 메모:", ""]
    return "\n".join(L)


# ------------------------------------------------------------------ 한 번에 실행
def run_manuscript(path, out_dir=None, store=None, doctrine_path=None, ai_items=None, app_dir=None):
    app_dir = app_dir or APP
    store = store or load_store(app_dir)
    out_dir = out_dir or os.path.join(app_dir, "output")
    os.makedirs(out_dir, exist_ok=True)
    text = read_manuscript(path)
    name = os.path.splitext(os.path.basename(path))[0]
    report = check_manuscript(text, store)
    with open(os.path.join(out_dir, "인용검사_%s.md" % name), "w", encoding="utf-8") as f:
        f.write(render_check_md(report, name))
    with open(os.path.join(out_dir, "인용검사_%s.html" % name), "w", encoding="utf-8") as f:
        f.write(render_check_html(report, name))
    doctrine_text = ""
    dp = doctrine_path or os.path.join(app_dir, "doctrine.md")
    if os.path.exists(dp):
        doctrine_text = open(dp, encoding="utf-8").read()
    with open(os.path.join(out_dir, "theology_review.md"), "w", encoding="utf-8") as f:
        f.write(render_theology_review(name, text, doctrine_text, ai_items, store.active.name))
    return report
