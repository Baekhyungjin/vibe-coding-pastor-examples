# -*- coding: utf-8 -*-
"""선택 사항: Streamlit 화면. 실행하려면 `pip install streamlit` 후 `streamlit run src/app_streamlit.py`.
개발 PC에서는 Streamlit 을 설치할 수 없어 실행을 확인하지 못했다(구문 검사만 함). 기본 화면은 정적 HTML 이다."""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import checker  # noqa: E402

try:
    import streamlit as st
except ImportError:  # pragma: no cover
    raise SystemExit("streamlit 이 설치돼 있지 않습니다. 기본 화면은 python scripts/run.py 로 만든 HTML 입니다.")

store = checker.load_store()
st.title("성경 장절 정밀 검증 (로컬 전용)")
st.caption("지정 번역본: %s. 이 화면의 결과를 인터넷에 올리지 마세요." % store.active.name)
up = st.file_uploader("설교 원고 (.txt, .docx)", type=["txt", "docx"])
if up is not None:
    suffix = os.path.splitext(up.name)[1]
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix, dir=os.path.join(checker.APP, "output")) as f:
        f.write(up.getvalue())
        path = f.name
    rep = checker.check_manuscript(checker.read_manuscript(path), store)
    os.unlink(path)
    st.subheader("결과: %s" % rep["status"])
    st.markdown(checker.render_check_md(rep, up.name))