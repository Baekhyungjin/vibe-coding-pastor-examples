"""사람이 테스트 목록을 승인한 순간 실행하는 '봉인' 명령.

사용법:
    python scripts/lock.py "홍길동"      # 승인자 이름과 함께 봉인
    python scripts/lock.py --check       # 봉인이 그대로인지 확인만

규칙: 이 명령은 사람이 직접 실행한다. AI는 실행하지 않는다(CLAUDE.md).
"""
import datetime
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from lockutil import LOCK_NAME, compare, fingerprint  # noqa: E402


def main():
    if "--check" in sys.argv:
        state, problems = compare(ROOT)
        if state == "OK":
            print("봉인 확인: 이상 없음")
            return 0
        print("봉인 확인: 문제 있음")
        for p in problems:
            print("  - " + p)
        return 1

    approver = sys.argv[1] if len(sys.argv) > 1 else "(이름 미기재)"
    files = fingerprint(ROOT)
    data = {
        "approved_by": approver,
        "approved_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "files": files,
    }
    (ROOT / LOCK_NAME).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"봉인 완료: 파일 {len(files)}개, 승인자 {approver}")
    for path in files:
        print("  " + path)
    return 0


if __name__ == "__main__":
    sys.exit(main())
