"""신학 리뷰 문서의 서명 상태를 알려 주는 작은 도구. (Ch 5)

output/theology_review.md 를 읽어
  - 문서가 있는지
  - 항목 표시(적합/우려/판단 필요)가 몇 개인지
  - 서명란(검토자, 검토 일자, 결정)이 모두 채워졌는지
를 보고한다. 이 도구는 신학 내용을 판정하지 않는다. 서명이 됐는지만 본다.

종료 코드: 서명 완료 0, 문서 없음 또는 서명 미완료 3 (verify.py 의 PASSED 와는 별개다)
"""
import re
import sys
from pathlib import Path

sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(__file__).resolve().parent.parent
DOC = ROOT / "output" / "theology_review.md"
FIELDS = ("검토자", "검토 일자", "결정")


def read_field(text, name):
    m = re.search(r"^- " + re.escape(name) + r":[ \t]*(.*)$", text, re.M)
    return m.group(1).strip() if m else ""


def status(text):
    marks = {k: len(re.findall(r"\|\s*" + k + r"\s*\|", text)) for k in ("적합", "우려", "판단 필요")}
    filled = {f: read_field(text, f) for f in FIELDS}
    # 결정 칸의 안내 문구(괄호 선택지)는 채운 것으로 보지 않는다
    if filled["결정"].startswith("("):
        filled["결정"] = ""
    return marks, filled


def main():
    if not DOC.exists():
        print("신학 리뷰: output/theology_review.md 가 아직 없습니다.")
        return 3
    marks, filled = status(DOC.read_text(encoding="utf-8"))
    print("신학 리뷰 표시: " + ", ".join(f"{k} {v}개" for k, v in marks.items()))
    missing = [f for f, v in filled.items() if not v]
    for f, v in filled.items():
        print(f"  {f}: {v if v else '(비어 있음)'}")
    if missing:
        print("서명 미완료: 목회자가 " + ", ".join(missing) + " 칸을 채워야 사용할 수 있습니다.")
        return 3
    print("서명 완료")
    return 0


if __name__ == "__main__":
    sys.exit(main())
