# -*- coding: utf-8 -*-
"""앱 1 실행: 설교 원고 인용 검사, 장절 리서치 정리.

  python scripts/run.py --manuscript samples/golden/sermon_ok.txt
  python scripts/run.py --ref "요 3:16"                       (AI 없이 본문과 원어 데이터만)
  python scripts/run.py --ref "요 3:16" --ai mock:samples/golden/ai_ok.json   (가짜 AI 응답으로 시험)
  python scripts/run.py --ref "요 3:16" --ai claude            (내 PC 의 claude -p 사용, 구독 로그인 필요)

결과는 output/ 에 만든다: 인용검사_원고명.md, 인용검사_원고명.html, theology_review.md, 리서치_본문.md
이 앱은 내 PC 에서만 쓴다. 성경 본문이 들어 있는 결과 파일을 인터넷에 올리지 않는다."""
import argparse
import os
import sys

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(APP, "src"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import checker  # noqa: E402
import ai_call  # noqa: E402


def make_backend(spec):
    if not spec or spec == "none":
        return None
    if spec.startswith("mock:"):
        text = open(os.path.join(APP, spec[5:]) if not os.path.isabs(spec[5:]) else spec[5:], encoding="utf-8").read()
        return ai_call.MockAI(lambda _p: text)
    if spec in ("claude", "codex"):
        return ai_call.cli_backend(spec)
    raise SystemExit("--ai 는 none, mock:경로, claude, codex 중 하나입니다")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--manuscript")
    ap.add_argument("--ref")
    ap.add_argument("--ai", default="none")
    ap.add_argument("--out", default=os.path.join(APP, "output"))
    a = ap.parse_args()
    if not a.manuscript and not a.ref:
        ap.error("--manuscript 또는 --ref 가 필요합니다")
    store = checker.load_store()
    os.makedirs(a.out, exist_ok=True)
    code = 0
    if a.manuscript:
        rep = checker.run_manuscript(a.manuscript, out_dir=a.out, store=store)
        print("인용 검사: %s (번역본 %s)" % (rep["status"], rep["translation"]))
        for q in rep["quotes"]:
            print("  %s %s %s" % (q["ref"], q["status"], q.get("message", "")))
        for r in rep["refs"]:
            if not r["ok"]:
                print("  장절 오류 %s: %s" % (r["ref"], r["message"]))
        for w in rep["warnings"]:
            print("  경고 %s: %s" % (w["code"], w["message"]))
        print("신학 리뷰는 AI 의견입니다: output/theology_review.md (서명 필요)")
        code = 0 if rep["status"] == "PASS" else 1
    if a.ref:
        doctrine = open(os.path.join(APP, "doctrine.md"), encoding="utf-8").read() if os.path.exists(os.path.join(APP, "doctrine.md")) else ""
        res = checker.research(a.ref, store, checker.load_originals(), doctrine, make_backend(a.ai))
        if not res.get("ok"):
            print("리서치 불가: %s" % res["message"])
            return 1
        md = checker.render_research_md(res)
        problems = checker.lint_research_md(md, store.active.name)
        with open(os.path.join(a.out, "리서치_본문.md"), "w", encoding="utf-8") as f:
            f.write(md)
        print("리서치 정리: output/리서치_본문.md (걸러 낸 항목 %d건, 점검 %s)" % (len(res["issues"]), problems or "이상 없음"))
        for i in res["issues"]:
            print("  %s %s" % (i["code"], i.get("word") or i.get("text", "")[:30]))
    return code


if __name__ == "__main__":
    sys.exit(main())
