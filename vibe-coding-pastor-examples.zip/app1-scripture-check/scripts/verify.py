# -*- coding: utf-8 -*-
"""하네스 진입점: python scripts/verify.py [--quiet]
마지막 줄 RESULT: PASSED (n/n) 또는 FAILED (k/n). 리포트는 output/verify_report.json.
종료 코드: 통과 0, 실패 2. 신학 리뷰(output/theology_review.md)는 이 결과에 포함되지 않는다."""
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "common"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

import verify_core  # noqa: E402

if __name__ == "__main__":
    sys.exit(verify_core.run_harness(ROOT, quiet="--quiet" in sys.argv))
