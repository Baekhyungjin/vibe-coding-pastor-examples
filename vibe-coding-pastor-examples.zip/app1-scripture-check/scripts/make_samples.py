# -*- coding: utf-8 -*-
"""가짜 샘플 생성기 (표준 라이브러리 + python-docx). 번역본 본문은 data/bible/ 의 파일에서 읽는다.
실행: python scripts/make_samples.py   -> samples/golden, samples/trap 을 다시 만든다.
설교 원고 샘플은 모두 연습용으로 지어낸 것이며 실제 설교가 아니다."""
import json
import os
import sys

APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(APP, "src"))
sys.dont_write_bytecode = True
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

import checker  # noqa: E402

G = os.path.join(APP, "samples", "golden")
T = os.path.join(APP, "samples", "trap")


def w(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def main():
    os.makedirs(G, exist_ok=True)
    os.makedirs(T, exist_ok=True)
    store = checker.load_store()
    gh, fb = store.translations["gaehan"], store.translations["fakeB"]
    v16 = gh.get("요 3:16")
    ps1 = gh.get("시 23:1")
    ph = gh.get("빌 4:6") + " " + gh.get("빌 4:7")
    name = gh.name
    head = "연습용 가짜 설교 개요 (실제 설교가 아님)\n오전 11:00 예배, 2026.10.18 주일.\n"
    ok = (head + "본문은 요한복음 3장 16절입니다. \u201c%s\u201d(요 3:16 %s)\n" % (v16, name)
          + "시편 23편 1절도 함께 읽습니다. \u201c%s\u201d(시 23:1 %s)\n" % (ps1, name)
          + "염려를 맡기는 말씀입니다. \u201c%s\u201d(빌 4:6-7 %s)\n" % (ph, name)
          + "인용 없이 장절만 적는 곳: 롬 8:28, 31을 참고하고 요일 1:9도 봅니다.\n")
    w(os.path.join(G, "sermon_ok.txt"), ok)
    try:
        from docx import Document
        d = Document()
        for line in ok.splitlines():
            d.add_paragraph(line)
        t = d.add_table(rows=1, cols=2)
        t.rows[0].cells[0].text = "참고"
        t.rows[0].cells[1].text = "고전 13:4-7"
        d.save(os.path.join(G, "sermon_ok.docx"))
    except ImportError:
        pass
    ai_ok = {"original_notes": [{"word": "\u1f20\u03b3\u03ac\u03c0\u03b7\u03c3\u03b5\u03bd",
                                 "note": "데이터에 기본형은 \u1f00\u03b3\u03b1\u03c0\u03ac\u03c9, 형태는 V- 3AAI-S-- (동사, 3인칭 부정과거 능동 직설 단수)로 적혀 있습니다. 뜻풀이는 목회자가 사전으로 확인합니다."}],
             "background": [{"text": "요한복음 3장은 니고데모가 밤에 예수께 오는 장면으로 시작합니다.", "source": "개역한글 성경 본문(요 3:1-2)"},
                            {"text": "이 대화는 예시 주석 1 이 다루는 본문 중 하나입니다.", "source": "예시 주석 1"}]}
    w(os.path.join(G, "ai_ok.json"), json.dumps(ai_ok, ensure_ascii=False, indent=1))

    traps = {
        "trap_01_없는절.txt": ("연습용 가짜 설교 개요\n유 1:30을 읽겠습니다.\n", ["VERSE_OUT_OF_RANGE"]),
        "trap_02_없는편.txt": ("연습용 가짜 설교 개요\n시 151:1을 읽겠습니다.\n", ["CHAPTER_OUT_OF_RANGE"]),
        "trap_03_한글자.txt": ("연습용 가짜 설교 개요\n\u201c%s\u201d(요 3:16 %s)\n" % (v16.replace("멸망치", "멸망지"), name), ["MISMATCH"]),
        "trap_04_띄어쓰기.txt": ("연습용 가짜 설교 개요\n\u201c%s\u201d(요 3:16 %s)\n" % (v16.replace("세상을 이처럼", "세상을이처럼").replace("독생자를 주셨으니", "독생자를주셨으니"), name), ["SPACING_DIFF"]),
        "trap_05_번역본혼용.txt": ("연습용 가짜 설교 개요\n\u201c%s\u201d(요 3:16 %s)\n" % (fb.get("요 3:16"), name), ["MIXED_TRANSLATION"]),
        "trap_06_역순.txt": ("연습용 가짜 설교 개요\n요 3:18-16을 읽겠습니다.\n", ["RANGE_REVERSED"]),
        "trap_07_모호약어.txt": ("연습용 가짜 설교 개요\n삼 3:1을 읽겠습니다.\n", ["AMBIGUOUS_BOOK"]),
    }
    expected = {}
    for fn, (text, codes) in traps.items():
        w(os.path.join(T, fn), text)
        expected[fn] = codes
    ai_traps = {
        "ai_01_원어없음.json": ({"original_notes": [{"word": "\u1f00\u03b3\u03ac\u03c0\u03b7", "note": "사랑이라는 명사"}], "background": []}, ["WORD_NOT_IN_DATA"]),
        "ai_02_출처없음.json": ({"original_notes": [], "background": [{"text": "당시 유대 사회에서 밤에 찾아오는 것은 드문 일이었습니다.", "source": ""}]}, ["NO_SOURCE"]),
        "ai_03_출처허용밖.json": ({"original_notes": [], "background": [{"text": "니고데모는 산헤드린 의원이었습니다.", "source": "유명한 블로그 글"}]}, ["SOURCE_NOT_ALLOWED"]),
    }
    for fn, (obj, codes) in ai_traps.items():
        w(os.path.join(T, fn), json.dumps(obj, ensure_ascii=False, indent=1))
        expected[fn] = codes
    w(os.path.join(T, "ai_04_자유문장.txt"), "네, 요한복음 3장 16절은 정말 은혜로운 말씀입니다. 사랑에 대해 이렇게 설교해 보세요: ...")
    expected["ai_04_자유문장.txt"] = ["BAD_SCHEMA"]
    w(os.path.join(T, "theology_01_숫자상징.txt"), "연습용 가짜 설교 개요\n7은 완전수이므로 이 본문은 완전한 구원을 뜻한다고 말합니다. (요 3:16)\n")
    expected["theology_01_숫자상징.txt"] = ["우려"]
    w(os.path.join(T, "expected.json"), json.dumps(expected, ensure_ascii=False, indent=1))
    print("샘플 생성 완료:", len(os.listdir(G)), "골든,", len(os.listdir(T)), "함정(expected.json 포함)")


if __name__ == "__main__":
    main()
