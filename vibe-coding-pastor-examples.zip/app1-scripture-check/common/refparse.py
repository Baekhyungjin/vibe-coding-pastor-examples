"""성경 장절 표기 파서 (표준 라이브러리만)

지원하는 표기 예
  요 3:16 / 요3:16-18 / 요한복음 3장 16절 / 롬 8:28, 31 / 창 1:1-2:3 / 시 23편
  빌 4:4~7 / 요일 1:9 / 삼상 17:45 / 유 5절 / 롬 8:28; 12:1 / 요 3:16; 롬 5:8

원칙
  - 책 이름은 반드시 숫자가 뒤따라야 한다(숫자 없는 "요한"은 장절이 아니다).
  - 한 글자 약어(요, 시, 창, 전 ...)는 "3:16" 또는 "3장/3편" 꼴일 때만 장절로 본다.
  - "오전 11:00", "2026.10.18", "10:30:15" 같은 시간/날짜는 장절로 읽지 않는다.
  - "삼, 왕, 대, 고, 살, 딤, 벧" 처럼 상/하(전/후)를 알 수 없는 약어는 AMBIGUOUS 로 돌려준다.
  - 성경 장절이 실제로 있는지는 validate.py 가 따로 확인한다.
"""
import json
import os
import re
from dataclasses import dataclass, field

import canon as canon_mod

_HERE = os.path.dirname(os.path.abspath(__file__))
_DASH = "-~\u2013\u2014\u223c\u301c"          # - ~ en dash, em dash, tilde operator, wave dash
_N = r"(\d{1,3})(?!\d)"

_RE_NUM = re.compile(r"\s*" + _N)
_RE_COLON = re.compile(r"\s*[:\uff1a]\s*" + _N)
_RE_CHAPTER_WORD = re.compile(r"\s*(장|편)")
_RE_VERSE_WORD = re.compile(r"\s*" + _N + r"(?:\s*[" + _DASH + r"]\s*" + _N + r")?\s*절")
_RE_RANGE = re.compile(r"\s*[" + _DASH + r"]\s*" + _N)
_RE_VERSE_SUFFIX = re.compile(r"\s*절")
_RE_LIST = re.compile(r"\s*([,;\uff0c\uff1b])\s*" + _N)
_RE_CLOCK = re.compile(r"\d{1,2}:\d{2}:\d{2}")

AMBIGUOUS = {
    "삼": ["사무엘상", "사무엘하"], "왕": ["열왕기상", "열왕기하"], "대": ["역대상", "역대하"],
    "고": ["고린도전서", "고린도후서"], "살": ["데살로니가전서", "데살로니가후서"],
    "딤": ["디모데전서", "디모데후서"], "벧": ["베드로전서", "베드로후서"],
}


@dataclass
class Ref:
    raw: str
    start: int
    end: int
    book: object = None              # canon.Book 또는 None
    book_name: str = ""              # 글에 적힌 책 이름
    c1: int = 0
    v1: object = None                # None 이면 장 전체
    c2: int = 0
    v2: object = None
    candidates: list = field(default_factory=list)   # 모호한 약어의 후보

    @property
    def whole_chapter(self):
        return self.v1 is None

    def key(self):
        """테스트 비교용 튜플: (책 약어 또는 이름, c1, v1, c2, v2)"""
        name = self.book.abbr if self.book else self.book_name
        return (name, self.c1, self.v1, self.c2, self.v2)


def _build_book_regex(cn):
    names = set(n for n, _ in cn.all_names()) | set(AMBIGUOUS)
    path = os.path.join(_HERE, "data", "abbrev.json")
    extra = {}
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f:
            extra = json.load(f).get("extra_aliases", {})
    names |= set(extra)
    ordered = sorted(names, key=lambda s: (-len(s), s))
    alt = "|".join(re.escape(n) for n in ordered)
    return re.compile(r"(?<![0-9A-Za-z\uac00-\ud7a3])(" + alt + r")(?=\s*\d)"), extra


class Parser:
    def __init__(self, cn=None):
        self.canon = cn or canon_mod.load()
        self._re_book, self._extra = _build_book_regex(self.canon)

    # ---- 책 이름 -> Book
    def _resolve(self, name):
        if name in AMBIGUOUS:
            return None, AMBIGUOUS[name]
        b = self.canon.find(name)
        if b is None and name in self._extra:
            b = self.canon.find(self._extra[name])
        return b, []

    # ---- 범위 꼬리: -v2, -c2:v2, 절
    @staticmethod
    def _range_tail(text, j, c, v):
        m = _RE_RANGE.match(text, j)
        seg = (c, v, c, v)
        k = j
        if m:
            n = int(m.group(1))
            k = m.end()
            mc = _RE_COLON.match(text, k)
            if mc:
                seg = (c, v, n, int(mc.group(1)))
                k = mc.end()
            else:
                seg = (c, v, c, n)
        ms = _RE_VERSE_SUFFIX.match(text, k)
        if ms:
            k = ms.end()
        return seg, k

    def _locator(self, text, i, single_chapter, strict):
        """책 이름 뒤의 장절 부분을 읽는다. 반환: (segments, end) 또는 None.
        segments 항목은 (c1, v1, c2, v2). v1 이 None 이면 장 전체."""
        m = _RE_NUM.match(text, i)
        if not m:
            return None
        if _RE_CLOCK.match(text, m.start(1)):
            return None
        n = int(m.group(1))
        j = m.end()
        segs = []
        ctx = None
        mc = _RE_COLON.match(text, j)
        if mc:
            v = int(mc.group(1))
            if mc.group(1).startswith("0") or v == 0:      # "11:00" 같은 시간
                if strict:
                    return None
            seg, j = self._range_tail(text, mc.end(), n, v)
            segs.append(seg)
            ctx = n
        else:
            mw = _RE_CHAPTER_WORD.match(text, j)
            if mw:
                j = mw.end()
                mv = _RE_VERSE_WORD.match(text, j)
                if mv:
                    a = int(mv.group(1))
                    b = int(mv.group(2)) if mv.group(2) else a
                    segs.append((n, a, n, b))
                    j = mv.end()
                else:
                    segs.append((n, None, n, None))
                ctx = n
            elif single_chapter:
                mv = _RE_VERSE_WORD.match(text, m.start(1))
                if mv:                                       # 유 5절, 유 5-7절
                    a = int(mv.group(1))
                    b = int(mv.group(2)) if mv.group(2) else a
                    segs.append((1, a, 1, b))
                    j = mv.end()
                    ctx = 1
                elif not strict:
                    seg, j = self._range_tail(text, j, 1, n)
                    segs.append(seg)
                    ctx = 1
                else:
                    return None
            else:
                return None
        # 이어지는 목록: , 31   ;  12:1
        while True:
            ml = _RE_LIST.match(text, j)
            if not ml:
                break
            n2 = int(ml.group(2))
            k = ml.end()
            mc2 = _RE_COLON.match(text, k)
            if mc2:
                seg, j = self._range_tail(text, mc2.end(), n2, int(mc2.group(1)))
                segs.append(seg)
                ctx = n2
            elif ctx is not None and segs[-1][1] is not None:
                seg, j = self._range_tail(text, k, ctx, n2)
                segs.append(seg)
            else:
                break
        return segs, j

    def parse(self, text):
        """글 안의 모든 장절 표기를 찾아 Ref 목록으로 돌려준다."""
        out = []
        pos = 0
        while True:
            m = self._re_book.search(text, pos)
            if not m:
                break
            name = m.group(1)
            book, cands = self._resolve(name)
            single = bool(book and book.chapter_count == 1)
            if name in AMBIGUOUS:
                single = False
            strict = len(name) == 1
            loc = self._locator(text, m.end(), single, strict)
            if not loc:
                pos = m.end()
                continue
            segs, end = loc
            for (c1, v1, c2, v2) in segs:
                out.append(Ref(raw=text[m.start():end], start=m.start(), end=end, book=book,
                               book_name=name, c1=c1, v1=v1, c2=c2, v2=v2, candidates=list(cands)))
            pos = end
        return out

    def parse_one(self, text):
        refs = self.parse(text)
        return refs[0] if refs else None


_default = None


def parse(text):
    global _default
    if _default is None:
        _default = Parser()
    return _default.parse(text)
