"""장절 존재 검증 (표준 라이브러리만)

refparse 가 읽어 낸 Ref 가 범위표(canon)에 실제로 있는지 확인하고, 사유 코드를 돌려준다.

사유 코드
  OK                 존재함
  UNKNOWN_BOOK       책 이름을 모름
  AMBIGUOUS_BOOK     삼, 왕, 대 처럼 상/하(전/후)를 알 수 없음
  CHAPTER_ZERO       0장
  CHAPTER_OUT_OF_RANGE  책에 없는 장 (예: 시 151편)
  VERSE_ZERO         0절
  VERSE_OUT_OF_RANGE 장에 없는 절 (예: 유 1:30)
  RANGE_REVERSED     끝이 시작보다 앞 (예: 요 3:18-16)
경고(warnings)
  VARIANT_CHAPTER    개역한글과 절 수가 다를 수 있는 장. 사람이 개역한글 사이트로 확인
"""
from dataclasses import dataclass, field

import canon as canon_mod
import refparse


@dataclass
class Check:
    ok: bool
    code: str
    message: str
    ref: object = None
    warnings: list = field(default_factory=list)


def validate_ref(ref, cn=None):
    cn = cn or canon_mod.load()
    if ref.book is None:
        if ref.candidates:
            return Check(False, "AMBIGUOUS_BOOK",
                         "'%s' 는 %s 중 어느 책인지 알 수 없습니다" % (ref.book_name, ", ".join(ref.candidates)), ref)
        return Check(False, "UNKNOWN_BOOK", "책 이름을 알 수 없습니다: %s" % ref.book_name, ref)
    b = ref.book
    warns = []
    for c in (ref.c1, ref.c2):
        if c == 0:
            return Check(False, "CHAPTER_ZERO", "%s: 0장은 없습니다" % b.ko, ref)
        if c > b.chapter_count:
            return Check(False, "CHAPTER_OUT_OF_RANGE",
                         "%s 은(는) %d장까지 있습니다 (%d장 요청)" % (b.ko, b.chapter_count, c), ref)
    if (ref.c2, ref.v2 if ref.v2 is not None else 0) < (ref.c1, ref.v1 if ref.v1 is not None else 0):
        return Check(False, "RANGE_REVERSED", "끝이 시작보다 앞입니다: %s" % ref.raw, ref)
    for c, v in ((ref.c1, ref.v1), (ref.c2, ref.v2)):
        if v is None:
            continue
        if v == 0:
            return Check(False, "VERSE_ZERO", "%s %d장: 0절은 없습니다" % (b.ko, c), ref)
        mx = cn.max_verse(b, c)
        if v > mx:
            return Check(False, "VERSE_OUT_OF_RANGE",
                         "%s %d장은 %d절까지 있습니다 (%d절 요청)" % (b.ko, c, mx, v), ref)
        if cn.is_variant(b, c):
            w = "VARIANT_CHAPTER"
            if w not in warns:
                warns.append(w)
    return Check(True, "OK", "있는 장절입니다", ref, warns)


def validate_text(text, parser=None, cn=None):
    parser = parser or refparse.Parser(cn)
    return [validate_ref(r, cn or parser.canon) for r in parser.parse(text)]


def summarize(checks):
    bad = [c for c in checks if not c.ok]
    return {"total": len(checks), "bad": len(bad), "codes": sorted({c.code for c in bad})}
