# common: 목회자편 공통 모듈

앱 1~5가 복사해 쓰는 모듈이다. 파이썬 3.13 표준 라이브러리만 쓴다. 이 폴더는 앱이 아니라 **부품 상자**다.

```
python scripts/verify.py          # 하네스. 마지막 줄 RESULT: PASSED (n/n), 리포트 output/verify_report.json
python -m unittest discover -s tests
```

| 파일 | 하는 일 |
| --- | --- |
| `canon.py`, `data/canon.json` | 66권 이름, 약어, 장 수, 장별 절 수. 본문 없음 |
| `refparse.py`, `data/abbrev.json` | "요 3:16", "요한복음 3장 16절", "롬 8:28, 31", "창 1:1-2:3", "시 23편" 같은 표기를 읽는다 |
| `validate.py` | 읽은 장절이 실제로 있는지 확인하고 사유 코드를 돌려준다 |
| `bible_store.py`, `config/bible.json` | 번역본을 설정으로 지정, 본문 조회, 글자 단위 비교, 번역본 혼용 탐지 |
| `anonymize.py` | 교인 익명화(목회자용 복원 가능, 공유용 복원 불가), 잔여 검사 |
| `ai_call.py` | 익명화 검사를 통과한 글만 AI에 보낸다. 가짜 AI(MockAI)로 시험 |
| `verify_core.py` | 하네스 공통 규약(`record_metric`로 측정값을 리포트에 기록) |

## 쓰는 법

```python
import refparse, validate, bible_store
store = bible_store.BibleStore()                       # config/bible.json 의 active 번역본
store.check_quotes([("(설교 원고의 인용 글)", "요 3:16")])  # PASS/FAIL 과 사유 코드
validate.validate_text("본문 유 1:30, 시 151:1")        # 없는 장절을 찾는다
```

```python
import anonymize, ai_call
roster = anonymize.load_roster("data/members_sample.csv")      # 이름,직분
an = anonymize.Anonymizer(roster, mode="pastor")               # 공유용은 mode="share"
safe = an.anonymize("곽도율 집사님 가정 심방, 연락처 010-1234-5678")
data = ai_call.call_ai(safe, ai_call.cli_backend("claude"), roster=roster)   # 남은 정보가 있으면 호출 자체를 막는다
```

사유 코드: `OK`, `UNKNOWN_BOOK`, `AMBIGUOUS_BOOK`(삼, 왕, 대, 고, 살, 딤, 벧), `CHAPTER_ZERO`, `CHAPTER_OUT_OF_RANGE`, `VERSE_ZERO`, `VERSE_OUT_OF_RANGE`, `RANGE_REVERSED`. 경고 `VARIANT_CHAPTER`는 개역한글과 절 수가 다를 수 있는 장이다.

## 성경 본문 규칙 (가장 중요)

1. **개역개정 본문 데이터는 이 저장소에 넣지 않는다.** 대한성서공회 안내에 따르면 개역개정은 저작권 보호 대상이며, 교회 내부 교육용으로 무료 배포하더라도 본문 사용량과 관계없이 허가가 필요하다.
2. 개발과 시험에는 **개역한글 24절**과 **가짜 번역본 B**만 쓴다. 개역한글은 저작재산권이 2011-12-31에 소멸했다. 다만 성명표시권(번역본 이름 표기)과 동일성유지권(본문 임의 변경 금지)은 지킨다.
3. 번역본은 코드에 넣지 말고 `config/bible.json`으로 지정한다. 교회가 허가를 받은 번역본은 같은 형식의 파일로 `data/bible/`에 두고 등록한다.
4. 공개 웹에는 장절 표기와 대한성서공회 성경 사이트 링크를 쓴다. 대한성서공회는 자기 사이트로 링크하는 방식은 저작권료 없이 쓸 수 있다고 안내한다.
5. 출처: https://www.bskorea.or.kr/bbs/content.php?co_id=subpage2_3_4_1 (2026-10-27 확인), 저작권 FAQ https://www.bskorea.or.kr/bbs/board.php?bo_table=copyright_faq. 법률 자문이 아니다. 저작권 문의 02-2103-8730.

## 한계 (정직하게)

- **개역한글 본문 24절은 공식 사이트와 글자 대조를 하지 못했다.** 대한성서공회 성경플랫폼이 이 작업 환경의 브라우저에서 표시되지 않아, 제3자 전사본(MIT 저장소)에서 가져왔다. 출간 전에 반드시 대조한다. `data/LICENSES.md`에 근거가 있다.
- 장절 범위표는 KJV 구조에서 만들었다. 개역한글과 다를 수 있는 3개 장(아가 6, 고후 13, 요삼 1)은 제3자 전사본과 비교해 찾았고, 이 3곳이 공식 장절과 맞는지는 확인하지 못했다. 전 장을 공식 사이트와 대조하지는 못했다.
- 원어(히브리어, 헬라어) 데이터는 라이선스를 확인하지 못해 포함하지 않았다.
- 파서는 책 이름 뒤에 숫자가 있는 꼴만 읽는다. "요한복음 삼 장 십육 절"처럼 한글 숫자나, 장절 없이 책 이름만 있는 문장은 읽지 않는다. 한 글자 약어는 3:16 또는 3장/3편 꼴일 때만 읽으므로 "요 3:0" 같은 표기는 시간 표기로 보고 무시한다.
- 익명화는 명부와 호칭 패턴에 의존한다. 명부에 없고 성이 없는 이름(예: "철수 형제"), 별명, 애칭은 놓칠 수 있다(시험으로 확인한 한계). "누락 0건"은 우리 가짜 메모 40개 기준이며 처음 보는 표기는 놓칠 수 있다. 공유 전에 목회자가 읽어 확인한다.
- 실제 `claude -p`, `codex exec` 호출은 이 책을 쓴 PC에서 확인하지 못했다. 독자 PC에서 한 번 시험한다. `claude --bare`는 구독 로그인을 읽지 않고 API 키가 필요하므로 쓰지 않는다.
- 대응표(`mapping_csv`로 저장하는 파일)에는 실명이 들어 있다. `data/`처럼 Git에서 제외된 폴더에만 두고 메일, 클라우드 동기화 폴더로 내보내지 않는다.
- 집필 시점: 2026년 10월. 저작권 안내와 도구 사용법은 바뀔 수 있다. 사용 전 공식 안내를 확인한다.
