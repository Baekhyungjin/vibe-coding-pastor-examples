"""교인 익명화 모듈 (로컬 전용, 표준 라이브러리만)

원칙: 로컬 익명화가 먼저, AI는 그다음. 이 모듈의 잔여 검사(residual_scan)를 통과한 글만
ai_call.py 가 AI 에게 보낸다.

두 가지 출력
  mode="pastor"  목회자용. 가명이 번호까지 붙어 있고(성도 A, [연락처1] ...) 대응표로 복원할 수 있다.
                 대응표(mapping_rows)는 이 PC 밖으로 내보내지 않는다. Git, 메일, 클라우드 폴더 금지.
  mode="share"   공유용. [연락처], [기관] 처럼 번호 없는 일반 표시만 쓰고 대응표를 만들지 않는다(복원 불가).

바꾸는 것 (사양서 7.3 FR1)
  교인 이름(명부 대조 + 직분 호칭 패턴) -> 성도 A, 성도 B ... (같은 사람은 같은 가명)
  가족 관계 표현("성도 A의 둘째 아들") -> 성도 A의 가족
  전화번호, 이메일, 주소, 주민등록번호 형식 -> [연락처], [이메일], [주소], [주민번호]
  기관(병원, 학교, 직장 패턴 + 사전) -> [기관]
  민감 단어(건강, 가정, 경제 사정 등 설정 목록) -> [건강 사정] 등

한계 (정직하게)
  - 명부에 없고 성이 없는 이름(예: "철수 형제")은 놓칠 수 있다. 잔여 검사가 일부를 잡지만 완전하지 않다.
  - 문장 속 별명, 애칭, 외국 이름, 한 글자 이름은 알아보지 못한다.
  - 기계가 못 잡는 것은 공유 전에 목회자가 직접 읽어 확인한다.
  - 이 모듈은 법률 자문이 아니다. 교회 개인정보 처리 방침과 법령이 우선한다.
"""
import csv
import re

# ---------------------------------------------------------------- 패턴
PHONE = re.compile(r"(?<!\d)(?:\+82[-.\s]?1[016789]|01[016789]|0\d{1,2})[-.\s]?\d{3,4}[-.\s]?\d{4}(?!\d)")
RRN = re.compile(r"(?<!\d)(\d{2})(\d{2})(\d{2})[-\s]?([1-8])(\d{6})(?!\d)")
EMAIL = re.compile(r"[A-Za-z0-9._%+-]+\s?@\s?[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
SIDO = ("서울특별시|서울|부산광역시|부산|대구광역시|대구|인천광역시|인천|광주광역시|광주|대전광역시|대전|"
        "울산광역시|울산|세종특별자치시|세종|경기도|경기|강원특별자치도|강원도|강원|충청북도|충북|충청남도|충남|"
        "전북특별자치도|전라북도|전북|전라남도|전남|경상북도|경북|경상남도|경남|제주특별자치도|제주")
ADDRESS = re.compile(
    r"(?:" + SIDO + r")\s+(?:[가-힣]+(?:시|군|구)\s+){1,2}[가-힣0-9]+(?:로|길)"
    r"(?:\s*\d+(?:번?길)?)?(?:\s*\d+(?:-\d+)?)?(?:\s*,?\s*\d+동)?(?:\s*,?\s*\d+호)?")
APT = re.compile(r"[가-힣A-Za-z0-9]{2,10}(?:아파트|빌라|맨션|오피스텔)\s*\d{1,4}동(?:\s*\d{1,4}호)?")
INSTITUTION = re.compile(
    r"[가-힣A-Za-z0-9]{1,10}(?:대학병원|종합병원|병원|한의원|치과|의원|약국|초등학교|중학교|고등학교|대학교|"
    r"유치원|어린이집|주식회사|회사|은행|공장|연구소|학원|요양원|요양병원|복지관)")
SENSITIVE_DEFAULT = {
    "희귀 질환": "건강 사정", "희귀질환": "건강 사정", "희귀병": "건강 사정", "항암": "건강 사정", "암 투병": "건강 사정",
    "말기 암": "건강 사정", "투석": "건강 사정", "수술": "건강 사정", "입원": "건강 사정", "우울증": "건강 사정",
    "공황장애": "건강 사정", "치매": "건강 사정", "중독": "건강 사정",
    "이혼": "가정 사정", "별거": "가정 사정", "불임": "가정 사정", "낙태": "가정 사정", "가정 폭력": "가정 사정",
    "파산": "경제 사정", "실직": "경제 사정", "빚": "경제 사정", "신용불량": "경제 사정",
}
TITLES = "집사|권사|장로|전도사|목사|성도|청년|자매|형제|권찰|서리집사|안수집사"
HONOR = r"(?:님|께서|이)?"
SURNAMES = set("김이박최정강조윤장임한오서신권황안송류홍전고문양손배백허유남심노하곽성차주우구민진나지엄채원천방공현함변염여추도소석선설마길연위표명기반왕금옥육인맹제모탁국어은편용")
# 이름처럼 보이지만 이름이 아닌 흔한 말 (오탐 방지)
SAFE_WORDS = {
    "성도", "새신자", "신입", "모든", "우리", "이번", "지난", "다른", "한국", "교회", "교구", "주일", "청소년", "대학",
    "남자", "여자", "젊은", "어린", "새로운", "함께", "소그룹", "구역", "기도", "심방", "사역", "목회", "예배", "찬양",
    "한", "그", "이", "저", "각", "전체", "일반", "신앙", "임원", "오신", "믿음", "주님", "형제자매", "집사", "권사", "장로",
}
BIBLE_NAMES = {
    "바울", "다윗", "베드로", "요한", "야고보", "모세", "아브라함", "이삭", "야곱", "요셉", "사무엘", "엘리야", "엘리사",
    "이사야", "예레미야", "다니엘", "에스더", "마리아", "마르다", "나사로", "바나바", "디모데", "디도", "빌레몬", "스데반",
    "빌립", "안드레", "마태", "마가", "누가", "도마", "솔로몬", "여호수아", "기드온", "삼손", "한나", "사라", "리브가",
    "라헬", "레아", "룻", "나오미", "아론", "미리암", "에스라", "느헤미야", "욥", "요나", "호세아", "아모스", "예수",
    "하나님", "여호와", "성령",
}
FAMILY = r"(?:첫째|둘째|셋째|넷째|막내|큰|작은|맏)?\s*(?:아들|딸|남편|아내|어머니|아버지|부모님|손자|손녀|며느리|사위|동생|오빠|형|누나|언니|자녀|가족)"


def label(n, letters=True):
    s = ""
    n += 1
    while n > 0:
        n, r = divmod(n - 1, 26)
        s = chr(ord("A") + r) + s
    return s


def valid_birth(mm, dd):
    return 1 <= int(mm) <= 12 and 1 <= int(dd) <= 31


def load_roster(path):
    """members.csv (이름,직분) -> [(이름, 직분)]"""
    rows = []
    with open(path, encoding="utf-8-sig", newline="") as f:
        for r in csv.DictReader(f):
            n = (r.get("이름") or "").strip()
            if n:
                rows.append((n, (r.get("직분") or "").strip()))
    return rows


def _roster_names(roster):
    out = []
    for item in roster or []:
        out.append(item[0] if isinstance(item, (tuple, list)) else item)
    return sorted(set(out), key=lambda s: (-len(s), s))


def looks_like_name(w):
    return (2 <= len(w) <= 4 and w[0] in SURNAMES and w not in SAFE_WORDS and w not in BIBLE_NAMES
            and not any(w.startswith(s) for s in SAFE_WORDS if len(s) >= 2))


class Anonymizer:
    def __init__(self, roster=None, sensitive=None, institutions=None, mode="pastor"):
        assert mode in ("pastor", "share")
        self.mode = mode
        self.names = _roster_names(roster)
        self.sensitive = dict(SENSITIVE_DEFAULT)
        self.sensitive.update(sensitive or {})
        self.institutions = sorted(set(institutions or []), key=lambda s: (-len(s), s))
        self.alias = {}                 # 이름 -> 성도 A
        self.mapping_rows = []          # [{"가명":..., "원문":..., "종류":...}] pastor 모드만
        self.counts = {}
        self._seq = {}                  # 종류별 번호

    # ---- 보조
    def _count(self, kind):
        self.counts[kind] = self.counts.get(kind, 0) + 1

    def _token(self, kind, original):
        """종류별 대체 표시. pastor 는 번호를 붙이고 대응표에 남긴다."""
        self._count(kind)
        if self.mode == "share":
            return "[%s]" % kind
        key = (kind, original)
        known = getattr(self, "_tok", None)
        if known is None:
            self._tok = known = {}
        if key not in known:
            self._seq[kind] = self._seq.get(kind, 0) + 1
            known[key] = "[%s%d]" % (kind, self._seq[kind])
            self.mapping_rows.append({"가명": known[key], "원문": original, "종류": kind})
        return known[key]

    def _person(self, name):
        if name not in self.alias:
            self.alias[name] = "성도 " + label(len(self.alias))
            if self.mode == "pastor":
                self.mapping_rows.append({"가명": self.alias[name], "원문": name, "종류": "이름"})
        self._count("이름")
        return self.alias[name]

    # ---- 본체
    def anonymize(self, text):
        t = text
        # 1) 연락처, 주민번호 형식, 이메일, 주소
        t = RRN.sub(lambda m: self._token("주민번호", m.group(0)) if valid_birth(m.group(2), m.group(3)) else m.group(0), t)
        t = EMAIL.sub(lambda m: self._token("이메일", m.group(0)), t)
        t = PHONE.sub(lambda m: self._token("연락처", m.group(0)), t)
        t = ADDRESS.sub(lambda m: self._token("주소", m.group(0)), t)
        t = APT.sub(lambda m: self._token("주소", m.group(0)), t)
        # 2) 기관 (사전 먼저, 그다음 패턴)
        for inst in self.institutions:
            if inst in t:
                t = t.replace(inst, self._token("기관", inst))
        t = INSTITUTION.sub(lambda m: self._token("기관", m.group(0)), t)
        # 3) 민감 단어
        for term in sorted(self.sensitive, key=len, reverse=True):
            if term in t:
                t = t.replace(term, self._token(self.sensitive[term], term))
        # 4) 이름: 명부 이름 + 직분 호칭
        if self.names:
            # 한 번에 왼쪽부터 바꿔서 가명 글자가 "처음 나온 순서"로 정해지게 한다(실행마다 같은 결과)
            pat = re.compile("(" + "|".join(re.escape(n) for n in self.names) + r")(?:\s*(?:" + TITLES + r")" + HONOR + r")?")
            t = pat.sub(lambda m: self._person(m.group(1)), t)
        # 5) 명부에 없는 이름: "홍OO 집사님" 꼴
        def ctx(m):
            w = m.group(1)
            if looks_like_name(w):
                return self._person(w)
            return m.group(0)
        t = re.compile(r"(?<![가-힣])([가-힣]{2,4})\s?(?:집사|권사|장로|전도사|자매|형제|권찰|청년)" + HONOR + r"(?!부|회|들|층|모임|수련|찬양|예배)").sub(ctx, t)
        t = re.compile(r"(?<![가-힣])([가-힣]{2,4})\s?성도님").sub(ctx, t)
        # 6) 가족 관계
        t = re.compile(r"(성도 [A-Z]+)(?:\s*(?:" + TITLES + r")" + HONOR + r")?(?:의|네)?\s*" + FAMILY).sub(
            lambda m: self._family(m.group(1)), t)
        return t

    def _family(self, who):
        self._count("가족")
        return who + "의 가족"

    def restore(self, text):
        """pastor 모드의 대응표로 원문을 되돌린다. share 모드는 복원 불가."""
        if self.mode == "share":
            raise ValueError("공유용(share) 출력은 복원할 수 없습니다")
        t = text
        for row in sorted(self.mapping_rows, key=lambda r: len(r["가명"]), reverse=True):
            t = t.replace(row["가명"], row["원문"])
        return t

    def mapping_csv(self, path):
        """대응표 저장. 이 파일은 data/ 같은 Git 제외 폴더에만 둔다."""
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["가명", "원문", "종류"])
            w.writeheader()
            w.writerows(self.mapping_rows)


def residual_scan(text, roster=None, sensitive=None, institutions=None):
    """익명화한 글에 남은 개인정보 후보를 찾는다. 반환: [{"type":..., "value": 일부만 보임}]"""
    found = []

    def add(kind, v):
        found.append({"type": kind, "value": (v[:2] + "***") if len(v) > 2 else "***"})

    for m in PHONE.finditer(text):
        add("연락처", m.group(0))
    for m in RRN.finditer(text):
        if valid_birth(m.group(2), m.group(3)):
            add("주민번호", m.group(0))
    for m in EMAIL.finditer(text):
        add("이메일", m.group(0))
    for m in ADDRESS.finditer(text):
        add("주소", m.group(0))
    for m in APT.finditer(text):
        add("주소", m.group(0))
    for m in INSTITUTION.finditer(text):
        add("기관", m.group(0))
    for inst in institutions or []:
        if inst in text:
            add("기관", inst)
    terms = dict(SENSITIVE_DEFAULT)
    terms.update(sensitive or {})
    for term in terms:
        if term in text:
            add("민감단어", term)
    for n in _roster_names(roster):
        if n in text:
            add("명부이름", n)
    for m in re.finditer(r"(?<![가-힣])([가-힣]{2,4})\s?(?:집사|권사|장로|전도사|자매|형제|권찰|청년)(?:님|께서)?(?!부|회|들|층|모임|수련|찬양|예배)", text):
        if looks_like_name(m.group(1)):
            add("이름후보", m.group(1))
    for m in re.finditer(r"(?<![가-힣])([가-힣]{2,4})\s?성도님", text):
        if looks_like_name(m.group(1)):
            add("이름후보", m.group(1))
    return found
