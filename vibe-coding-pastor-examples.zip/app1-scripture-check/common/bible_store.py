"""번역본 저장소: 본문 조회, 글자 단위 비교, 번역본 혼용 탐지 (표준 라이브러리만)

번역본은 코드에 넣지 않고 config/bible.json 으로 지정한다.

지켜야 할 규칙 (대한성서공회 안내 기준, 법률 자문이 아님)
  - 번역본 이름을 반드시 표기한다(성명표시권). 이 모듈의 name 값을 결과물에 함께 쓴다.
  - 본문을 임의로 바꾸지 않는다(동일성유지권). 이 모듈은 본문을 읽기만 하고 수정하지 않는다.
  - 개역개정판 본문은 이 저장소에 넣지 않는다. 사용하려면 대한성서공회 허가가 필요하다.
  - 개발과 시험에는 개역한글 소량(30절 이내)과 가짜 번역본 B 만 쓴다.
"""
import difflib
import json
import os
import re
import unicodedata

import refparse
import validate as validate_mod

_HERE = os.path.dirname(os.path.abspath(__file__))
_PUNCT = re.compile(r"[\s.,;:!?'\"`\u2018\u2019\u201c\u201d\u00b7\u2026\u300c\u300d\u300e\u300f()\[\]{}<>\uff0c\uff0e\u3001\u3002~\-]+")


def normalize(text):
    """공백과 문장부호를 지우고 NFC 로 맞춘다. 글자 비교용."""
    return _PUNCT.sub("", unicodedata.normalize("NFC", text or ""))


def collapse_space(text):
    return re.sub(r"\s+", " ", unicodedata.normalize("NFC", text or "")).strip()


class Translation:
    def __init__(self, tid, cfg, base_dir):
        self.id = tid
        self.name = cfg["name"]                      # 결과물에 반드시 표기할 번역본 이름
        self.test_only = bool(cfg.get("test_only"))
        path = cfg["path"]
        if not os.path.isabs(path):
            path = os.path.join(base_dir, path)
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        self.meta = {k: v for k, v in raw.items() if k != "verses"}
        self.verses = raw["verses"]                  # "요 3:16" -> 본문

    def has(self, key):
        return key in self.verses

    def get(self, key):
        return self.verses.get(key)


class Comparison:
    def __init__(self, ref_key, translation, expected, quote, exact, normalized, diffs):
        self.ref_key = ref_key
        self.translation = translation
        self.expected = expected
        self.quote = quote
        self.exact = exact                 # 공백만 정리하고 글자까지 같은가
        self.normalized = normalized       # 공백과 문장부호를 지우고도 같은가
        self.diffs = diffs                 # [(종류, 기대 조각, 인용 조각, 기대 글자 위치)]

    @property
    def ok(self):
        return self.normalized


class BibleStore:
    def __init__(self, config_path=None, base_dir=None):
        base_dir = base_dir or _HERE
        config_path = config_path or os.path.join(base_dir, "config", "bible.json")
        with open(config_path, encoding="utf-8") as f:
            self.config = json.load(f)
        self.base_dir = base_dir
        self.translations = {t: Translation(t, c, base_dir) for t, c in self.config["translations"].items()}
        self.active_id = self.config["active"]
        self.parser = refparse.Parser()

    @property
    def active(self):
        return self.translations[self.active_id]

    # ---- 장절 -> 키 목록
    def keys_for(self, ref):
        """Ref 하나를 "요 3:16" 꼴 키 목록으로 푼다(같은 장 안의 구간, 여러 장은 저장된 절만)."""
        if ref.book is None or ref.v1 is None:
            return []
        abbr = ref.book.abbr
        if ref.c1 == ref.c2:
            return ["%s %d:%d" % (abbr, ref.c1, v) for v in range(ref.v1, ref.v2 + 1)]
        keys = []
        for c in range(ref.c1, ref.c2 + 1):
            lo = ref.v1 if c == ref.c1 else 1
            hi = ref.v2 if c == ref.c2 else 200
            keys += ["%s %d:%d" % (abbr, c, v) for v in range(lo, hi + 1)]
        return keys

    def text_of(self, ref_text, translation_id=None):
        """장절 표기 하나의 본문. 저장된 절이 하나라도 빠지면 None."""
        tr = self.translations[translation_id or self.active_id]
        refs = self.parser.parse(ref_text)
        if not refs:
            return None
        parts = []
        for r in refs:
            keys = [k for k in self.keys_for(r) if tr.has(k)] if r.c1 != r.c2 else self.keys_for(r)
            if not keys or any(not tr.has(k) for k in keys):
                return None
            parts += [tr.get(k) for k in keys]
        return " ".join(parts)

    # ---- 글자 단위 비교
    def compare(self, quote, ref_text, translation_id=None):
        tr = self.translations[translation_id or self.active_id]
        expected = self.text_of(ref_text, tr.id)
        if expected is None:
            return None
        e_raw, q_raw = collapse_space(expected), collapse_space(quote)
        e_n, q_n = normalize(expected), normalize(quote)
        diffs = []
        sm = difflib.SequenceMatcher(None, e_n, q_n, autojunk=False)
        for op, a1, a2, b1, b2 in sm.get_opcodes():
            if op != "equal":
                diffs.append((op, e_n[a1:a2], q_n[b1:b2], a1))
        return Comparison(ref_text, tr, expected, quote, e_raw == q_raw, e_n == q_n, diffs)

    def detect_mix(self, quote, ref_text):
        """인용이 지정한 번역본과 다르지만, 다른 번역본 데이터와는 같으면 그 번역본 id 를 돌려준다.
        (번역본 혼용 탐지) 없으면 None."""
        active = self.compare(quote, ref_text)
        if active is None or active.ok:
            return None
        for tid in self.translations:
            if tid == self.active_id:
                continue
            other = self.compare(quote, ref_text, tid)
            if other is not None and other.ok:
                return tid
        return None

    def check_quotes(self, items):
        """items: [(인용 글, 장절 표기)] -> 결과 목록. 각 결과는 dict(status, code, ...).
        status: PASS | FAIL. code: OK, REF_NOT_EXIST(+사유), NOT_IN_STORE, MISMATCH, MIXED_TRANSLATION"""
        out = []
        for quote, ref_text in items:
            checks = validate_mod.validate_text(ref_text, self.parser)
            if not checks:
                out.append({"status": "FAIL", "code": "NO_REF", "ref": ref_text})
                continue
            bad = [c for c in checks if not c.ok]
            if bad:
                out.append({"status": "FAIL", "code": "REF_NOT_EXIST:" + bad[0].code, "ref": ref_text, "message": bad[0].message})
                continue
            cmp = self.compare(quote, ref_text)
            if cmp is None:
                out.append({"status": "FAIL", "code": "NOT_IN_STORE", "ref": ref_text,
                            "message": "이 번역본 데이터에 해당 절이 없어 대조할 수 없습니다"})
                continue
            if cmp.ok:
                out.append({"status": "PASS", "code": "OK", "ref": ref_text, "translation": cmp.translation.name,
                            "exact": cmp.exact})
                continue
            mixed = self.detect_mix(quote, ref_text)
            if mixed:
                out.append({"status": "FAIL", "code": "MIXED_TRANSLATION", "ref": ref_text,
                            "message": "지정한 번역본(%s)이 아니라 %s 의 문장입니다" % (self.active.name, self.translations[mixed].name)})
            else:
                out.append({"status": "FAIL", "code": "MISMATCH", "ref": ref_text, "diffs": cmp.diffs[:5],
                            "message": "지정한 번역본(%s)과 글자가 다릅니다" % self.active.name})
        return out
