"""성경 66권 장절 범위표 (표준 라이브러리만)

data/canon.json 에서 책 이름, 약어, 장 수, 장별 절 수를 읽는다.
이 파일에는 성경 본문이 들어 있지 않다. 장과 절의 "개수"만 있다.

기준 구조는 공개 도메인 KJV(영어 흠정역)의 장절 구조이고, 개역한글과 다른 곳이
알려진 3곳은 data/canon.json 의 variants 에 따로 적었다. 자세한 근거와 한계는 data/LICENSES.md.
"""
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
_DEFAULT = os.path.join(_HERE, "data", "canon.json")


class Book:
    def __init__(self, raw):
        self.id = raw["id"]
        self.ko = raw["ko"]
        self.abbr = raw["abbr"]
        self.en = raw["en"]
        self.aliases = list(raw.get("aliases", []))
        self.testament = raw["testament"]
        self.verses = list(raw["verses"])          # 장별 절 수 (KJV 구조)
        self.chapter_count = len(self.verses)

    def names(self):
        return [self.ko, self.abbr] + self.aliases


class Canon:
    def __init__(self, path=_DEFAULT, extra_aliases=None):
        with open(path, encoding="utf-8") as f:
            raw = json.load(f)
        self.meta = {k: raw[k] for k in ("schema", "basis", "checked", "total_verses_kjv") if k in raw}
        self.books = [Book(b) for b in raw["books"]]
        self.variants = raw.get("variants", [])
        self._by_name = {}
        for b in self.books:
            for n in b.names():
                self._by_name[n] = b
        for name, ko in (extra_aliases or {}).items():
            if ko in self._by_name:
                self._by_name[name] = self._by_name[ko]
        # 개역한글과 다를 수 있는 장: (책 ko, 장) -> 허용 최대 절
        self._variant = {}
        for v in self.variants:
            self._variant[(v["book"], v["chapter"])] = max(v["kjv"], v["ko_third_party"])

    def find(self, name):
        """책 이름(전체명, 약어, 별칭)으로 Book 을 찾는다. 없으면 None."""
        return self._by_name.get((name or "").strip())

    def verse_count(self, book, chapter):
        """기준 구조의 절 수. 장이 없으면 None."""
        if not 1 <= chapter <= book.chapter_count:
            return None
        return book.verses[chapter - 1]

    def max_verse(self, book, chapter):
        """허용하는 가장 큰 절 번호(개역한글과 달라질 수 있는 장은 더 큰 쪽)."""
        base = self.verse_count(book, chapter)
        if base is None:
            return None
        return max(base, self._variant.get((book.ko, chapter), 0))

    def is_variant(self, book, chapter):
        return (book.ko, chapter) in self._variant

    def total_verses(self):
        return sum(sum(b.verses) for b in self.books)

    def all_names(self):
        """파서가 쓰는 (이름, Book) 목록"""
        return list(self._by_name.items())


_cached = None


def load(path=None):
    global _cached
    if path:
        return Canon(path)
    if _cached is None:
        _cached = Canon()
    return _cached
