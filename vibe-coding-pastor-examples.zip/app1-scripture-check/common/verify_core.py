"""하네스 공통 규약 (모든 앱이 복사해 쓰는 파일)

규약
  - tests/ 의 unittest 를 모두 돌린다.
  - output/verify_report.json 에 실행 시각, 테스트별 결과, 샘플 지문, 측정 수치를 쓴다.
  - 마지막 줄은 반드시 RESULT: PASSED (n/n) 또는 RESULT: FAILED (k/n).
  - 실패하면 종료 코드 2 (Stop 훅이 AI에게 '아직 안 끝났다'고 알리는 신호).
  - 테스트가 잰 수치는 record_metric() 으로 남기면 리포트에 함께 실린다.
"""
import datetime
import hashlib
import json
import os
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True

_METRICS_FILE = "metrics.tmp.json"


def record_metric(root, key, value):
    """테스트 안에서 부른다. 예: record_metric(ROOT, '분류 정확도', 0.92)"""
    path = Path(root) / "output" / _METRICS_FILE
    path.parent.mkdir(exist_ok=True)
    data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    data[key] = value
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


def sample_hashes(root, patterns=("*.eml", "*.csv", "*.json", "*.txt", "*.xlsx")):
    hashes = {}
    for pat in patterns:
        for p in sorted((Path(root) / "samples").rglob(pat)):
            hashes[p.relative_to(root).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()[:12]
    return hashes


class _Recorder(unittest.TextTestResult):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.records = []

    def _n(self, t):
        return t.id().split(".")[-1]

    def addSuccess(self, t):
        super().addSuccess(t)
        self.records.append({"test": self._n(t), "result": "PASS"})

    def addFailure(self, t, err):
        super().addFailure(t, err)
        self.records.append({"test": self._n(t), "result": "FAIL", "reason": str(err[1]).splitlines()[0]})

    def addError(self, t, err):
        super().addError(t, err)
        self.records.append({"test": self._n(t), "result": "ERROR", "reason": f"{err[0].__name__}: {err[1]}"})


def run_harness(root, quiet=False):
    root = Path(root)
    out = root / "output"
    out.mkdir(exist_ok=True)
    tmp = out / _METRICS_FILE
    if tmp.exists():
        tmp.unlink()
    suite = unittest.defaultTestLoader.discover(str(root / "tests"), top_level_dir=str(root / "tests"))
    with open(os.devnull, "w", encoding="utf-8") as sink:
        result = unittest.TextTestRunner(resultclass=_Recorder, verbosity=0, stream=sink).run(suite)
    metrics = json.loads(tmp.read_text(encoding="utf-8")) if tmp.exists() else {}
    if tmp.exists():
        tmp.unlink()
    total = len(result.records)
    passed = sum(r["result"] == "PASS" for r in result.records)
    ok = total > 0 and passed == total
    report = {
        "app": root.name,
        "run_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "sample_hashes": sample_hashes(root),
        "tests": result.records,
        "metrics": metrics,
        "result": "PASSED" if ok else "FAILED",
        "passed": passed,
        "total": total,
    }
    (out / "verify_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if not quiet:
        print(f"[하네스] {root.name} 검사 시작 ({report['run_at']})")
        for r in result.records:
            print(f"  {r['result']:<5} {r['test']}")
            if "reason" in r:
                print(f"        이유: {r['reason']}")
        for k, v in metrics.items():
            print(f"  [측정] {k}: {v}")
        print("  리포트: output/verify_report.json")
    if ok:
        print(f"RESULT: PASSED ({passed}/{total})")
        return 0
    print(f"RESULT: FAILED ({total - passed}/{total})")
    for r in result.records:
        if r["result"] != "PASS":
            print(f"{r['result']} {r['test']}: {r.get('reason', '')}", file=sys.stderr)
    print("하네스 실패: 위 항목을 고친 뒤 다시 실행하세요. tests/와 samples/는 고치지 마세요.", file=sys.stderr)
    return 2
