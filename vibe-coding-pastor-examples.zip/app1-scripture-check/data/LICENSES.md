# 데이터 출처와 라이선스 기록 (확인 일자 2026-10-27, 법률 자문이 아님)

## 개역한글 본문 (data/bible/gaehan_sample.json, 24절)
- 번역본 이름: **개역한글**. 성경전서 개역한글판 (c) 대한성서공회 1961. 저작재산권 보호기간은 2011-12-31 소멸, 성명표시권과 동일성유지권은 지켜야 한다(대한성서공회 저작권 안내 https://www.bskorea.or.kr/bbs/content.php?co_id=subpage2_3_4_1 , FAQ https://www.bskorea.or.kr/bbs/board.php?bo_table=copyright_faq&wr_id=5).
- **공식 대조 완료**: 24절 모두 대한성서공회 성경플랫폼 개역한글판(https://bible.bskorea.or.kr/bible/KRV/<책코드>.<장>)의 본문과 공백 정리와 NFC 정규화 후 글자까지 같다. 확인 일자 2026-10-27. 절별 결과는 data/official_check_krv.json (요 3:16, 시 23:1-6, 롬 8:28, 빌 4:6-7, 빌 4:13, 요일 1:9, 창 1:1-3, 잠 3:5-6, 사 41:10, 마 11:28, 렘 29:11, 고전 13:4-7).
- 가져온 경로: 제3자 전사본(thiagobodruk/bible, MIT)을 공식 사이트와 대조해 확인. 이 대조는 24절에 한한다. 교회가 쓸 번역본 파일은 data/bible/ 에 직접 넣는다.
- **개역개정 본문은 이 폴더에 없다.** 쓰려면 대한성서공회 허가가 필요하다(교회 내부 교육용 무료 배포도 허가 신청 대상).

## 가짜 번역본 B (data/bible/fakeB_test_only.json)
- 번역본 혼용 탐지 시험 전용. 개역한글 문장을 기계적으로 바꾼 가짜이며 실제 번역본이 아니다.

## 원어 데이터 (data/original/)
- 헬라어 요 3:16: MorphGNT SBLGNT 6.12 (https://github.com/morphgnt/sblgnt, 64-Jn-morphgnt.txt). SBLGNT 본문은 CC BY 4.0(http://sblgnt.com/license/ 에서 확인), MorphGNT 형태 분석과 기본형은 CC BY-SA 3.0(저장소 README). 표기: SBL Greek New Testament, Michael W. Holmes ed., SBL and Logos Bible Software. MorphGNT: J. K. Tauber (2017), DOI 10.5281/zenodo.376200. 이 파일을 다른 곳에 나눌 때는 CC BY-SA 조건(같은 조건 공유)을 따른다.
- 히브리어 시 23:1: Open Scriptures Hebrew Bible (https://github.com/openscriptures/morphhb, wlc/Ps.xml). CC BY 4.0, 원 본문 Westminster Leningrad Codex는 퍼블릭 도메인(저장소 LICENSE.md 확인). 표기: "Original work of the Open Scriptures Hebrew Bible available at https://github.com/openscriptures/morphhb". 표제(מִזְמוֹר לְדָוִד)는 OSHB 에서 시 23:1 에 포함되어 있어 KJV 구분 표시 뒤의 단어만 넣었다.
- 뜻풀이(사전) 데이터는 넣지 않았다. 라이선스를 확인한 사전이 없기 때문이다. 단어 뜻은 목회자가 가진 사전으로 확인한다.

## 장절 범위표 (common/data/canon.json)
- 공개 도메인 KJV 구조(thiagobodruk/bible, MIT). 개역한글과 다를 수 있는 3곳(아가 6장, 고후 13장, 요삼 1장)은 VARIANT_CHAPTER 경고를 붙인다. 이 3곳의 개역한글 절 수는 공식 사이트와 대조하지 못했다.