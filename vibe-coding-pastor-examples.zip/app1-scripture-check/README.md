# 앱 1: 성경 장절 정밀 검증 & 원어 리서치 정리 (로컬 전용)

설교 준비를 돕는 검증과 리서치 도구입니다. **설교를 대신 쓰지 않습니다.** 내 PC에서만 쓰고, 결과 파일(성경 본문과 설교 원고가 들어 있음)을 인터넷에 올리지 않습니다.

## 쓰는 법
```
python scripts/run.py --manuscript 내설교.docx          # 인용 검사
python scripts/run.py --ref "요 3:16"                  # 본문과 원어 데이터
python scripts/run.py --ref "요 3:16" --ai claude       # AI 초안(내 PC의 claude -p, 구독 로그인 필요)
python scripts/verify.py                                # 하네스: RESULT: PASSED (n/n)
```
결과는 output/ 에 생깁니다: 인용검사_원고명.md/.html, 리서치_본문.md, theology_review.md.

## 번역본
config/bible.json 의 active 가 지정한 번역본만 씁니다. 교회가 허가를 받은 번역본은 data/bible/ 에 같은 형식(data/bible/gaehan_sample.json 참고)의 파일로 넣고 config 에 등록하세요. 개역개정 본문은 대한성서공회 허가가 필요하며 이 폴더에는 없습니다. 결과물에는 번역본 이름이 반드시 표시됩니다.

## 한계
- 같은 절을 다른 번역본 데이터와 비교해 혼용을 찾는 기능은 등록된 번역본 파일 안에서만 동작합니다.
- 원어 데이터는 요 3:16(헬라어), 시 23:1(히브리어) 샘플만 있습니다. 더 쓰려면 라이선스를 확인한 데이터를 data/original/ 에 같은 형식으로 넣으세요(data/LICENSES.md 참고).
- 신학 리뷰는 doctrine.md 에 `| 표현:` 으로 적은 글자가 있는지만 기계가 찾습니다. 나머지는 "판단 필요"로 목회자에게 남깁니다.
- 실제 `claude -p` / `codex exec` 호출은 개발 PC에서 확인하지 못했습니다. 하네스는 가짜 AI(MockAI)로 돌렸습니다.
- Streamlit 화면(src/app_streamlit.py)은 선택 사항이며 실행을 확인하지 못했습니다. 기본 화면은 정적 HTML 입니다.
- 봉인(lock.py)은 Ch 5 의 것을 그대로 복사해 두었습니다. 사람이 테스트 목록을 승인한 뒤 `python scripts/lock.py "이름"` 으로 봉인하세요(이 폴더는 봉인 전 상태입니다).