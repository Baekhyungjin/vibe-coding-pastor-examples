"""하네스 실행 진입점 (모든 앱 공통 이름: scripts/verify.py)

하는 일
  1. tests/ 폴더의 테스트를 모두 돌린다.
  2. 결과를 output/verify_report.json 에 기록한다.
  3. 마지막 줄에 RESULT: PASSED (n/n) 또는 RESULT: FAILED (k/n) 을 출력한다.
  4. 실패하면 종료 코드 2를 돌려준다(훅이 AI에게 '아직 안 끝났다'고 알릴 때 사용).

사용법:
    python scripts/verify.py          # 자세히
    python scripts/verify.py --quiet  # 요약만
"""
import datetime
import hashlib
import json
import os
import sys
import unittest
from pathlib import Path

sys.dont_write_bytecode = True  # 고친 코드가 바로 반영되도록 캐시 파일을 만들지 않는다

ROOT = Path(__file__).resolve().parent.parent
QUIET = "--quiet" in sys.argv
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")


def file_hashes():
    hashes = {}
    for path in sorted((ROOT / "samples").rglob("*.md")):
        rel = path.relative_to(ROOT).as_posix()
        hashes[rel] = hashlib.sha256(path.read_bytes()).hexdigest()[:12]
    return hashes


class RecordingResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.records = []

    def _name(self, test):
        return test.id().split(".")[-1]

    def addSuccess(self, test):
        super().addSuccess(test)
        self.records.append({"test": self._name(test), "result": "PASS"})

    def addFailure(self, test, err):
        super().addFailure(test, err)
        self.records.append({"test": self._name(test), "result": "FAIL",
                             "reason": str(err[1]).splitlines()[0]})

    def addError(self, test, err):
        super().addError(test, err)
        self.records.append({"test": self._name(test), "result": "ERROR",
                             "reason": f"{err[0].__name__}: {err[1]}"})

    def addSubTest(self, test, subtest, err):
        # subTest 안에서 난 실패는 addFailure 로 오지 않는다. 기록하지 않으면 그 시험이 목록에서 사라져
        # 총 개수만 줄고 PASSED 로 보일 수 있다. 그래서 실패마다 FAIL 로 따로 적는다.
        super().addSubTest(test, subtest, err)
        if err is not None:
            kind = "FAIL" if issubclass(err[0], test.failureException) else "ERROR"
            self.records.append({"test": f"{self._name(test)} [{subtest._subDescription()}]", "result": kind,
                                 "reason": str(err[1]).splitlines()[0] if str(err[1]) else err[0].__name__})


def main():
    suite = unittest.defaultTestLoader.discover(str(ROOT / "tests"))
    with open(os.devnull, "w", encoding="utf-8") as sink:
        runner = unittest.TextTestRunner(resultclass=RecordingResult, verbosity=0, stream=sink)
        result = runner.run(suite)

    total = len(result.records)
    passed = sum(1 for r in result.records if r["result"] == "PASS")
    ok = total > 0 and passed == total

    report = {
        "app": ROOT.name,
        "run_at": datetime.datetime.now().astimezone().isoformat(timespec="seconds"),
        "python": sys.version.split()[0],
        "sample_hashes": file_hashes(),
        "tests": result.records,
        "result": "PASSED" if ok else "FAILED",
        "passed": passed,
        "total": total,
    }
    out_dir = ROOT / "output"
    out_dir.mkdir(exist_ok=True)
    (out_dir / "verify_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")

    if not QUIET:
        print(f"[하네스] {ROOT.name} 검사 시작 ({report['run_at']})")
        for r in result.records:
            line = f"  {r['result']:<5} {r['test']}"
            if "reason" in r:
                line += f"\n        이유: {r['reason']}"
            print(line)
        print("  리포트: output/verify_report.json")
    if ok:
        print(f"RESULT: PASSED ({passed}/{total})")
        return 0
    print(f"RESULT: FAILED ({total - passed}/{total})")
    # 훅(Stop)이 종료 코드 2를 받으면 stderr 내용을 AI에게 보여준다.
    # 그래서 실패 항목과 이유를 stderr에도 남긴다.
    for r in result.records:
        if r["result"] != "PASS":
            print(f"{r['result']} {r['test']}: {r.get('reason', '')}", file=sys.stderr)
    print("하네스 실패: 위 항목을 고친 뒤 다시 실행하세요. tests/와 samples/는 고치지 마세요.", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main())
