"""월 1회 규칙 점검. CLAUDE.md 의 실수 기록을 훑어서 정리할 것을 알려 준다.

사용법:
    python scripts/monthly_review.py                              # 이 폴더의 CLAUDE.md
    python scripts/monthly_review.py --claude 앱폴더\\CLAUDE.md    # 다른 앱 폴더(그 폴더의 tests/ 를 확인)
    python scripts/monthly_review.py --claude ... --approver "이 목사"   # 인수인계 때 봉인 승인자 확인
    python scripts/monthly_review.py --claude ... --strict        # 먼저 고칠 것이 있으면 종료 코드 1

보여 주는 것
  1. 먼저 고칠 것: 가리키는 테스트가 없는 규칙, 개인정보 규칙인데 테스트가 없는 것,
     신학 결론을 정해 버린 규칙, 규칙이 너무 많거나 긴 것
  2. 정리 후보: 테스트가 없는 규칙(부탁만), 오래된 항목, 옛 형식 항목
  3. 인수인계: 봉인 승인자(tests.lock), doctrine.md 가 봉인 대상인지
이 스크립트는 파일을 고치지 않는다. 정리와 신학 판단은 사람이 한다.
"""
import argparse
import datetime
import sys
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))

import journal  # noqa: E402

MESSAGES = {
    "GUARD_FILE_MISSING": "지키는 곳이 가리키는 테스트 파일이 없습니다",
    "GUARD_TEST_MISSING": "지키는 곳이 가리키는 테스트 이름이 없습니다",
    "PRIVACY_NO_GUARD": "개인정보 규칙인데 지키는 테스트가 없습니다",
    "THEOLOGY_VERDICT": "신학 결론을 정해 버린 규칙입니다(과정만 정하세요)",
}


def main(argv=None):
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser(description="월 1회 CLAUDE.md 점검")
    ap.add_argument("--claude", default=str(ROOT / "CLAUDE.md"))
    ap.add_argument("--root", default=None, help="테스트가 들어 있는 앱 폴더(기본: CLAUDE.md 가 있는 폴더)")
    ap.add_argument("--today", default=datetime.date.today().isoformat())
    ap.add_argument("--stale-days", type=int, default=90)
    ap.add_argument("--max-entries", type=int, default=30)
    ap.add_argument("--approver", default=None, help="지금 봉인 승인자여야 할 사람 이름")
    ap.add_argument("--strict", action="store_true", help="먼저 고칠 것이 있으면 종료 코드 1")
    args = ap.parse_args(argv)
    claude = Path(args.claude)
    root = Path(args.root) if args.root else claude.resolve().parent

    r = journal.review(claude, root, args.today, stale_days=args.stale_days, max_entries=args.max_entries)

    print(f"[월 점검] {claude.resolve().parent.name}/{claude.name}  (기준일 {args.today})")
    print(f"  실수 기록 항목: {r['entries']}개 (권장 {r['max_entries']}개 이하), 파일 {r['line_count']}줄 (권장 {r['max_lines']}줄 이하)")
    if r["entries"]:
        print(f"  지키는 테스트가 실제로 있는 규칙: {r['linked']}개 / {r['entries']}개")

    first = [f for f in r["findings"] if f["code"] in journal.BLOCKING]
    print(f"  먼저 고칠 것: {len(first)}건")
    for f in first:
        e = f["entry"]
        if e is None:
            print(f"    - {'항목이 너무 많습니다' if f['code'] == 'TOO_MANY' else '파일이 너무 깁니다'} ({f['info']})")
        else:
            print(f"    - {MESSAGES.get(f['code'], f['code'])}: {e['rule'][:50]}")

    print(f"  지키는 테스트가 없는 규칙(부탁만): {len(r['unlinked'])}개")
    for e in r["unlinked"]:
        print(f"    - {e['date'] or '날짜 없음'} {e['rule'][:50]}")
    print(f"  {r['stale_days']}일이 지난 항목: {len(r['stale'])}개")
    for e, age in r["stale"]:
        print(f"    - {e['date']} ({age}일 전) {e['rule'][:50]}")
    print(f"  옛 형식 항목: {len(r['old_format'])}개")
    for e in r["old_format"]:
        print(f"    - {e['date']} {e['rule'][:50]}")

    lock = journal.lock_info(root)
    has_doctrine = (root / "doctrine.md").is_file()
    if lock is None:
        print("  봉인: tests.lock 없음(봉인하지 않은 폴더)")
        if has_doctrine:
            print("  주의: doctrine.md 가 있는데 봉인하지 않았습니다. 교단 기준이 조용히 바뀔 수 있습니다.")
    else:
        if not has_doctrine:
            dtxt = "doctrine.md 없음(교단 기준서를 만든 뒤 봉인하세요)"
        elif "doctrine.md" in lock["files"]:
            dtxt = "doctrine.md 봉인됨"
        else:
            dtxt = "doctrine.md 봉인 안 됨"
        print(f"  봉인 승인자: {lock['approved_by']} ({lock['approved_at'][:10]}), 봉인 파일 {len(lock['files'])}개, {dtxt}")
        if args.approver and lock["approved_by"] != args.approver:
            print(f"  인수인계 주의: 지금 담당은 {args.approver} 인데 봉인 승인자는 {lock['approved_by']} 입니다. "
                  "후임이 테스트를 읽고 확인한 뒤 lock.py 로 다시 봉인하세요.")

    todo = len(r["unlinked"]) + len(r["old_format"]) + len(r["stale"])
    print(f"  정리 후보 합계: {todo}건")
    return 1 if (args.strict and first) else 0


if __name__ == "__main__":
    sys.exit(main())
