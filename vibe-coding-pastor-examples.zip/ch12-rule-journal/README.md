# ch12-rule-journal: 실수할 때마다 규칙 한 줄 (목회자편 Ch 12 예제)

CLAUDE.md 의 '## 실수 기록' 칸에 `날짜 | 실수 | 원인 | 규칙 | 지키는 곳` 한 줄을 쌓고,
한 달에 한 번 정리할 것을 점검하는 작은 도구입니다. 표준 라이브러리만 씁니다(Python 3.13에서 확인).

    python scripts/add_rule.py --mistake "..." --cause "..." --rule "..." --guard "tests/test_x.py::test_name"
    python scripts/add_rule.py ... --guard 없음            # 테스트가 아직 없을 때
    python scripts/monthly_review.py --claude 앱폴더\CLAUDE.md
    python scripts/monthly_review.py --claude 앱폴더\CLAUDE.md --approver "이 목사" --strict
    python scripts/verify.py

- 월 점검은 이 책의 앱 폴더들이 실제로 쓰는 네 가지 형식(한 줄, 슬래시, 표, 이어받은 규칙)을 읽습니다.
- 파일을 고치지 않습니다. 신학 판단을 하지 않습니다. 글자를 보고 짐작해서 목회자 확인으로 넘길 뿐입니다.
- samples/golden/formats/ 의 파일은 앱 폴더의 실제 CLAUDE.md 줄을 그대로 복사한 것입니다(교인 정보 없음).
- log/ 에는 첫 판의 실패 기록(run1_*), 고친 뒤의 기록, 일부러 느슨하게 고쳐 본 기록(mutation_demo.txt)이 있습니다.