"""규칙 일지 도우미의 핵심 로직 (표준 라이브러리만 사용)

CLAUDE.md 의 '## 실수 기록' 칸에 새 항목은 아래 한 줄 형식으로 쌓는다.

- 2026-10-27 | 실수: ... | 원인: ... | 규칙: ... | 지키는 곳: tests/test_x.py::test_name

월 점검은 이 책의 앱 폴더들이 실제로 쓰는 다른 형식도 읽는다.
  - 슬래시 형식   - 2026-10-27 / 실수 / 원인 / 규칙 / 지키는 테스트
  - 표 형식       | 날짜 | 실수 | 원인 | 규칙 | 지키는 테스트 |
  - 이어받은 규칙 - 이어받은 규칙 (출처): 규칙 / 지키는 테스트     (날짜 없음)
  - 옛 형식       - 2026-10-27: 한 줄 메모

'지키는 곳'은 그 규칙을 어기면 FAIL 이 나는 테스트다. 테스트가 없으면 '없음'이라고 적는다.
규칙은 AI에게 하는 부탁이고, 테스트는 강제다. 부탁만 있는 규칙은 월 점검 때 따로 보여 준다.

주의: 이 모듈은 글자를 보고 짐작할 뿐이다. 신학 판단을 하지 않는다.
"""
import datetime
import json
import re
from pathlib import Path

SECTION = "## 실수 기록"          # 제목 뒤에 설명이 붙어도 인식한다(앞부분만 비교)
DATE = r"\d{4}-\d{2}-\d{2}"
PIPE_RE = re.compile(rf"^- ({DATE}) \| 실수: (.+?) \| 원인: (.+?) \| 규칙: (.+?) \| 지키는 곳: (.+)$")
SLASH_RE = re.compile(rf"^- ({DATE}) / (.+)$")
OLD_RE = re.compile(rf"^- ({DATE}): (.+)$")
INHERIT_RE = re.compile(r"^- 이어받은 규칙 \((.+?)\): (.+)$")
TABLE_DATE_RE = re.compile(rf"^{DATE}$")
TOKEN_RE = re.compile(r"(?:([\w./\\-]+\.py)::)?(test_[\w]+)")
GUARD_PREFIX_RE = re.compile(r"^(지키는 테스트|지키는 곳)\s*:?\s*")
MAX_RULE_CHARS = 120

PRIVACY_WORDS = ("개인정보", "익명", "실명", "명부", "연락처", "전화", "대응표", "가명", "성도 이름", "교인 이름")
THEOLOGY_WORDS = ("신학", "doctrine", "교단", "번역본", "개역개정", "판단 필요", "해석")
VERDICT_WORDS = ("이 맞다", "가 맞다", "이 옳다", "가 옳다", "이 틀리다", "가 틀리다", "이단", "정답이다", "항상 답한다")

BLOCKING = ("GUARD_FILE_MISSING", "GUARD_TEST_MISSING", "PRIVACY_NO_GUARD", "THEOLOGY_VERDICT",
            "TOO_MANY", "TOO_LONG")


# ------------------------------------------------------------------ 읽기
def _entry(fmt, date, mistake, cause, rule, guard, raw):
    return {"kind": "new" if fmt in ("pipe", "slash", "table") else fmt, "format": fmt, "date": date,
            "mistake": mistake, "cause": cause, "rule": rule, "guard": guard.strip(), "raw": raw}


def parse_entries(text):
    """CLAUDE.md 본문에서 실수 기록 항목을 읽는다. 형식은 앱 폴더들이 쓰는 것을 모두 지원한다."""
    entries = []
    in_section = False
    for line in text.splitlines():
        if line.startswith("## "):
            in_section = line.strip().startswith(SECTION)
            continue
        if not in_section:
            continue
        m = PIPE_RE.match(line)
        if m:
            entries.append(_entry("pipe", m.group(1), m.group(2), m.group(3), m.group(4), m.group(5), line))
            continue
        m = SLASH_RE.match(line)
        if m:
            parts = m.group(2).split(" / ", 3)       # 마지막 칸에 슬래시가 더 있어도 그대로 둔다
            if len(parts) == 4:
                entries.append(_entry("slash", m.group(1), parts[0], parts[1], parts[2], parts[3], line))
            else:
                entries.append(_entry("old", m.group(1), m.group(2), "", m.group(2), "", line))
            continue
        m = INHERIT_RE.match(line)
        if m:
            body = m.group(2)
            rule, guard = body.rsplit(" / ", 1) if " / " in body else (body, "")
            entries.append(_entry("inherited", None, f"(이어받은 규칙: {m.group(1)})", "", rule, guard, line))
            continue
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) >= 5 and TABLE_DATE_RE.match(cells[0]):
                entries.append(_entry("table", cells[0], cells[1], cells[2], cells[3], cells[4], line))
            continue
        m = OLD_RE.match(line)
        if m:
            entries.append(_entry("old", m.group(1), m.group(2), "", m.group(2), "", line))
    return entries


# ------------------------------------------------------------------ 쓰기
def format_entry(date, mistake, cause, rule, guard):
    return f"- {date} | 실수: {mistake} | 원인: {cause} | 규칙: {rule} | 지키는 곳: {guard}"


def append_entry(path, entry_line):
    """'## 실수 기록' 칸의 맨 끝에 한 줄을 넣는다. 칸이 없으면 파일 끝에 만든다."""
    path = Path(path)
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    lines = text.splitlines()
    start = None
    for i, line in enumerate(lines):
        if line.strip().startswith(SECTION):
            start = i
            break
    if start is None:
        if lines and lines[-1].strip():
            lines.append("")
        lines += [SECTION, entry_line]
    else:
        end = len(lines)
        for j in range(start + 1, len(lines)):
            if lines[j].startswith("## "):
                end = j
                break
        insert_at = end
        while insert_at > start + 1 and not lines[insert_at - 1].strip():
            insert_at -= 1
        lines.insert(insert_at, entry_line)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ------------------------------------------------------------------ 짐작
def category(entry):
    """항목이 개인정보 규칙인지, 신학/번역본 규칙인지 짐작한다. 글자만 보는 짐작이다."""
    blob = " ".join([entry.get("mistake", ""), entry.get("rule", "")])
    if any(w in blob for w in PRIVACY_WORDS):
        return "개인정보"
    if any(w in blob for w in THEOLOGY_WORDS):
        return "신학"
    return "일반"


def verdict_words(rule):
    """규칙이 신학 결론을 정해 버리는 말을 담고 있는지 본다."""
    return [w for w in VERDICT_WORDS if w in rule]


def normalize_guard(guard):
    return GUARD_PREFIX_RE.sub("", (guard or "").strip()).strip()


def resolve_guard(guard, root):
    """'지키는 곳' 글자가 가리키는 테스트를 찾는다.

    반환: (상태, 설명)
      linked              테스트가 실제로 있다
      none                테스트가 없다고 적었거나 테스트를 가리키지 않는다
      GUARD_FILE_MISSING  가리킨 테스트 파일이 없다
      GUARD_TEST_MISSING  파일은 있으나(또는 어디에도) 그 이름의 테스트가 없다
    """
    g = normalize_guard(guard)
    if g == "" or g.startswith("없음") or g.startswith("부탁만"):
        return "none", "테스트 없음"
    m = TOKEN_RE.search(g)
    if not m:
        return "none", "테스트 이름이 아님"
    rel, name = m.group(1), m.group(2)
    root = Path(root)

    def has(text):
        return f"def {name}(" in text or re.search(rf"def {re.escape(name)}_", text) is not None

    if rel:
        f = root / rel.replace("\\", "/")
        if not f.is_file():
            return "GUARD_FILE_MISSING", rel
        return ("linked", name) if has(f.read_text(encoding="utf-8")) else ("GUARD_TEST_MISSING", name)
    tests_dir = root / "tests"
    files = sorted(tests_dir.rglob("*.py")) if tests_dir.is_dir() else []
    for f in files:
        if has(f.read_text(encoding="utf-8")):
            return "linked", name
    return "GUARD_TEST_MISSING", name


def guard_status(entry, root):
    """호환용: 'linked' | 'unlinked' | 'old'"""
    if entry["kind"] == "old":
        return "old"
    state, _ = resolve_guard(entry["guard"], root)
    return "linked" if state == "linked" else "unlinked"


def validate_new_entry(text, mistake, cause, rule, guard, root=None):
    """새 항목이 규칙을 지키는지 본다. 문제가 있으면 한국어 문장 목록을 돌려준다."""
    problems = []
    for name, value in (("실수", mistake), ("원인", cause), ("규칙", rule)):
        if not value or not value.strip():
            problems.append(f"'{name}' 칸이 비어 있습니다.")
    if guard is None or not str(guard).strip():
        problems.append("'지키는 곳'이 비어 있거나 빠졌습니다. --guard 에 테스트 이름을 적거나 --guard 없음 이라고 적어 주세요.")
    for value in (mistake, cause, rule, guard or ""):
        if value and ("|" in value or "\n" in value):
            problems.append("항목 안에 '|' 문자나 줄바꿈은 쓸 수 없습니다.")
            break
    if rule and len(rule) > MAX_RULE_CHARS:
        problems.append(f"규칙이 {len(rule)}자입니다. {MAX_RULE_CHARS}자 이내 한 줄로 줄여 주세요.")
    if rule:
        for e in parse_entries(text):
            if e["rule"].strip() == rule.strip():
                problems.append("이미 같은 규칙이 있습니다. 새로 추가하지 말고 기존 항목을 고쳐 주세요.")
                break
    if rule and category({"mistake": mistake or "", "rule": rule}) == "신학" and verdict_words(rule):
        problems.append("신학 결론을 규칙으로 적으면 안 됩니다. 규칙은 '판단 필요로 표시한다'처럼 과정을 정하고, 결론은 목회자가 정합니다.")
    if guard and root is not None:
        state, info = resolve_guard(guard, root)
        if state == "GUARD_FILE_MISSING":
            problems.append(f"'지키는 곳'의 테스트 파일을 찾지 못했습니다: {info}")
        elif state == "GUARD_TEST_MISSING":
            problems.append(f"'지키는 곳'의 테스트를 찾지 못했습니다: {info}. 테스트가 아직 없으면 --guard 없음 으로 적으세요.")
    return problems


# ------------------------------------------------------------------ 봉인과 인수인계
def lock_info(root):
    """tests.lock 이 있으면 승인자와 봉인 대상 파일을 읽는다. 없으면 None."""
    f = Path(root) / "tests.lock"
    if not f.is_file():
        return None
    data = json.loads(f.read_text(encoding="utf-8"))
    return {"approved_by": data.get("approved_by", ""), "approved_at": data.get("approved_at", ""),
            "files": sorted(data.get("files", {}))}


# ------------------------------------------------------------------ 월 점검
def review(claude_md, root, today, stale_days=90, max_entries=30, max_lines=150):
    """월 1회 점검 결과를 딕셔너리로 돌려준다. 파일을 고치지 않는다."""
    claude_md = Path(claude_md)
    text = claude_md.read_text(encoding="utf-8")
    entries = parse_entries(text)
    today_d = datetime.date.fromisoformat(today)

    unlinked, old_format, stale, findings = [], [], [], []
    linked = 0
    for e in entries:
        if e["kind"] == "old":
            old_format.append(e)
            findings.append({"code": "OLD_FORMAT", "entry": e})
        else:
            state, info = resolve_guard(e["guard"], root)
            if state == "linked":
                linked += 1
            else:
                unlinked.append(e)
                if state in ("GUARD_FILE_MISSING", "GUARD_TEST_MISSING"):
                    findings.append({"code": state, "entry": e, "info": info})
                elif category(e) == "개인정보":
                    findings.append({"code": "PRIVACY_NO_GUARD", "entry": e})
                else:
                    findings.append({"code": "UNLINKED", "entry": e})
        if category(e) == "신학" and verdict_words(e["rule"]):
            findings.append({"code": "THEOLOGY_VERDICT", "entry": e, "info": verdict_words(e["rule"])})
        if e["date"]:
            age = (today_d - datetime.date.fromisoformat(e["date"])).days
            if age > stale_days:
                stale.append((e, age))
                findings.append({"code": "STALE", "entry": e, "info": age})

    line_count = len(text.splitlines())
    too_many = len(entries) > max_entries
    too_long = line_count > max_lines
    if too_many:
        findings.append({"code": "TOO_MANY", "entry": None, "info": len(entries)})
    if too_long:
        findings.append({"code": "TOO_LONG", "entry": None, "info": line_count})
    return {
        "entries": len(entries),
        "linked": linked,
        "unlinked": unlinked,
        "old_format": old_format,
        "stale": stale,
        "too_many": too_many,
        "too_long": too_long,
        "line_count": line_count,
        "max_entries": max_entries,
        "max_lines": max_lines,
        "stale_days": stale_days,
        "findings": findings,
        "codes": sorted({f["code"] for f in findings}),
        "blocking": sorted({f["code"] for f in findings if f["code"] in BLOCKING}),
        "inherited": sum(1 for e in entries if e["format"] == "inherited"),
        "formats": sorted({e["format"] for e in entries}),
    }
