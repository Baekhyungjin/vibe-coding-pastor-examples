"""가짜 앱의 테스트 자리 표시. 월 점검이 지키는 테스트가 실제로 있는가를 확인할 때만 쓴다.
이 파일의 함수들은 일부러 아무것도 하지 않는다. verify.py 는 이 폴더를 돌리지 않는다.
"""

def test_번역본은_설정에서만_정한다():
    pass

def test_공유용에는_식별_단서가_없다():
    pass

def test_애매하면_판단필요로_표시한다():
    pass

def test_N5_공식_개역한글_대조_기록이_24절_모두_일치():
    pass

def test_H_표현이_없는_원고는_자동_표시가_없다():
    pass

def test_S4_stub():
    pass

def test_S9_stub():
    pass

def test_S10_stub():
    pass

def test_T4_총입금_빼기_총지출은_잔액이고_배정과_미배정을_더하면_총입금():
    pass

def test_N1_시각은_장절로_보지_않음():
    pass

def test_S3_함정은_정해진_이유로_걸린다():
    pass

def test_L2_봉인은_한글자_변경도_잡는다():
    pass

def test_a_stub():
    pass
