import io
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))

import verify  # noqa: E402  (scripts/verify.py 는 불러와도 바로 실행되지 않는다)


class TestHarnessRecording(unittest.TestCase):
    def test_V1_subTest_실패도_하네스가_FAIL로_기록한다(self):
        # 일부러 하위 시험 하나가 실패하는 작은 시험을 이 안에서만 만든다(바깥에 두면 verify.py 가 같이 돌린다).
        class Tiny(unittest.TestCase):
            def test_하위시험이_하나_실패한다(self):
                for n in (1, 2, 3):
                    with self.subTest(n=n):
                        self.assertNotEqual(n, 2)

            def test_모두_통과한다(self):
                self.assertTrue(True)

        suite = unittest.defaultTestLoader.loadTestsFromTestCase(Tiny)
        runner = unittest.TextTestRunner(resultclass=verify.RecordingResult, verbosity=0, stream=io.StringIO())
        result = runner.run(suite)
        results = [r["result"] for r in result.records]
        self.assertIn("FAIL", results, "subTest 실패가 기록에서 빠졌습니다. 이대로면 PASSED 로 보일 수 있습니다.")
        self.assertEqual(results.count("PASS"), 1)           # 통과한 시험은 따로 하나
        failing = [r for r in result.records if r["result"] == "FAIL"]
        self.assertEqual(len(failing), 1)
        self.assertIn("n=2", failing[0]["test"])


if __name__ == "__main__":
    unittest.main()
