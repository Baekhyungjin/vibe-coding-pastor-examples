import hashlib
import io
import json
import shutil
import sys
import unittest
import uuid
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import journal  # noqa: E402
import add_rule  # noqa: E402
import monthly_review  # noqa: E402

MINI = ROOT / "samples" / "golden" / "mini_app"
GOLDEN = MINI / "CLAUDE.md"
TRAP = ROOT / "samples" / "trap"
TODAY = "2026-10-30"
TMP_BASE = ROOT / "output" / "_test_tmp"


def run_review(argv):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        code = monthly_review.main(argv)
    return code, out.getvalue()


class TestTraps(unittest.TestCase):
    def test_H2_함정은_정해진_이유로만_걸린다(self):
        expected = json.loads((TRAP / "expected.json").read_text(encoding="utf-8"))
        for name, codes in expected.items():
            with self.subTest(name):
                r = journal.review(TRAP / name, MINI, TODAY)
                self.assertEqual(r["codes"], sorted(codes), f"{name}: 걸린 이유가 다릅니다 {r['codes']}")

    def test_S4_골든은_먼저_고칠_것이_없다(self):
        r = journal.review(GOLDEN, MINI, TODAY)
        self.assertEqual(r["blocking"], [])
        self.assertEqual(r["codes"], ["OLD_FORMAT", "STALE", "UNLINKED"])
        self.assertEqual(r["linked"], 3)

    def test_S5_항목이_30개를_넘으면_경고한다(self):
        r = journal.review(TRAP / "CLAUDE.trap_too_long.md", MINI, TODAY)
        self.assertEqual(r["entries"], 31)
        self.assertTrue(r["too_many"])
        self.assertFalse(r["too_long"])

    def test_S6_개인정보_규칙에_테스트가_없으면_먼저_고칠_것으로_올린다(self):
        r = journal.review(TRAP / "CLAUDE.trap_privacy_no_guard.md", MINI, TODAY)
        self.assertIn("PRIVACY_NO_GUARD", r["blocking"])
        self.assertNotIn("UNLINKED", r["codes"])      # 더 구체적인 이유 하나만 보고한다

    def test_S7_일반_규칙에_테스트가_없으면_정리_후보일_뿐이다(self):
        r = journal.review(GOLDEN, MINI, TODAY)
        self.assertEqual([f["code"] for f in r["findings"] if f["code"] == "UNLINKED"], ["UNLINKED"])
        self.assertEqual(r["blocking"], [])

    def test_S8_신학_결론을_정한_규칙은_잡지만_과정을_정한_규칙은_통과한다(self):
        bad = {"mistake": "본문 해석에 AI가 답을 정함", "rule": "이 본문은 알레고리 해석이 맞다고 항상 답한다"}
        good = {"mistake": "신학 우려를 결론처럼 적음", "rule": "신학적으로 애매하면 판단 필요로 표시한다"}
        self.assertEqual(journal.category(bad), "신학")
        self.assertTrue(journal.verdict_words(bad["rule"]))
        self.assertEqual(journal.verdict_words(good["rule"]), [])


class TestGuardResolution(unittest.TestCase):
    def test_G1_지키는_곳_글자를_여러_모양으로_읽는다(self):
        cases = [
            ("tests/test_sample.py::test_a_stub", "linked"),
            ("test_a_stub", "linked"),
            ("지키는 테스트: test_a_stub(설명이 붙어도)", "linked"),
            ("test_S4", "linked"),                                   # 이름 앞부분만 적은 경우
            ("tests/없는파일.py::test_a_stub", "GUARD_FILE_MISSING"),
            ("tests/test_sample.py::test_없는_이름", "GUARD_TEST_MISSING"),
            ("test_어디에도_없음", "GUARD_TEST_MISSING"),
            ("없음", "none"),
            ("지키는 테스트 없음(사람이 확인)", "none"),
            ("verify.py 전체(불러오기에 실패하면 모든 테스트가 실패)", "none"),
            ("", "none"),
        ]
        for guard, want in cases:
            with self.subTest(guard):
                self.assertEqual(journal.resolve_guard(guard, MINI)[0], want)


class TestAddGuard(unittest.TestCase):
    def setUp(self):
        TMP_BASE.mkdir(parents=True, exist_ok=True)
        self.tmp = TMP_BASE / ("r" + uuid.uuid4().hex[:8])
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        shutil.copytree(MINI, self.tmp)
        self.claude = self.tmp / "CLAUDE.md"

    def add(self, **kw):
        argv = ["--file", str(self.claude), "--date", "2026-10-30"]
        for k, v in kw.items():
            argv += [f"--{k}", v]
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = add_rule.main(argv)
        return code, err.getvalue()

    def sha(self):
        return hashlib.sha256(self.claude.read_bytes()).hexdigest()

    def test_A1_없는_테스트를_지키는_곳으로_적으면_거절한다(self):
        h = self.sha()
        code, err = self.add(mistake="a", cause="b", rule="새 규칙", guard="tests/test_sample.py::test_없는_이름")
        self.assertEqual(code, 1)
        self.assertIn("찾지 못했습니다", err)
        self.assertEqual(self.sha(), h)

    def test_A2_신학_결론을_규칙으로_적으면_거절한다(self):
        h = self.sha()
        code, err = self.add(mistake="본문 해석에 AI가 답을 정함", cause="b",
                             rule="이 본문은 알레고리 해석이 맞다고 항상 답한다", guard="없음")
        self.assertEqual(code, 1)
        self.assertIn("신학 결론", err)
        self.assertEqual(self.sha(), h)

    def test_A3_테스트가_아직_없으면_없음으로_적을_수_있다(self):
        code, err = self.add(mistake="a", cause="b", rule="새 규칙이다", guard="없음")
        self.assertEqual(code, 0, err)
        self.assertTrue(self.claude.read_text(encoding="utf-8").rstrip().endswith("지키는 곳: 없음"))


class TestHandover(unittest.TestCase):
    def setUp(self):
        TMP_BASE.mkdir(parents=True, exist_ok=True)
        self.tmp = TMP_BASE / ("h" + uuid.uuid4().hex[:8])
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        shutil.copytree(MINI, self.tmp)

    def test_P1_봉인_파일이_없으면_없다고_알린다(self):
        self.assertIsNone(journal.lock_info(self.tmp))
        code, out = run_review(["--claude", str(self.tmp / "CLAUDE.md"), "--today", TODAY])
        self.assertIn("tests.lock 없음", out)

    def test_P2_승인자가_다르면_인수인계_주의를_보여_준다(self):
        lock = {"approved_by": "김 목사", "approved_at": "2026-10-01T09:00:00+09:00",
                "files": {"tests/test_sample.py": "x", "doctrine.md": "y"}}
        (self.tmp / "tests.lock").write_text(json.dumps(lock, ensure_ascii=False), encoding="utf-8")
        info = journal.lock_info(self.tmp)
        self.assertEqual(info["approved_by"], "김 목사")
        code, out = run_review(["--claude", str(self.tmp / "CLAUDE.md"), "--today", TODAY])
        self.assertIn("doctrine.md 없음", out)          # 봉인 목록에 이름이 있어도 파일이 없으면 '봉인됨'이라고 하지 않는다
        (self.tmp / "doctrine.md").write_text("# 교단 기준서(가상)\n", encoding="utf-8")
        code, out = run_review(["--claude", str(self.tmp / "CLAUDE.md"), "--today", TODAY, "--approver", "이 목사"])
        self.assertIn("봉인 승인자: 김 목사", out)
        self.assertIn("doctrine.md 봉인됨", out)
        self.assertIn("인수인계 주의", out)
        code, out = run_review(["--claude", str(self.tmp / "CLAUDE.md"), "--today", TODAY, "--approver", "김 목사"])
        self.assertNotIn("인수인계 주의", out)


class TestReviewScript(unittest.TestCase):
    def test_R1_월_점검_화면에_숫자가_맞게_나온다(self):
        code, out = run_review(["--claude", str(GOLDEN), "--today", TODAY])
        self.assertEqual(code, 0)
        self.assertIn("실수 기록 항목: 5개", out)
        self.assertIn("먼저 고칠 것: 0건", out)
        self.assertIn("지키는 테스트가 실제로 있는 규칙: 3개 / 5개", out)
        self.assertIn("정리 후보 합계: 3건", out)

    def test_R2_strict는_먼저_고칠_것이_있으면_1을_돌려준다(self):
        code, out = run_review(["--claude", str(TRAP / "CLAUDE.trap_ghost_name.md"), "--root", str(MINI),
                                "--today", TODAY, "--strict"])
        self.assertEqual(code, 1)
        self.assertIn("테스트 이름이 없습니다", out)

    def test_R3_점검은_파일을_고치지_않는다(self):
        before = hashlib.sha256(GOLDEN.read_bytes()).hexdigest()
        run_review(["--claude", str(GOLDEN), "--today", TODAY])
        self.assertEqual(hashlib.sha256(GOLDEN.read_bytes()).hexdigest(), before)


class TestThisFolder(unittest.TestCase):
    def test_H1_이_폴더의_CLAUDE_md도_월_점검을_통과한다(self):
        r = journal.review(ROOT / "CLAUDE.md", ROOT, TODAY)
        self.assertEqual(r["blocking"], [], f"이 폴더의 규칙에 먼저 고칠 것이 있습니다: {r['blocking']}")
        self.assertGreaterEqual(r["entries"], 1)


if __name__ == "__main__":
    unittest.main()
