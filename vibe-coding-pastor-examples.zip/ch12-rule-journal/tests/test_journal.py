import hashlib
import io
import shutil
import sys
import unittest
import uuid
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts"))

import journal  # noqa: E402
import add_rule  # noqa: E402

MINI = ROOT / "samples" / "golden" / "mini_app"
GOLDEN = MINI / "CLAUDE.md"
FORMATS = ROOT / "samples" / "golden" / "formats"
TODAY = "2026-10-30"
TMP_BASE = ROOT / "output" / "_test_tmp"  # 시스템 TEMP 는 막힌 PC가 있어 폴더 안을 쓴다


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Base(unittest.TestCase):
    def setUp(self):
        TMP_BASE.mkdir(parents=True, exist_ok=True)
        self.tmp = TMP_BASE / uuid.uuid4().hex[:8]
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        shutil.copytree(MINI, self.tmp)           # 가짜 앱 폴더를 통째로 복사해서 고친다
        self.claude = self.tmp / "CLAUDE.md"

    def run_add(self, **kw):
        argv = ["--file", str(self.claude), "--date", "2026-10-30"]
        for k, v in kw.items():
            argv += [f"--{k}", v]
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = add_rule.main(argv)
        return code, out.getvalue(), err.getvalue()


class TestAddRule(Base):
    GOOD = dict(mistake="표를 반올림함", cause="반올림 금지 규칙이 없었음",
                rule="금액은 반올림하지 않는다", guard="tests/test_sample.py::test_a_stub")

    def test_S1_추가는_맨_끝에_한_줄만_들어간다(self):
        before = self.claude.read_text(encoding="utf-8").splitlines()
        code, out, err = self.run_add(**self.GOOD)
        self.assertEqual(code, 0, err)
        after = self.claude.read_text(encoding="utf-8").splitlines()
        self.assertEqual(after[:len(before)], before, "기존 줄이 바뀌었습니다")
        self.assertEqual(len(after), len(before) + 1)
        self.assertTrue(after[-1].startswith("- 2026-10-30 | 실수: 표를 반올림함 | 원인:"))

    def test_S1_다른_칸은_그대로_둔다(self):
        original = ("# 제목\n\n## 실수 기록 (설명이 뒤에 붙은 제목)\n"
                    "- 2026-10-01 | 실수: a | 원인: b | 규칙: c | 지키는 곳: 없음\n\n"
                    "## 메모\n여기는 건드리면 안 됩니다.\n")
        self.claude.write_text(original, encoding="utf-8")
        code, _, err = self.run_add(**self.GOOD)
        self.assertEqual(code, 0, err)
        text = self.claude.read_text(encoding="utf-8")
        self.assertTrue(text.endswith("## 메모\n여기는 건드리면 안 됩니다.\n"))
        self.assertLess(text.index("금액은 반올림하지 않는다"), text.index("## 메모"))

    def _assert_rejected(self, **override):
        h = sha(self.claude)
        kw = dict(self.GOOD)
        kw.update(override)
        code, out, err = self.run_add(**kw)
        self.assertEqual(code, 1)
        self.assertEqual(sha(self.claude), h, "거절했는데 파일이 바뀌었습니다")
        return err

    def test_S2_규칙이_120자를_넘으면_거절한다(self):
        self.assertIn("120자 이내", self._assert_rejected(rule="가" * 121))

    def test_S2_같은_규칙은_거절한다(self):
        self.assertIn("같은 규칙", self._assert_rejected(rule="번역본 이름은 config/bible.json 에서만 정한다"))

    def test_S2_지키는_곳이_빠지면_안내문을_보여_준다(self):
        # PowerShell 에서 --guard "" 는 인자가 통째로 사라질 수 있다. 빠진 것과 같게 다룬다.
        h = sha(self.claude)
        argv = ["--file", str(self.claude), "--mistake", "a", "--cause", "b", "--rule", "c"]
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = add_rule.main(argv)
        self.assertEqual(code, 1)
        self.assertIn("지키는 곳", err.getvalue())
        self.assertIn("없음", err.getvalue())
        self.assertEqual(sha(self.claude), h)


class TestFormats(unittest.TestCase):
    """이 책의 앱 폴더들이 실제로 쓰는 CLAUDE.md 형식을 모두 읽을 수 있어야 한다."""

    def _read(self, name):
        return journal.parse_entries((FORMATS / name).read_text(encoding="utf-8"))

    def test_F1_슬래시_형식을_읽는다(self):
        entries = self._read("slash.md")
        self.assertEqual(len(entries), 3)
        self.assertTrue(all(e["date"] == "2026-10-27" for e in entries))
        self.assertTrue(entries[0]["guard"].startswith("test_N5"))

    def test_F1_표_형식을_읽는다(self):
        entries = self._read("table.md")
        self.assertEqual(len(entries), 4)
        self.assertEqual([e["guard"] for e in entries], ["test_S4", "test_S9", "test_S4", "test_S10"])

    def test_F1_앱5_혼합_형식을_읽는다(self):
        entries = self._read("mixed_app5.md")
        self.assertEqual(len(entries), 3)

    def test_F1_이어받은_규칙은_날짜_없이_읽는다(self):
        entries = self._read("inherited.md")
        self.assertEqual(len(entries), 4)
        self.assertEqual(sum(1 for e in entries if e["date"] is None), 2)

    def test_F4_실제_형식_항목의_연결_상태(self):
        def status(name):
            return [journal.guard_status(e, MINI) for e in self._read(name)]
        self.assertEqual(status("slash.md"), ["linked", "linked", "unlinked"])
        self.assertEqual(status("table.md"), ["linked"] * 4)
        self.assertEqual(status("mixed_app5.md"), ["unlinked", "linked", "unlinked"])
        self.assertEqual(status("inherited.md"), ["linked", "unlinked", "linked", "linked"])


class TestReviewBasics(Base):
    def test_S3_골든_숫자(self):
        r = journal.review(GOLDEN, MINI, TODAY)
        self.assertEqual(r["entries"], 5)
        self.assertEqual(len(r["unlinked"]), 1)
        self.assertEqual(len(r["old_format"]), 1)
        self.assertEqual(len(r["stale"]), 1)
        self.assertFalse(r["too_many"])

    def test_N1_점검은_파일을_고치지_않는다(self):
        h = sha(self.claude)
        journal.review(self.claude, MINI, TODAY)
        self.assertEqual(sha(self.claude), h)


if __name__ == "__main__":
    unittest.main()
